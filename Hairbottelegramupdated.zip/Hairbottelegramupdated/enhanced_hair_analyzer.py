"""
Enhanced Hair Analysis System with advanced thickness prediction and realistic commentary
"""
import cv2
import numpy as np
import logging
from typing import Dict, Tuple, List, Optional
import random
from sklearn.cluster import KMeans
from scipy import ndimage
from scipy.stats import entropy

logger = logging.getLogger(__name__)

class EnhancedHairAnalyzer:
    """Enhanced hair analyzer with improved thickness prediction and realistic comments"""
    
    def __init__(self):
        self.thickness_model_initialized = False
        self.comment_templates = self._initialize_comment_templates()
        self.challenge_styles = self._initialize_challenge_styles()
    
    def _initialize_comment_templates(self):
        """Initialize realistic comment templates based on score ranges"""
        return {
            'thickness': {
                'low': [
                    "Your hair's got that fine, delicate texture - perfect for trying volume-boosting products! ✨",
                    "Fine hair can be absolutely gorgeous! Try some texturizing spray for extra oomph 💫",
                    "That wispy, ethereal look is so dreamy! Consider root-lifting techniques 🌸",
                    "Fine strands = endless styling possibilities! Volume-boosting shampoo would work wonders 💆‍♀️"
                ],
                'medium': [
                    "You've got that perfect medium thickness - so versatile for any style! 🔥",
                    "Your hair strikes the perfect balance - not too thick, not too fine, just right! ✨",
                    "Medium thickness is the holy grail of hair types - you can literally do anything! 💫",
                    "That beautiful medium density gives you the best of both worlds! 👑"
                ],
                'high': [
                    "Wow, that THICK hair is pure goals! You're blessed with natural volume 👑",
                    "Goddess-tier thickness detected! Your hair has serious main character energy 🔥",
                    "That voluminous mane is absolutely stunning - you've won the hair lottery! ✨",
                    "Your thick hair is giving Disney princess vibes - absolutely magnificent! 🦁"
                ]
            },
            'silkiness': {
                'low': [
                    "Time for some deep conditioning magic! Your hair will thank you for the extra TLC 💆‍♀️",
                    "A good hair mask could transform your texture into silk heaven! ✨",
                    "Your hair's begging for some moisture love - keratin treatments work wonders! 🌺",
                    "With the right products, you could unlock serious smoothness potential! 💫"
                ],
                'medium': [
                    "Your hair's got that natural smoothness that's so enviable! 🌸",
                    "That soft, touchable texture is absolutely gorgeous! ✨",
                    "You've got that perfect balance of texture and smoothness! 💫",
                    "Your hair looks so healthy and well-maintained - stunning! 👑"
                ],
                'high': [
                    "OH MY GOD that silky smooth perfection! Your hair is like liquid silk! 🔥",
                    "This is what hair commercials dream of - absolutely flawless silkiness! ✨",
                    "Your hair is smoother than a fresh silk pillowcase - incredible! 💎",
                    "That mirror-like shine and silk texture is pure perfection! 👑"
                ]
            },
            'length': {
                'short': [
                    "Short hair, don't care! That chic length is absolutely perfect on you! ✨",
                    "Your short style is giving major boss babe energy - love it! 🔥",
                    "That cute short cut frames your face beautifully! 💫",
                    "Short and sweet - you're rocking that confident vibe! 👑"
                ],
                'medium': [
                    "Medium length is so versatile - you can literally style it any way! ✨",
                    "That perfect shoulder-length is the sweet spot for styling! 💫",
                    "Your length is ideal for both casual and glam looks! 🌸",
                    "Medium length hair is having a moment - and you're nailing it! 🔥"
                ],
                'long': [
                    "That long, flowing hair is pure mermaid magic! 🧜‍♀️",
                    "Your long locks are absolutely breathtaking - so jealous! ✨",
                    "Rapunzel could never! Your long hair is stunning! 👑",
                    "That length is goals - you must get compliments constantly! 💫"
                ]
            },
            'elite_reactions': [
                "Elite Hair Status UNLOCKED! You're in the top 5% - incredible! 💎",
                "LEGENDARY hair detected! Welcome to the elite hair hall of fame! 👑",
                "Your hair just broke the excellence meter - absolutely stunning! 🏆",
                "TOP TIER hair goals achieved! You're setting the standard! ✨",
                "ICON status confirmed - your hair is pure perfection! 🔥"
            ],
            'color_vibrant': [
                "That color is absolutely POPPING! You're a walking work of art! 🎨",
                "Your vibrant color is giving main character energy - love it! 🔥",
                "Goddess-tier hair detected! That color is pure magic! ✨",
                "Your bold color choice is absolutely stunning - so brave and beautiful! 💫"
            ],
            'braids_specific': [
                "Those braids are absolutely STUNNING - the intricate work is incredible! ✨",
                "Your braid game is strong! The pattern and technique are flawless! 👑",
                "Braided perfection detected! This is serious hair artistry! 🎨",
                "Your braids are giving cultural beauty goddess vibes - absolutely gorgeous! 💫",
                "That braid work is mesmerizing - you've got serious skills! 🔥"
            ]
        }
    
    def _initialize_challenge_styles(self):
        """Initialize trending and rare style challenges"""
        return {
            'trending': [
                {'name': 'Curtain Bangs', 'difficulty': 'medium', 'points': 50},
                {'name': 'Wolf Cut', 'difficulty': 'hard', 'points': 75},
                {'name': 'Butterfly Layers', 'difficulty': 'medium', 'points': 60},
                {'name': 'Hime Cut', 'difficulty': 'hard', 'points': 80},
                {'name': 'Shag Layers', 'difficulty': 'medium', 'points': 55},
            ],
            'rare': [
                {'name': 'Victory Rolls', 'difficulty': 'expert', 'points': 100},
                {'name': 'Gibson Tuck', 'difficulty': 'expert', 'points': 95},
                {'name': 'Waterfall Braid Crown', 'difficulty': 'expert', 'points': 90},
                {'name': 'Dutch Braid Mohawk', 'difficulty': 'hard', 'points': 85},
                {'name': 'Twisted Crown Braid', 'difficulty': 'hard', 'points': 80},
            ]
        }
    
    def enhanced_thickness_analysis(self, hair_region: np.ndarray) -> Dict:
        """
        Advanced thickness analysis using pixel density and contrast
        """
        if hair_region is None or hair_region.size == 0:
            return {'thickness_score': 30.0, 'confidence': 0.0, 'thickness_map': None}
        
        try:
            # Convert to grayscale for analysis
            if len(hair_region.shape) == 3:
                gray_hair = cv2.cvtColor(hair_region, cv2.COLOR_RGB2GRAY)
            else:
                gray_hair = hair_region.copy()
            
            # 1. Pixel Density Analysis
            pixel_density = self._calculate_pixel_density(gray_hair)
            
            # 2. Contrast Analysis within hair strands
            contrast_score = self._analyze_hair_strand_contrast(gray_hair)
            
            # 3. Edge Density for hair strand definition
            edge_density = self._calculate_edge_density(gray_hair)
            
            # 4. Local Thickness Variation Analysis
            thickness_variation = self._analyze_thickness_variation(gray_hair)
            
            # 5. Hair Strand Count Estimation
            strand_count = self._estimate_strand_count(gray_hair)
            
            # 6. Generate thickness heatmap
            thickness_map = self._generate_thickness_heatmap(gray_hair)
            
            # Combine all metrics for final thickness score
            thickness_score = self._combine_thickness_metrics(
                pixel_density, contrast_score, edge_density, 
                thickness_variation, strand_count
            )
            
            # Calculate confidence based on analysis quality
            confidence = self._calculate_thickness_confidence(
                gray_hair, pixel_density, contrast_score
            )
            
            return {
                'thickness_score': thickness_score,
                'confidence': confidence,
                'thickness_map': thickness_map,
                'pixel_density': pixel_density,
                'contrast_score': contrast_score,
                'edge_density': edge_density,
                'strand_count': strand_count,
                'thickness_variation': thickness_variation
            }
            
        except Exception as e:
            logger.error(f"Error in enhanced thickness analysis: {e}")
            return {'thickness_score': 30.0, 'confidence': 0.0, 'thickness_map': None}
    
    def _calculate_pixel_density(self, gray_hair: np.ndarray) -> float:
        """Calculate hair pixel density"""
        # Threshold to identify hair pixels
        _, hair_mask = cv2.threshold(gray_hair, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # Calculate density as percentage of hair pixels
        total_pixels = gray_hair.shape[0] * gray_hair.shape[1]
        hair_pixels = np.sum(hair_mask > 0)
        
        density = (hair_pixels / total_pixels) * 100
        return min(100.0, density * 1.5)  # Scale for thickness relevance
    
    def _analyze_hair_strand_contrast(self, gray_hair: np.ndarray) -> float:
        """Analyze contrast within hair strands"""
        # Apply gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray_hair, (3, 3), 0)
        
        # Calculate local standard deviation (contrast measure)
        kernel = np.ones((9, 9), np.uint8)
        mean_filtered = cv2.filter2D(blurred.astype(np.float32), -1, kernel/81)
        sqr_mean_filtered = cv2.filter2D((blurred.astype(np.float32))**2, -1, kernel/81)
        
        local_variance = sqr_mean_filtered - mean_filtered**2
        local_std = np.sqrt(np.maximum(local_variance, 0))
        
        # Higher standard deviation indicates thicker hair strands
        contrast_score = np.mean(local_std) * 2
        return min(100.0, contrast_score)
    
    def _calculate_edge_density(self, gray_hair: np.ndarray) -> float:
        """Calculate edge density for strand definition"""
        edges = cv2.Canny(gray_hair, 50, 150)
        edge_pixels = np.sum(edges > 0)
        total_pixels = edges.shape[0] * edges.shape[1]
        
        edge_density = (edge_pixels / total_pixels) * 100
        return min(100.0, edge_density * 3)
    
    def _analyze_thickness_variation(self, gray_hair: np.ndarray) -> float:
        """Analyze thickness variation across the hair region"""
        h, w = gray_hair.shape
        
        # Divide into sections and analyze thickness in each
        sections_h = 5
        sections_w = 5
        section_thickness = []
        
        for i in range(sections_h):
            for j in range(sections_w):
                start_h = (i * h) // sections_h
                end_h = ((i + 1) * h) // sections_h
                start_w = (j * w) // sections_w
                end_w = ((j + 1) * w) // sections_w
                
                section = gray_hair[start_h:end_h, start_w:end_w]
                if section.size > 0:
                    # Use standard deviation as thickness indicator
                    thickness = np.std(section)
                    section_thickness.append(thickness)
        
        if section_thickness:
            avg_thickness = np.mean(section_thickness)
            return min(100.0, avg_thickness * 1.5)
        
        return 30.0
    
    def _estimate_strand_count(self, gray_hair: np.ndarray) -> int:
        """Estimate number of visible hair strands"""
        # Apply morphological operations to separate strands
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        processed = cv2.morphologyEx(gray_hair, cv2.MORPH_CLOSE, kernel)
        
        # Find contours as potential strands
        edges = cv2.Canny(processed, 30, 100)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Filter contours by size and aspect ratio
        valid_strands = 0
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 10:  # Minimum area threshold
                rect = cv2.boundingRect(contour)
                aspect_ratio = rect[3] / rect[2]  # height / width
                if aspect_ratio > 0.5:  # Strand-like shape
                    valid_strands += 1
        
        return valid_strands
    
    def _generate_thickness_heatmap(self, gray_hair: np.ndarray) -> np.ndarray:
        """Generate thickness heatmap overlay"""
        h, w = gray_hair.shape
        
        # Create thickness map using local standard deviation
        kernel_size = 15
        kernel = np.ones((kernel_size, kernel_size), np.float32) / (kernel_size * kernel_size)
        
        mean_img = cv2.filter2D(gray_hair.astype(np.float32), -1, kernel)
        sqr_img = cv2.filter2D((gray_hair.astype(np.float32))**2, -1, kernel)
        
        thickness_map = np.sqrt(sqr_img - mean_img**2)
        
        # Normalize to 0-255 for visualization
        thickness_map = cv2.normalize(thickness_map, None, 0, 255, cv2.NORM_MINMAX)
        
        # Apply color map for heatmap visualization
        thickness_heatmap = cv2.applyColorMap(thickness_map.astype(np.uint8), cv2.COLORMAP_JET)
        
        return thickness_heatmap
    
    def _combine_thickness_metrics(self, pixel_density: float, contrast_score: float, 
                                 edge_density: float, thickness_variation: float, 
                                 strand_count: int) -> float:
        """Combine all thickness metrics into final score"""
        
        # Weighted combination of metrics
        strand_score = min(100.0, strand_count * 2)  # More strands = thicker appearance
        
        combined_score = (
            pixel_density * 0.25 +
            contrast_score * 0.30 +
            edge_density * 0.20 +
            thickness_variation * 0.15 +
            strand_score * 0.10
        )
        
        return min(100.0, max(5.0, combined_score))
    
    def _calculate_thickness_confidence(self, gray_hair: np.ndarray, 
                                      pixel_density: float, contrast_score: float) -> float:
        """Calculate confidence in thickness analysis"""
        
        # Base confidence on image quality metrics
        hair_area = gray_hair.shape[0] * gray_hair.shape[1]
        
        # Larger regions give more confidence
        area_confidence = min(1.0, hair_area / 10000)
        
        # Higher contrast gives more confidence
        contrast_confidence = min(1.0, contrast_score / 50)
        
        # Reasonable pixel density gives more confidence
        density_confidence = 1.0 - abs(pixel_density - 50) / 100
        
        overall_confidence = (area_confidence + contrast_confidence + density_confidence) / 3
        
        return max(0.3, min(1.0, overall_confidence))
    
    def generate_realistic_comment(self, analysis_result: Dict) -> str:
        """Generate realistic, personalized comments based on analysis"""
        
        # Extract scores
        thickness_score = analysis_result.get('hair_thickness_score', 0)
        silkiness_score = analysis_result.get('hair_silkiness_score', 0) 
        length_score = analysis_result.get('hair_length_score', 0)
        overall_score = analysis_result.get('overall_score', 0)
        color_vibrancy = analysis_result.get('color_vibrancy', 0)
        hairstyle = analysis_result.get('hairstyle', 'unknown')
        
        comments = []
        
        # Thickness-based comments
        if thickness_score < 30:
            comments.append(random.choice(self.comment_templates['thickness']['low']))
        elif thickness_score < 70:
            comments.append(random.choice(self.comment_templates['thickness']['medium']))
        else:
            comments.append(random.choice(self.comment_templates['thickness']['high']))
        
        # Silkiness-based comments  
        if silkiness_score < 40:
            comments.append(random.choice(self.comment_templates['silkiness']['low']))
        elif silkiness_score < 75:
            comments.append(random.choice(self.comment_templates['silkiness']['medium']))
        else:
            comments.append(random.choice(self.comment_templates['silkiness']['high']))
        
        # Length-based comments
        if length_score < 30:
            comments.append(random.choice(self.comment_templates['length']['short']))
        elif length_score < 70:
            comments.append(random.choice(self.comment_templates['length']['medium']))
        else:
            comments.append(random.choice(self.comment_templates['length']['long']))
        
        # Special reactions
        if overall_score >= 85:  # Top 5%
            comments.insert(0, random.choice(self.comment_templates['elite_reactions']))
        
        if color_vibrancy > 70:
            comments.append(random.choice(self.comment_templates['color_vibrant']))
        
        # Braids-specific comments
        if 'braid' in hairstyle.lower() or hairstyle.lower() == 'braids':
            comments.insert(0, random.choice(self.comment_templates['braids_specific']))
        
        # Combine comments naturally
        if len(comments) > 3:
            # Select 2-3 most relevant comments
            selected_comments = comments[:3]
        else:
            selected_comments = comments
        
        return ' '.join(selected_comments)
    
    def suggest_challenge_style(self) -> Dict:
        """Suggest a trending or rare style challenge"""
        
        # 70% chance for trending, 30% for rare
        if random.random() < 0.7:
            category = 'trending'
            styles = self.challenge_styles['trending']
        else:
            category = 'rare'
            styles = self.challenge_styles['rare']
        
        style = random.choice(styles)
        
        return {
            'category': category,
            'name': style['name'],
            'difficulty': style['difficulty'],
            'points': style['points'],
            'challenge_text': self._generate_challenge_text(style, category)
        }
    
    def _generate_challenge_text(self, style: Dict, category: str) -> str:
        """Generate challenge text for style"""
        
        difficulty_emojis = {
            'medium': '⭐⭐',
            'hard': '⭐⭐⭐',
            'expert': '⭐⭐⭐⭐'
        }
        
        category_text = "TRENDING" if category == 'trending' else "RARE STYLE"
        
        return f"""
🎯 **{category_text} CHALLENGE** 🎯

Try the **{style['name']}** look!
Difficulty: {difficulty_emojis.get(style['difficulty'], '⭐')} {style['difficulty'].upper()}
Reward: {style['points']} challenge points

Think you can pull it off? Send me a photo when you try it! 
Perfect matches get bonus points and special recognition! ✨
        """.strip()

# Global instance
enhanced_analyzer = EnhancedHairAnalyzer()