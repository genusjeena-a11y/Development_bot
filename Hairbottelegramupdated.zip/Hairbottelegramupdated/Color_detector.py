import cv2
import numpy as np

def get_dominant_hair_color_rgb(image_path):
    """
    Get the dominant hair color in RGB format for glamorous naming
    
    Args:
        image_path (str): Path to the image file
        
    Returns:
        tuple: (r, g, b) values of dominant color, or (None, None, None) if failed
    """
    try:
        # Load the image
        image = cv2.imread(image_path)
        if image is None:
            return None, None, None
        
        # Convert BGR to RGB for processing
        rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Reshape for k-means
        rgb_reshaped = rgb_image.reshape((-1, 3))
        rgb_reshaped = np.float32(rgb_reshaped)
        
        # Apply k-means clustering
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)
        k = 1
        labels = np.zeros((rgb_reshaped.shape[0], 1), dtype=np.int32)
        _, labels, center = cv2.kmeans(rgb_reshaped, k, labels, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
        
        # Extract RGB values
        r, g, b = center[0]
        return int(r), int(g), int(b)
        
    except Exception as e:
        print(f"Error getting RGB color: {e}")
        return None, None, None

def analyze_hair_color(image_path):
    """
    Loads an image, converts it to HSV and LAB, extracts dominant hue and saturation,
    and calculates average saturation.

    Args:
        image_path (str): The path to the image file.

    Returns:
        tuple: A tuple containing the dominant hue, dominant saturation, and average saturation.
    """
    try:
        # Load the image
        image = cv2.imread(image_path)
        if image is None:
            print(f"Error: Could not load image from {image_path}")
            return None, None, None

        # Convert to HSV
        hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # Convert to LAB
        lab_image = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)

        # Reshape the HSV image to be a list of pixels for k-means
        hsv_reshaped = hsv_image.reshape((-1, 3))
        hsv_reshaped = np.float32(hsv_reshaped)

        # Calculate average saturation
        average_saturation = np.mean(hsv_image[:,:,1])

        # Define criteria and apply k-means clustering for dominant color
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)
        k = 1  # We are looking for the dominant color, so k=1
        
        # Initialize empty arrays for kmeans
        labels = np.zeros((hsv_reshaped.shape[0], 1), dtype=np.int32)
        _, labels, center = cv2.kmeans(hsv_reshaped, k, labels, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

        # The dominant color is the center of the cluster
        dominant_hue = center[0][0]
        dominant_saturation = center[0][1]


        return dominant_hue, dominant_saturation, average_saturation

    except Exception as e:
        print(f"An error occurred: {e}")
        return None, None, None

def map_color_to_class(hue, saturation, average_saturation):
    """
    Maps dominant hue and saturation values to hair color classes and calculates
    a Vibrancy score for dyed hair.

    Args:
        hue (float): The dominant hue value (0-180 for OpenCV HSV).
        saturation (float): The dominant saturation value (0-255 for OpenCV HSV).
        average_saturation (float): The average saturation of the image.

    Returns:
        tuple: A tuple containing the hair color class (str) and Vibrancy score (float or None).
    """
    # Define ranges based on typical HSV values (OpenCV uses H: 0-180, S/V: 0-255)

    vibrancy_score = None # Initialize vibrancy score

    # Black hair: Typically low saturation
    if saturation < 50:
        color_class = "black"

    # Red hair: Hue typically around 0-10 or 160-180
    elif (hue >= 0 and hue <= 10) or (hue >= 160 and hue <= 180):
        if saturation > 80: # Moderate to high saturation for red
             color_class = "red"
        else: # Low saturation in red range might be brown or dyed depending on V
             color_class = "dyed" # Or refine with Value later if needed

    # Blonde hair: Specific hue range with lower saturation
    elif (hue >= 11 and hue <= 30) and saturation < 100: # Example range, needs refinement
        color_class = "blonde"

    # Brown hair: Specific hue range with moderate saturation
    elif (hue >= 11 and hue <= 30) and saturation >= 100: # Example range, needs refinement
        color_class = "brown"

    # Dyed hair: Catch-all for colors that don't fit natural ranges or have high saturation
    else:
        color_class = "dyed"

    # Calculate Vibrancy score if classified as "dyed"
    if color_class == "dyed":
        # A simple approach using the average saturation, scaled
        vibrancy_score = average_saturation / 255.0 * 100.0 # Scale to 0-100


    return color_class, vibrancy_score

def get_hair_color_and_vibrancy(image_path):
    """
    Analyzes an image for hair color and vibrancy.

    Args:
        image_path (str): The path to the image file.

    Returns:
        tuple: A tuple containing the hair color class (str) and
               Vibrancy score (float or None). Returns (None, None) if
               analysis fails.
    """
    dominant_hue, dominant_saturation, average_saturation = analyze_hair_color(image_path)

    if dominant_hue is None or dominant_saturation is None or average_saturation is None:
        print("Error: Could not analyze hair color from the image.")
        return None, None

    hair_color_class, vibrancy_score = map_color_to_class(dominant_hue, dominant_saturation, average_saturation)

    return hair_color_class, vibrancy_score

# Example Usage (replace with your image paths):
# image_path_1 = 'path/to/your/image1.jpg'
# color1, vibrancy1 = get_hair_color_and_vibrancy(image_path_1)
# print(f"Image 1: Hair Color = {color1}, Vibrancy = {vibrancy1}")

# image_path_2 = 'path/to/your/image2.png'
# color2, vibrancy2 = get_hair_color_and_vibrancy(image_path_2)
# print(f"Image 2: Hair Color = {color2}, Vibrancy = {vibrancy2}")