"""
Challenge System for "Try This Look" feature
"""
import json
import os
import random
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class ChallengeSystem:
    """Manages style challenges and rewards for users"""
    
    def __init__(self):
        self.challenges_file = 'active_challenges.json'
        self.user_challenges_file = 'user_challenges.json'
        self.challenge_styles = self._initialize_challenge_styles()
        self.load_active_challenges()
        self.load_user_challenges()
    
    def _initialize_challenge_styles(self):
        """Initialize available challenge styles with difficulty and rewards"""
        return {
            'trending': [
                {
                    'name': 'Curtain Bangs',
                    'difficulty': 'medium',
                    'points': 50,
                    'description': 'Soft, face-framing bangs that part in the middle',
                    'tips': 'Use a round brush and blow dry away from your face for that perfect curtain effect',
                    'detection_keywords': ['bang', 'fringe', 'curtain'],
                    'style_features': ['face_framing', 'layered', 'parted']
                },
                {
                    'name': 'Wolf Cut',
                    'difficulty': 'hard', 
                    'points': 75,
                    'description': 'A choppy, layered style that combines a shag with a mullet',
                    'tips': 'This edgy style works best with natural texture - scrunch with texturizing mousse',
                    'detection_keywords': ['wolf', 'shag', 'layered', 'choppy'],
                    'style_features': ['heavily_layered', 'textured', 'edgy']
                },
                {
                    'name': 'Butterfly Layers',
                    'difficulty': 'medium',
                    'points': 60,
                    'description': 'Face-framing layers that create a butterfly-like silhouette',
                    'tips': 'Blow dry with a volumizing mousse to enhance the layered butterfly effect',
                    'detection_keywords': ['butterfly', 'layer', 'frame'],
                    'style_features': ['face_framing', 'voluminous', 'layered']
                },
                {
                    'name': 'Hime Cut',
                    'difficulty': 'hard',
                    'points': 80,
                    'description': 'Straight-across bangs with long hair and face-framing side pieces',
                    'tips': 'Keep the contrast sharp - straight bangs and side pieces with long back hair',
                    'detection_keywords': ['hime', 'straight', 'bang', 'princess'],
                    'style_features': ['straight_bangs', 'face_framing', 'long_back']
                },
                {
                    'name': 'Shag Layers',
                    'difficulty': 'medium',
                    'points': 55,
                    'description': 'Messy, textured layers throughout for effortless volume',
                    'tips': 'Air dry with sea salt spray for that perfect undone shag texture',
                    'detection_keywords': ['shag', 'messy', 'textured', 'layer'],
                    'style_features': ['textured', 'layered', 'voluminous']
                }
            ],
            'rare': [
                {
                    'name': 'Victory Rolls',
                    'difficulty': 'expert',
                    'points': 100,
                    'description': 'Classic 1940s pin-up style with rolled sections at the front',
                    'tips': 'Use strong hold gel and bobby pins - practice the rolling technique first',
                    'detection_keywords': ['victory', 'roll', 'vintage', 'pin'],
                    'style_features': ['vintage', 'rolled', 'structured']
                },
                {
                    'name': 'Gibson Tuck',
                    'difficulty': 'expert',
                    'points': 95,
                    'description': 'Elegant updo where hair is tucked and rolled under at the nape',
                    'tips': 'Start with slightly dirty hair for better grip and use hairspray for hold',
                    'detection_keywords': ['gibson', 'tuck', 'updo', 'elegant'],
                    'style_features': ['updo', 'elegant', 'tucked']
                },
                {
                    'name': 'Waterfall Braid Crown',
                    'difficulty': 'expert',
                    'points': 90,
                    'description': 'Cascading braid that wraps around the head like a crown',
                    'tips': 'Section hair carefully and let some strands fall free for the waterfall effect',
                    'detection_keywords': ['waterfall', 'braid', 'crown', 'cascade'],
                    'style_features': ['braided', 'crown_like', 'cascading']
                },
                {
                    'name': 'Dutch Braid Mohawk',
                    'difficulty': 'hard',
                    'points': 85,
                    'description': 'Bold Dutch braid down the center with shaved or slicked sides',
                    'tips': 'Keep the center braid tight and use gel to sleek down the sides',
                    'detection_keywords': ['dutch', 'mohawk', 'braid', 'center'],
                    'style_features': ['braided', 'center_part', 'edgy']
                },
                {
                    'name': 'Twisted Crown Braid',
                    'difficulty': 'hard',
                    'points': 80,
                    'description': 'Twisted sections that form a braided crown around the head',
                    'tips': 'Twist tightly and secure with clear elastics for an invisible finish',
                    'detection_keywords': ['twisted', 'crown', 'braid', 'halo'],
                    'style_features': ['braided', 'twisted', 'crown_like']
                }
            ],
            'seasonal': [
                {
                    'name': 'Beach Waves',
                    'difficulty': 'easy',
                    'points': 40,
                    'description': 'Effortless, tousled waves perfect for summer',
                    'tips': 'Scrunch with sea salt spray while damp and let air dry',
                    'detection_keywords': ['beach', 'wave', 'tousled', 'natural'],
                    'style_features': ['wavy', 'natural', 'tousled'],
                    'season': 'summer'
                },
                {
                    'name': 'Holiday Glam Curls',
                    'difficulty': 'medium',
                    'points': 65,
                    'description': 'Glamorous, bouncy curls perfect for special occasions',
                    'tips': 'Use a large barrel curling iron and finish with shine spray',
                    'detection_keywords': ['glam', 'curl', 'bouncy', 'holiday'],
                    'style_features': ['curly', 'voluminous', 'glamorous'],
                    'season': 'winter'
                }
            ]
        }
    
    def load_active_challenges(self):
        """Load active challenges from file"""
        try:
            if os.path.exists(self.challenges_file):
                with open(self.challenges_file, 'r') as f:
                    self.active_challenges = json.load(f)
            else:
                self.active_challenges = []
                self.save_active_challenges()
        except Exception as e:
            logger.error(f"Error loading active challenges: {e}")
            self.active_challenges = []
    
    def load_user_challenges(self):
        """Load user challenge progress from file"""
        try:
            if os.path.exists(self.user_challenges_file):
                with open(self.user_challenges_file, 'r') as f:
                    self.user_challenges = json.load(f)
            else:
                self.user_challenges = {}
                self.save_user_challenges()
        except Exception as e:
            logger.error(f"Error loading user challenges: {e}")
            self.user_challenges = {}
    
    def save_active_challenges(self):
        """Save active challenges to file"""
        try:
            with open(self.challenges_file, 'w') as f:
                json.dump(self.active_challenges, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Error saving active challenges: {e}")
    
    def save_user_challenges(self):
        """Save user challenge progress to file"""
        try:
            with open(self.user_challenges_file, 'w') as f:
                json.dump(self.user_challenges, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Error saving user challenges: {e}")
    
    def create_daily_challenge(self) -> Dict:
        """Create a new daily challenge"""
        
        # Check if there's already an active daily challenge
        now = datetime.now()
        for challenge in self.active_challenges:
            if challenge['type'] == 'daily' and challenge['expires'] > now.isoformat():
                return challenge
        
        # Create new daily challenge
        category = random.choice(['trending', 'rare'])
        if random.random() < 0.8:  # 80% trending, 20% rare
            category = 'trending'
        
        style = random.choice(self.challenge_styles[category])
        
        challenge = {
            'id': f"daily_{now.strftime('%Y%m%d')}",
            'type': 'daily',
            'category': category,
            'style': style,
            'created': now.isoformat(),
            'expires': (now + timedelta(days=1)).isoformat(),
            'participants': [],
            'completions': []
        }
        
        # Remove any expired daily challenges
        self.active_challenges = [c for c in self.active_challenges 
                                if c['type'] != 'daily' or c['expires'] > now.isoformat()]
        
        self.active_challenges.append(challenge)
        self.save_active_challenges()
        
        return challenge
    
    def create_weekly_challenge(self) -> Dict:
        """Create a new weekly challenge (harder styles)"""
        
        now = datetime.now()
        
        # Check if there's already an active weekly challenge
        for challenge in self.active_challenges:
            if challenge['type'] == 'weekly' and challenge['expires'] > now.isoformat():
                return challenge
        
        # Create new weekly challenge (always rare/expert level)
        style = random.choice(self.challenge_styles['rare'])
        
        challenge = {
            'id': f"weekly_{now.strftime('%Y%W')}",
            'type': 'weekly',
            'category': 'rare',
            'style': style,
            'created': now.isoformat(),
            'expires': (now + timedelta(weeks=1)).isoformat(),
            'participants': [],
            'completions': [],
            'bonus_points': 25  # Extra points for weekly challenges
        }
        
        # Remove any expired weekly challenges
        self.active_challenges = [c for c in self.active_challenges 
                                if c['type'] != 'weekly' or c['expires'] > now.isoformat()]
        
        self.active_challenges.append(challenge)
        self.save_active_challenges()
        
        return challenge
    
    def get_random_challenge_suggestion(self) -> Dict:
        """Get a random challenge suggestion for a user"""
        
        # 60% chance for trending, 30% for rare, 10% for seasonal
        rand = random.random()
        if rand < 0.6:
            category = 'trending'
        elif rand < 0.9:
            category = 'rare'
        else:
            category = 'seasonal'
        
        styles = self.challenge_styles[category]
        
        # Filter seasonal challenges by current season if applicable
        if category == 'seasonal':
            current_season = self._get_current_season()
            seasonal_styles = [s for s in styles if s.get('season') == current_season]
            if seasonal_styles:
                styles = seasonal_styles
        
        style = random.choice(styles)
        
        return {
            'category': category,
            'style': style,
            'challenge_text': self._generate_challenge_text(style, category)
        }
    
    def check_style_match(self, detected_hairstyle: str, challenge_style: Dict) -> float:
        """Check how well a detected hairstyle matches a challenge style"""
        
        detected_lower = detected_hairstyle.lower()
        
        # Direct keyword matching
        keyword_matches = 0
        for keyword in challenge_style.get('detection_keywords', []):
            if keyword.lower() in detected_lower:
                keyword_matches += 1
        
        # Calculate match score (0-100)
        if keyword_matches > 0:
            # Base score on keyword matches
            keyword_score = min(100, (keyword_matches / len(challenge_style.get('detection_keywords', []))) * 100)
            
            # Bonus for exact name match
            if challenge_style['name'].lower() in detected_lower:
                keyword_score = min(100, keyword_score * 1.5)
            
            return keyword_score
        
        # Fallback: check for partial matches in style features
        feature_matches = 0
        for feature in challenge_style.get('style_features', []):
            if feature.replace('_', ' ') in detected_lower or feature.replace('_', '') in detected_lower:
                feature_matches += 1
        
        if feature_matches > 0:
            return min(80, (feature_matches / len(challenge_style.get('style_features', []))) * 80)
        
        return 0.0
    
    def evaluate_challenge_completion(self, user_id: int, detected_hairstyle: str, 
                                    analysis_result: Dict) -> Optional[Dict]:
        """Evaluate if user completed any active challenges"""
        
        completions = []
        
        for challenge in self.active_challenges:
            # Check if challenge is still active
            if datetime.now() > datetime.fromisoformat(challenge['expires']):
                continue
            
            # Check if user already completed this challenge
            if any(c.get('user_id') == user_id for c in challenge.get('completions', [])):
                continue
            
            # Check style match
            match_score = self.check_style_match(detected_hairstyle, challenge['style'])
            
            if match_score >= 70:  # Good match threshold
                # Calculate points
                base_points = challenge['style']['points']
                bonus_points = challenge.get('bonus_points', 0)
                quality_bonus = min(20, (analysis_result.get('overall_score', 0) - 70) / 2)  # Bonus for high quality
                
                total_points = base_points + bonus_points + max(0, quality_bonus)
                
                completion = {
                    'user_id': user_id,
                    'challenge_id': challenge['id'],
                    'challenge_type': challenge['type'],
                    'style_name': challenge['style']['name'],
                    'match_score': match_score,
                    'points_earned': int(total_points),
                    'completed_at': datetime.now().isoformat(),
                    'analysis_score': analysis_result.get('overall_score', 0)
                }
                
                # Add to challenge completions
                challenge['completions'].append(completion)
                
                # Update user's challenge history
                if str(user_id) not in self.user_challenges:
                    self.user_challenges[str(user_id)] = {'total_points': 0, 'completed_challenges': []}
                
                self.user_challenges[str(user_id)]['total_points'] += int(total_points)
                self.user_challenges[str(user_id)]['completed_challenges'].append(completion)
                
                completions.append(completion)
        
        if completions:
            self.save_active_challenges()
            self.save_user_challenges()
        
        return completions
    
    def get_user_stats(self, user_id: int) -> Dict:
        """Get user's challenge statistics"""
        
        user_data = self.user_challenges.get(str(user_id), {})
        
        completed_challenges = user_data.get('completed_challenges', [])
        
        stats = {
            'total_points': user_data.get('total_points', 0),
            'challenges_completed': len(completed_challenges),
            'daily_completed': len([c for c in completed_challenges if c.get('challenge_type') == 'daily']),
            'weekly_completed': len([c for c in completed_challenges if c.get('challenge_type') == 'weekly']),
            'recent_completions': sorted(completed_challenges, key=lambda x: x.get('completed_at', ''), reverse=True)[:5]
        }
        
        return stats
    
    def get_active_challenges_for_user(self) -> List[Dict]:
        """Get all active challenges for display"""
        
        now = datetime.now()
        active = []
        
        for challenge in self.active_challenges:
            if datetime.fromisoformat(challenge['expires']) > now:
                active.append({
                    'id': challenge['id'],
                    'type': challenge['type'],
                    'style_name': challenge['style']['name'],
                    'description': challenge['style']['description'],
                    'difficulty': challenge['style']['difficulty'],
                    'points': challenge['style']['points'] + challenge.get('bonus_points', 0),
                    'tips': challenge['style']['tips'],
                    'expires': challenge['expires'],
                    'participants': len(challenge.get('participants', [])),
                    'completions': len(challenge.get('completions', []))
                })
        
        return active
    
    def _generate_challenge_text(self, style: Dict, category: str) -> str:
        """Generate challenge description text"""
        
        difficulty_emojis = {
            'easy': '⭐',
            'medium': '⭐⭐',
            'hard': '⭐⭐⭐',
            'expert': '⭐⭐⭐⭐'
        }
        
        category_text = category.upper()
        if category == 'trending':
            category_text = "TRENDING STYLE"
        elif category == 'rare':
            category_text = "RARE CHALLENGE"
        elif category == 'seasonal':
            category_text = "SEASONAL SPECIAL"
        
        challenge_text = f"""
🎯 **{category_text} CHALLENGE** 🎯

**{style['name']}**
{style['description']}

Difficulty: {difficulty_emojis.get(style['difficulty'], '⭐')} {style['difficulty'].upper()}
Reward: {style['points']} points

💡 **Pro Tip:** {style['tips']}

Think you can nail this look? Send me a photo when you try it! 
Perfect matches earn full points and special recognition! ✨
        """.strip()
        
        return challenge_text
    
    def _get_current_season(self) -> str:
        """Get current season based on month"""
        month = datetime.now().month
        if month in [12, 1, 2]:
            return 'winter'
        elif month in [3, 4, 5]:
            return 'spring'
        elif month in [6, 7, 8]:
            return 'summer'
        else:
            return 'fall'

# Global instance
challenge_system = ChallengeSystem()