import os
import logging
from flask import Flask, render_template, send_from_directory, request, jsonify
from photo_manager import photo_manager

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "hair-analysis-secret-key")

# Configuration
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def index():
    """Homepage with statistics"""
    try:
        # Get basic stats from photo manager
        all_photos = photo_manager.get_all_photos()
        leaderboards = photo_manager.get_leaderboards()
        
        total_submissions = len(all_photos)
        total_users = len(set(photo['name'] for photo in all_photos.values()))
        
        # Get top scorers for each category
        def get_top_entry(category):
            entries = leaderboards.get(category, [])
            if entries:
                top_entry = entries[0]  # First entry is highest ranked
                photo_info = photo_manager.get_photo_info(top_entry['unique_id'])
                if photo_info:
                    # Create entry with proper attribute naming to match template expectations
                    entry_data = {
                        'person_name': photo_info['name'],
                        'nationality': photo_info['nationality'],
                        'score': top_entry['score'],
                        'unique_id': top_entry['unique_id']
                    }
                    
                    # Add specific score fields based on category for template compatibility
                    if category == 'overall':
                        entry_data['overall_score'] = top_entry['score']
                    elif category == 'length':
                        entry_data['hair_length_score'] = top_entry['score']
                    elif category == 'thickness':
                        entry_data['hair_thickness_score'] = top_entry['score']  
                    elif category == 'silkiness':
                        entry_data['hair_silkiness_score'] = top_entry['score']
                        
                    return entry_data
            return None
        
        stats = {
            'total_submissions': total_submissions,
            'total_users': total_users,
            'top_length': get_top_entry('length'),
            'top_thickness': get_top_entry('thickness'),
            'top_silkiness': get_top_entry('silkiness'),
            'top_overall': get_top_entry('overall')
        }
        
        return render_template('index.html', stats=stats)
        
    except Exception as e:
        logger.error(f"Error loading index page: {str(e)}")
        return render_template('index.html', stats={})

@app.route('/leaderboard')
@app.route('/leaderboard/<category>')
def leaderboard(category='all'):
    """Display leaderboards - show all categories by default or specific category"""
    try:
        valid_categories = ['length', 'thickness', 'silkiness', 'overall', 'all']
        if category not in valid_categories:
            category = 'all'
        
        category_titles = {
            'length': '📏 Longest Hair',
            'thickness': '🧵 Thickest Hair', 
            'silkiness': '🫧 Silkiest Hair',
            'overall': '👑 Overall Hair Queen',
            'all': '🏆 All Categories'
        }
        
        leaderboards = photo_manager.get_leaderboards()
        
        if category == 'all':
            # Get top entries from each category for comprehensive view
            all_categories_data = {}
            categories_order = ['overall', 'length', 'thickness', 'silkiness']
            
            for cat in categories_order:
                # Get entries and add photo info
                entries = []
                for entry in leaderboards.get(cat, [])[:10]:  # Top 10 for each category
                    photo_info = photo_manager.get_photo_info(entry['unique_id'])
                    if photo_info and photo_manager.photo_exists(entry['unique_id']):
                        # Create entry object similar to database format
                        entry_obj = {
                            'Leaderboard': {
                                'rank': entry['rank'],
                                'score': entry['score']
                            },
                            'Submission': {
                                'unique_id': entry['unique_id'],
                                'person_name': photo_info['name'],
                                'nationality': photo_info['nationality'],
                                'photo_filename': f"{entry['unique_id']}.jpg",
                                'created_at': photo_info.get('timestamp', ''),
                                'get_short_id': lambda: photo_manager.get_short_id(entry['unique_id'])
                            },
                            'User': {
                                'username': photo_info['name']  # Using name as username
                            }
                        }
                        entries.append(entry_obj)
                
                all_categories_data[cat] = {
                    'title': category_titles[cat],
                    'entries': entries
                }
            
            return render_template('leaderboard_all.html',
                                 all_categories=all_categories_data,
                                 categories_order=categories_order,
                                 current_category='all',
                                 categories=valid_categories,
                                 category_titles=category_titles)
        else:
            # Single category view
            entries = []
            for entry in leaderboards.get(category, [])[:50]:  # Top 50 for single category
                photo_info = photo_manager.get_photo_info(entry['unique_id'])
                if photo_info and photo_manager.photo_exists(entry['unique_id']):
                    # Create entry object similar to database format
                    entry_obj = {
                        'Leaderboard': {
                            'rank': entry['rank'],
                            'score': entry['score']
                        },
                        'Submission': {
                            'unique_id': entry['unique_id'],
                            'person_name': photo_info['name'],
                            'nationality': photo_info['nationality'],
                            'photo_filename': f"{entry['unique_id']}.jpg",
                            'created_at': photo_info.get('timestamp', ''),
                            'get_short_id': lambda: photo_manager.get_short_id(entry['unique_id'])
                        },
                        'User': {
                            'username': photo_info['name']
                        }
                    }
                    entries.append(entry_obj)
            
            return render_template('leaderboard.html', 
                                 entries=entries,
                                 current_category=category,
                                 category_title=category_titles[category],
                                 categories=valid_categories,
                                 category_titles=category_titles)
        
    except Exception as e:
        logger.error(f"Error loading leaderboard: {str(e)}")
        return render_template('leaderboard.html', 
                             entries=[],
                             current_category=category,
                             category_title='Leaderboard',
                             categories=['length', 'thickness', 'silkiness', 'overall', 'all'],
                             category_titles=category_titles)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    """Serve uploaded files"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/submission/<unique_id>')
def view_submission(unique_id):
    """View individual submission by unique_id"""
    try:
        photo_info = photo_manager.get_photo_info(unique_id)
        if not photo_info or not photo_manager.photo_exists(unique_id):
            return render_template('submission.html', submission=None, error="Submission not found"), 404
        
        # Create submission object similar to database format
        submission = {
            'unique_id': unique_id,
            'person_name': photo_info['name'],
            'nationality': photo_info['nationality'],
            'photo_filename': f"{unique_id}.jpg",
            'created_at': photo_info.get('timestamp', ''),
            'hair_length_score': photo_info['scores'].get('hair_length_score', 0),
            'hair_thickness_score': photo_info['scores'].get('hair_thickness_score', 0),
            'hair_silkiness_score': photo_info['scores'].get('hair_silkiness_score', 0),
            'overall_score': photo_info['scores'].get('overall_score', 0),
            'get_short_id': lambda: photo_manager.get_short_id(unique_id)
        }
        
        return render_template('submission.html', submission=submission)
        
    except Exception as e:
        logger.error(f"Error loading submission {unique_id}: {str(e)}")
        return render_template('submission.html', submission=None, error="Error loading submission"), 500

@app.route('/api/stats')
def api_stats():
    """API endpoint for statistics"""
    try:
        all_photos = photo_manager.get_all_photos()
        leaderboards = photo_manager.get_leaderboards()
        
        total_submissions = len(all_photos)
        total_users = len(set(photo['name'] for photo in all_photos.values()))
        
        # Average scores
        if all_photos:
            avg_length = sum(photo['scores'].get('hair_length_score', 0) for photo in all_photos.values()) / len(all_photos)
            avg_thickness = sum(photo['scores'].get('hair_thickness_score', 0) for photo in all_photos.values()) / len(all_photos)
            avg_silkiness = sum(photo['scores'].get('hair_silkiness_score', 0) for photo in all_photos.values()) / len(all_photos)
            avg_overall = sum(photo['scores'].get('overall_score', 0) for photo in all_photos.values()) / len(all_photos)
        else:
            avg_length = avg_thickness = avg_silkiness = avg_overall = 0
        
        return jsonify({
            'total_submissions': total_submissions,
            'total_users': total_users,
            'average_scores': {
                'length': round(avg_length, 1),
                'thickness': round(avg_thickness, 1),
                'silkiness': round(avg_silkiness, 1),
                'overall': round(avg_overall, 1)
            },
            'leaderboard_counts': {
                'overall': len(leaderboards.get('overall', [])),
                'length': len(leaderboards.get('length', [])),
                'thickness': len(leaderboards.get('thickness', [])),
                'silkiness': len(leaderboards.get('silkiness', []))
            }
        })
        
    except Exception as e:
        logger.error(f"Error getting API stats: {str(e)}")
        return jsonify({'error': 'Unable to load statistics'}), 500

@app.route('/cleanup')
def cleanup_photos():
    """Manual cleanup endpoint for unused photos"""
    try:
        deleted_count = photo_manager.cleanup_unused_photos()
        return jsonify({
            'success': True,
            'deleted_count': deleted_count,
            'message': f'Cleaned up {deleted_count} unused photos'
        })
    except Exception as e:
        logger.error(f"Error during cleanup: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)