import cv2
import numpy as np
import logging
# MediaPipe temporarily disabled due to compatibility issues
mp = None
from scipy import ndimage
try:
    from skimage.feature import local_binary_pattern, graycomatrix, graycoprops
except ImportError:
    # If scikit-image is not available, define placeholder functions
    def local_binary_pattern(image, P, R, method='uniform'):
        return np.zeros_like(image)
    def graycomatrix(image, distances, angles, levels=256, symmetric=False, normed=False):
        return np.zeros((levels, levels, len(distances), len(angles)))
    def graycoprops(P, prop):
        return np.array([[0.5]])
from Color_detector import get_hair_color_and_vibrancy, get_dominant_hair_color_rgb # Import the functions from the other file
from glamorous_color_names import rgb_to_glamorous_name, get_dye_suggestion, get_color_personality_message
from hairstyle_detector import HairStyleDetector
from hair_care_advisor import HairCareAdvisor

# Import the new AI Hair Analyzer
try:
    from ai_hair_analyzer import ai_hair_analyzer
    AI_ENABLED = True
except ImportError as e:
    AI_ENABLED = False

logger = logging.getLogger(__name__)

# Define the detect_body_landmarks function (as implemented previously)
def detect_body_landmarks(image_path):
    """
    Detects body landmarks (shoulders, waist, etc.) using MediaPipe Pose
    and estimates the visible body portion, and flags if the image is cropped.

    Returns:
        tuple: (pose_landmarks_list, visible_body_portion_estimate, is_cropped)
               pose_landmarks_list: A list of detected landmarks or None.
               visible_body_portion_estimate: A string ('full', 'half',
               'upper-cropped', 'undetermined') or a float representing the
               estimated visible body portion relative to upper body height.
               is_cropped: A boolean flag, True if likely cropped, False otherwise.
    """
    # MediaPipe is disabled, return default values
    if mp is None:
        return None, 'undetermined', True
    
    mp_pose = mp.solutions.pose
    # Correct usage of mp_pose.Pose
    with mp_pose.Pose(static_image_mode=True, min_detection_confidence=0.5) as pose:

        try:
            image = cv2.imread(image_path)
            if image is None:
                raise ValueError(f"Could not load image from {image_path}")

            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            results = pose.process(image_rgb)

            visible_body_portion_estimate = 'undetermined'
            landmarks_list = None
            image_height = image.shape[0]
            is_cropped = False # Initialize the flag

            if results.pose_landmarks:
                landmarks = results.pose_landmarks.landmark
                landmarks_list = [(lmk.x, lmk.y, lmk.z) for lmk in landmarks]

                # Get relevant landmarks
                left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER]
                right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER]
                left_hip = landmarks[mp_pose.PoseLandmark.LEFT_HIP]
                right_hip = landmarks[mp_pose.PoseLandmark.RIGHT_HIP]
                # nose = landmarks[mp_pose.PoseLandmark.NOSE] # Not used in current estimation logic


                shoulder_y = (left_shoulder.y + right_shoulder.y) / 2.0
                hip_y = (left_hip.y + right_hip.y) / 2.0

                # Check if hips are visible (assuming y-coordinates increase downwards)
                are_hips_visible = hip_y > shoulder_y and hip_y < 1.0

                if are_hips_visible:
                    # Estimate visible portion based on hip position relative to image bottom
                    # If hip is near the bottom (y close to 1.0), assume full upper body visible
                    # If hip is higher up, it's a cropped view.
                    # Estimate based on hip_y position relative to shoulder_y and image bottom
                    # Range from shoulder_y to 1.0 represents potential full upper body span below shoulders

                    # Visible range below shoulders is (1.0 - shoulder_y)
                    # Portion of that range covered by visible hips is (hip_y - shoulder_y)
                    if (1.0 - shoulder_y) > 1e-6: # Avoid division by zero
                         visible_portion_below_shoulders = (hip_y - shoulder_y) / (1.0 - shoulder_y)
                         # Cap at 1.0, minimum can be 0 if hip_y <= shoulder_y
                         visible_body_portion_estimate = max(0.0, min(1.0, visible_portion_below_shoulders))
                         if visible_body_portion_estimate > 0.8:
                             visible_body_portion_estimate = 'full'
                         elif visible_body_portion_estimate > 0.4:
                              visible_body_portion_estimate = 'half' # Upper half visible
                         else:
                              visible_body_portion_estimate = 'upper-cropped' # Only head/shoulders

                    else: # Shoulders are very low or at bottom, unlikely scenario but handle it
                        visible_body_portion_estimate = 'undetermined'


                elif shoulder_y < 1.0: # Shoulders visible, but hips are not
                    # Assume upper body is visible up to the shoulders
                    # If shoulders are relatively low in the frame, might be 'upper-cropped'
                    # If shoulders are high, might be 'full' (though hips are missing)
                    # Use shoulder_y position relative to image top (0.0)
                    # If shoulder_y is small, it's likely a full upper body shot, hips just not detected
                    # If shoulder_y is large (closer to 1.0), it's likely 'upper-cropped'

                    # This is more ambiguous. Let's use a threshold.
                    # If shoulders are in the top ~40% of the image, assume potential 'full'
                    if shoulder_y < 0.4:
                         visible_body_portion_estimate = 'half' # Best guess, maybe 'full'
                    else:
                         visible_body_portion_estimate = 'upper-cropped' # Likely only head/shoulders

                else: # Shoulders not visible or at bottom
                     visible_body_portion_estimate = 'undetermined'

            # Set the is_cropped flag based on the estimate
            if visible_body_portion_estimate in ['upper-cropped', 'undetermined']:
                is_cropped = True
            else:
                is_cropped = False


            return landmarks_list, visible_body_portion_estimate, is_cropped

        except Exception as e:
            logger.error(f"Error in body landmark detection: {str(e)}")
            return None, 'undetermined', True # Assume cropped/undetermined on error


class HairAnalyzer:
    def __init__(self):
        """Initialize the hair analyzer with face detection and advanced features"""
        # Initialize face detection cascade
        try:
            import os
            # Try to get haarcascade path from cv2.data if available
            if hasattr(cv2, 'data') and hasattr(cv2.data, 'haarcascades'):
                cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            else:
                # Fallback paths for different OpenCV installations
                possible_paths = [
                    '/usr/share/opencv4/haarcascades/haarcascade_frontalface_default.xml',
                    '/usr/local/share/opencv4/haarcascades/haarcascade_frontalface_default.xml',
                    '/opt/homebrew/share/opencv4/haarcascades/haarcascade_frontalface_default.xml'
                ]
                cascade_path = None
                for path in possible_paths:
                    if os.path.exists(path):
                        cascade_path = path
                        break
                if cascade_path is None:
                    # Last resort: try without path specification
                    cascade_path = 'haarcascade_frontalface_default.xml'
            
            self.face_cascade = cv2.CascadeClassifier(cascade_path)
            
            # Verify the cascade loaded correctly
            if self.face_cascade.empty():
                logger.warning("Face cascade failed to load, face detection may not work")
                
        except Exception as e:
            logger.warning(f"Could not load face cascade: {e}, face detection may not work")
            self.face_cascade = cv2.CascadeClassifier()
        
        # Initialize advanced analysis components
        self.hairstyle_detector = HairStyleDetector()
        self.hair_care_advisor = HairCareAdvisor()

    def analyze_hair(self, image_path):
        """
        Analyze hair characteristics from an image and include body analysis
        Returns a dictionary with hair metrics and body analysis results
        """
        try:
            # Load image
            # Correct usage of cv2.imread
            image = cv2.imread(image_path)
            if image is None:
                raise ValueError("Could not load image")

            height, width = image.shape[:2]

            # Convert to different color spaces for analysis
            hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # Detect face to focus hair analysis
            faces = self.face_cascade.detectMultiScale(gray, 1.1, 4)

            # Call body detection function
            landmarks_list, visible_body_portion_estimate, is_cropped = detect_body_landmarks(image_path)

            # Define hair region (above face or full image if no face detected)
            if len(faces) > 0:
                hair_region_image = self._get_hair_region(image, faces[0])
            else:
                # If no face detected, analyze top 60% of image
                hair_region_image = image[:int(height * 0.6), :]

            # Segment hair using the new method
            hair_mask = self._segment_hair(image, landmarks_list)

            # Refine hair_region_image using the mask if segmentation was successful
            if hair_mask is not None:
                 # Apply the mask to the original image to get the segmented hair region
                 # Ensure mask is the same size as the original image
                 if hair_mask.shape[:2] == image.shape[:2]:
                     hair_region_image = cv2.bitwise_and(image, image, mask=hair_mask)
                 else:
                     logger.warning("Hair mask shape mismatch, using original hair region.")
                     # Fallback to the initial hair region definition if mask shape is wrong

            # Detect hair bounding box from the segmented hair mask
            hair_bbox = self._detect_hair_bounding_box(hair_mask)

            # Analyze hair characteristics, passing body analysis results and bbox to _analyze_hair_length and _analyze_hair_thickness
            length_score = self._analyze_hair_length(hair_region_image, visible_body_portion_estimate, is_cropped, height, hair_bbox, landmarks_list) # Pass landmarks
            thickness_score = self._analyze_hair_thickness(hair_region_image, hair_bbox)
            silkiness_score = self._analyze_hair_silkiness(hair_region_image)
            texture_score = self._analyze_hair_texture(hair_region_image)

            # Enhanced AI-powered color analysis
            if AI_ENABLED:
                try:
                    ai_analysis = ai_hair_analyzer.analyze_hair_image(
                        image_path, 
                        hair_thickness=thickness_score/100, 
                        hair_health=silkiness_score/100
                    )
                    
                    if ai_analysis.get('analysis_success'):
                        # Use AI results for more accurate color analysis
                        hair_color_class = ai_analysis['color_category'] 
                        glamorous_color_name = ai_analysis['color_name']
                        ai_care_tips = ai_analysis['care_tips']
                        
                        # Generate enhanced messages
                        color_personality_message = f"Your {glamorous_color_name.lower()} is absolutely stunning! ✨"
                        dye_suggestion = f"With your {hair_color_class} base, you'd look amazing with complementary tones! 💫"
                        vibrancy_score = ai_analysis.get('confidence', 70)
                        
                        logger.info(f"AI analysis successful: {glamorous_color_name}")
                    else:
                        # Fall back to original method
                        raise Exception("AI analysis failed")
                        
                except Exception as e:
                    logger.warning(f"AI analysis failed, using fallback: {e}")
                    # Fallback to original color analysis
                    hair_color_class, vibrancy_score = get_hair_color_and_vibrancy(image_path)
                    r, g, b = get_dominant_hair_color_rgb(image_path)
                    
                    if r is not None and g is not None and b is not None:
                        glamorous_color_name = rgb_to_glamorous_name(r, g, b, hair_color_class)
                        color_personality_message = get_color_personality_message(glamorous_color_name, hair_color_class)
                        dye_suggestion = get_dye_suggestion(hair_color_class)
                    else:
                        glamorous_color_name = "Stunning Hair Color ✨"
                        color_personality_message = "Your hair color is absolutely gorgeous! ✨"
                        dye_suggestion = "You'd look amazing with any bold color choice! 💫"
            else:
                # Original color analysis method when AI is not available
                hair_color_class, vibrancy_score = get_hair_color_and_vibrancy(image_path)
                r, g, b = get_dominant_hair_color_rgb(image_path)
                
                if r is not None and g is not None and b is not None:
                    glamorous_color_name = rgb_to_glamorous_name(r, g, b, hair_color_class)
                    color_personality_message = get_color_personality_message(glamorous_color_name, hair_color_class)
                    dye_suggestion = get_dye_suggestion(hair_color_class)
                else:
                    glamorous_color_name = "Stunning Hair Color ✨"
                    color_personality_message = "Your hair color is absolutely gorgeous! ✨"
                    dye_suggestion = "You'd look amazing with any bold color choice! 💫"
            
            # Advanced hairstyle detection
            hairstyle_results = self.hairstyle_detector.detect_hairstyle(image_path)
            hairstyle = hairstyle_results.get('hairstyle', 'unknown')
            hairstyle_confidence = hairstyle_results.get('confidence', 0.5)
            hairstyle_message = self.hairstyle_detector.get_hairstyle_message(hairstyle, hairstyle_confidence)


            # Calculate overall score as weighted average
            overall_score = (
                length_score * 0.35 +     # Length is most visually important
                thickness_score * 0.25 +  # Thickness for fullness
                silkiness_score * 0.25 +  # Silkiness for health/quality
                texture_score * 0.15      # Texture as supporting factor
            )

            # Generate hair comment
            hair_comment = self._generate_hair_comment(length_score, thickness_score, silkiness_score)
            
            # Create comprehensive analysis results for hair care tips
            analysis_results = {
                'hair_silkiness_score': silkiness_score,
                'hair_thickness_score': thickness_score,
                'hair_length_score': length_score,
                'hair_texture_score': texture_score,
                'hairstyle': hairstyle,
                'hair_color_class': hair_color_class
            }
            
            # Generate enhanced personalized hair care tips
            if AI_ENABLED and 'ai_care_tips' in locals():
                # Use AI-powered care tips with enhanced personalization
                hair_care_tips = ai_care_tips
                
                # Format AI tips for message display
                formatted_tips = "🌟 **PERSONALIZED HAIR CARE PLAN** 🌟\n\n"
                
                formatted_tips += f"💧 **Shampoo Care:**\n{hair_care_tips['shampoo']}\n\n"
                formatted_tips += f"🧴 **Conditioning:**\n{hair_care_tips['conditioning']}\n\n"
                formatted_tips += f"✨ **Styling Tips:**\n{hair_care_tips['styling']}\n\n"
                formatted_tips += f"🔧 **Maintenance:**\n{hair_care_tips['maintenance']}\n\n"
                
                if hair_care_tips.get('products'):
                    formatted_tips += f"🛒 **Recommended Products:**\n• " + "\n• ".join(hair_care_tips['products'])
                
                logger.info("Using AI-powered hair care tips")
            else:
                # Fallback to original hair care advisor
                hair_care_tips = self.hair_care_advisor.get_personalized_tips(analysis_results)
                formatted_tips = self.hair_care_advisor.format_tips_for_message(hair_care_tips)


            return {
                'hair_length_score': length_score,
                'hair_thickness_score': thickness_score,
                'hair_silkiness_score': silkiness_score,
                'hair_texture_score': texture_score,
                'overall_score': overall_score,
                'image_width': width,
                'image_height': height,
                'hair_pixel_count': self._count_hair_pixels(hair_region_image),
                'visible_body_portion_estimate': visible_body_portion_estimate,
                'is_cropped': is_cropped,
                'body_landmarks': landmarks_list,
                'hair_bounding_box': hair_bbox,
                'hair_comment': hair_comment,
                'hair_color_class': hair_color_class,
                'hair_vibrancy_score': vibrancy_score,
                # New advanced features
                'glamorous_color_name': glamorous_color_name,
                'color_personality_message': color_personality_message,
                'dye_suggestion': dye_suggestion,
                'hairstyle': hairstyle,
                'hairstyle_confidence': hairstyle_confidence,
                'hairstyle_message': hairstyle_message,
                'hair_care_tips': hair_care_tips,
                'formatted_care_tips': formatted_tips
            }

        except Exception as e:
            logger.error(f"Error analyzing hair: {str(e)}")
            return {
                'hair_length_score': 0.0,
                'hair_thickness_score': 0.0,
                'hair_silkiness_score': 0.0,
                'hair_texture_score': 0.0,
                'overall_score': 0.0,
                'image_width': 0,
                'image_height': 0,
                'hair_pixel_count': 0,
                'visible_body_portion_estimate': 'error',
                'is_cropped': True, # Assume cropped on error
                'body_landmarks': None,
                'hair_bounding_box': None,
                'hair_comment': 'Analysis failed.',
                'hair_color_class': None,
                'hair_vibrancy_score': None
            }

    # Remove unused function estimate_hair_thickness
    # import cv2
    # import numpy as np

    # def estimate_hair_thickness(image_path):
    #     """
    #     Estimate hair thickness based on how much horizontal space
    #     the hair takes up in the image.
    #     """
    #     img = cv2.imread(image_path)

    #     if img is None:
    #         print("Failed to read image.")
    #         return 0

    #     gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    #     # Assume hair is dark – adjust threshold as needed
    #     _, thresh = cv2.threshold(gray, 60, 255, cv2.THRESH_BINARY_INV)

    #     # Morph operations to reduce noise
    #     kernel = np.ones((5, 5), np.uint8)
    #     closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    #     # Find largest contour (likely hair mass)
    #     contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    #     if not contours:
    #         print("No contours found.")
    #         return 0

    #     # Largest blob = hair
    #     hair_contour = max(contours, key=cv2.contourArea)
    #     x, y, w, h = cv2.boundingRect(hair_contour)

    #     # Thickness is width of hair region relative to image width
    #     thickness_ratio = w / img.shape[1]
    #     thickness_score = round(thickness_ratio * 100, 2)

    #     return thickness_score

    def _get_hair_region(self, image, face_rect):
        """Extract hair region based on detected face"""
        x, y, w, h = face_rect

        # Hair region is typically above the face
        hair_y_start = max(0, y - int(h * 0.5))
        hair_y_end = y + int(h * 0.2)  # Include some forehead
        hair_x_start = max(0, x - int(w * 0.3))
        hair_x_end = min(image.shape[1], x + w + int(w * 0.3))

        return image[hair_y_start:hair_y_end, hair_x_start:hair_x_end]

    def _segment_hair(self, image, landmarks_list=None):
        """
        Segments the hair region from the image using color-based segmentation
        and morphology, optionally refined by body landmarks.

        Args:
            image (np.ndarray): The input image (BGR format).
            landmarks_list (list, optional): List of detected body landmarks. Defaults to None.

        Returns:
            np.ndarray: A binary mask of the segmented hair region (255 for hair, 0 for background),
                        or None if segmentation fails.
        """
        try:
            hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
            height, width = image.shape[:2]

            # Define a broad range for hair colors in HSV (adjust as needed)
            # This is a basic starting point and may need significant tuning
            # Lower bound (Hue, Saturation, Value)
            lower_hair_color = np.array([0, 20, 20])
            # Upper bound (Hue, Saturation, Value)
            upper_hair_color = np.array([180, 255, 200]) # Broad range for various hair colors

            # Create a mask based on the color range
            color_mask = cv2.inRange(hsv, lower_hair_color, upper_hair_color)

            # Apply morphological operations to refine the mask
            kernel_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
            kernel_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))

            mask_opened = cv2.morphologyEx(color_mask, cv2.MORPH_OPEN, kernel_open)
            mask_closed = cv2.morphologyEx(mask_opened, cv2.MORPH_CLOSE, kernel_close)

            # Skip landmark-based refinement since MediaPipe is disabled
            # Use the color mask as the final mask
            final_mask = mask_closed

            # Clean up small noise and fill small holes
            kernel_final_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
            kernel_final_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (10, 10))
            final_mask = cv2.morphologyEx(final_mask, cv2.MORPH_OPEN, kernel_final_open)
            final_mask = cv2.morphologyEx(final_mask, cv2.MORPH_CLOSE, kernel_final_close)


            return final_mask

        except Exception as e:
            logger.error(f"Error in hair segmentation: {str(e)}")
            return None

    def _detect_hair_bounding_box(self, hair_mask):
        """
        Detects the bounding box around the segmented hair region.

        Args:
            hair_mask (np.ndarray): A binary mask of the segmented hair region.

        Returns:
            tuple: (x, y, w, h) of the bounding box, or None if no hair is detected.
        """
        try:
            if hair_mask is None:
                return None

            # Find contours in the hair mask
            contours, _ = cv2.findContours(hair_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            if not contours:
                return None

            # Combine all contours to find the bounding box of the entire hair region
            combined_contours = np.concatenate(contours)
            x, y, w, h = cv2.boundingRect(combined_contours)

            return (x, y, w, h)

        except Exception as e:
            logger.error(f"Error detecting hair bounding box: {str(e)}")
            return None


    def _analyze_hair_length(self, hair_region, visible_body_portion_estimate, is_cropped, image_height, hair_bbox, landmarks_list=None):
        """
        Analyze hair length with advanced computer vision techniques,
        adjusting based on visible body portion if available, using the bounding box
        and body landmarks for reference points.
        Returns score 0-100.
        """
        try:
            hair_length_pixels = 0
            if hair_bbox is not None:
                _, _, _, h = hair_bbox
                hair_length_pixels = h
            else:
                 # Fallback if bbox detection failed
                 gray = cv2.cvtColor(hair_region, cv2.COLOR_BGR2GRAY)
                 height, width = gray.shape # Height of the hair region


                 # Multiple edge detection approaches for better accuracy
                 edges1 = cv2.Canny(gray, 30, 100)
                 edges2 = cv2.Canny(gray, 50, 150)
                 edges3 = cv2.Canny(gray, 70, 200)

                 # Combine edge maps
                 combined_edges = cv2.bitwise_or(edges1, cv2.bitwise_or(edges2, edges3))

                 # Morphological operations to enhance hair strands
                 kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2, 5))
                 enhanced_edges = cv2.morphologyEx(combined_edges, cv2.MORPH_CLOSE, kernel)

                 # analyze vertical hair distribution
                 vertical_projection = np.sum(enhanced_edges, axis=1)

                 # Smooth the projection
                 smoothed = ndimage.gaussian_filter1d(vertical_projection, sigma=2)

                 # Find significant hair regions (above threshold)
                 threshold = np.max(smoothed) * 0.2
                 hair_rows = np.where(smoothed > threshold)[0]

                 if len(hair_rows) > 5:
                     # Calculate the span of hair
                     hair_span = hair_rows[-1] - hair_rows[0]

                     # Look for continuous hair regions
                     diff = np.diff(hair_rows)
                     gaps = np.where(diff > 5)[0]  # Find gaps larger than 5 pixels

                     if len(gaps) > 0:
                         # Take the longest continuous segment
                         segments = np.split(hair_rows, gaps + 1)
                         longest_segment = max(segments, key=len)
                         if len(longest_segment) > 0:
                             hair_length_pixels = longest_segment[-1] - longest_segment[0]
                     else:
                         hair_length_pixels = hair_span


            # Calculate relative score based on image dimensions and realistic hair lengths
            if hair_length_pixels > 0:
                effective_height = image_height # Default to full image height

                # Use body landmarks as a reference for realistic length estimation
                if landmarks_list is not None and len(landmarks_list) > 0 and mp is not None:
                     mp_pose = mp.solutions.pose
                     left_shoulder = landmarks_list[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
                     right_shoulder = landmarks_list[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
                     left_hip = landmarks_list[mp_pose.PoseLandmark.LEFT_HIP.value]

                     shoulder_y_px = int(((left_shoulder[1] + right_shoulder[1]) / 2.0) * image_height)
                     hip_y_px = int(left_hip[1] * image_height) # Using left hip as reference

                     # Determine reference length based on landmark positions
                     # Distance from shoulders to hips is a better reference than overall image height
                     shoulder_to_hip_distance = abs(hip_y_px - shoulder_y_px)

                     # Use shoulder_to_hip_distance as a key reference for length scaling
                     # If hair extends significantly below hips, it's long
                     # If hair is around shoulder level, it's medium
                     # If hair is above shoulders, it's short

                     # Adjust length_ratio based on hair_length_pixels relative to shoulder_to_hip_distance
                     if shoulder_to_hip_distance > 1e-6:
                         # Calculate the hair length relative to the shoulder-to-hip distance
                         # We need to know where the bottom of the hair is relative to shoulders/hips
                         # Assuming hair_bbox y is the top and y+h is the bottom
                         if hair_bbox is not None:
                             _, hair_bbox_y, _, hair_bbox_h = hair_bbox
                             hair_bottom_y_px = hair_bbox_y + hair_bbox_h
                         else:
                              # Fallback: estimate hair bottom based on the hair_region height
                              # This is less accurate, assumes hair region starts above head
                              # and extends downwards within the region.
                              # This fallback is only used if bbox failed.
                              hair_bottom_y_px = image_height # Worst case, assume hair extends to bottom

                         # Calculate hair length from shoulders downwards
                         # The relevant length is from the shoulders to the bottom of the hair
                         effective_hair_length_from_shoulders = max(0, hair_bottom_y_px - shoulder_y_px)

                         # Normalize this effective length by shoulder-to-hip distance
                         length_ratio_relative_to_body = effective_hair_length_from_shoulders / shoulder_to_hip_distance

                         # Improved scoring based on length_ratio_relative_to_body
                         # Better thresholds for more accurate classification
                         if length_ratio_relative_to_body < 0.2: # Short (above shoulders)
                             length_score = length_ratio_relative_to_body * 150 # 0-30
                         elif length_ratio_relative_to_body < 0.8: # Medium (shoulder to mid-back)
                             length_score = 30 + (length_ratio_relative_to_body - 0.2) * 66.67 # 30-70
                         elif length_ratio_relative_to_body < 1.5: # Long (mid-back to waist)
                             length_score = 70 + (length_ratio_relative_to_body - 0.8) * 42.86 # 70-100
                         else: # Very Long (below waist)
                             length_score = 100 # Cap at 100

                         # Further adjustments based on is_cropped and visible_body_portion_estimate
                         # If image is cropped and only upper body visible, and hair is long relative to visible part, it's truly long.
                         # If image is full body and hair is short relative to full body, it's short.
                         # The landmark-based ratio helps normalize across different framing,
                         # but the 'is_cropped' and 'visible_body_portion_estimate' can add confidence.

                         if is_cropped:
                              if visible_body_portion_estimate == 'upper-cropped':
                                   # If upper-cropped and calculated length is medium/long, boost confidence.
                                   if length_score > 30:
                                        length_score = min(100, length_score * 1.1) # Slight boost
                              elif visible_body_portion_estimate == 'half':
                                   # If half body and calculated length is long, boost confidence.
                                   if length_score > 70:
                                       length_score = min(100, length_score + 5) # Moderate boost
                         else: # Not cropped or 'full' body
                              # If full body and hair is short/medium, the score should reflect that accurately.
                              # No additional bonus needed, the ratio handles this.
                              pass # No adjustment needed for full body/not cropped as landmark ratio is reliable

                     else:
                         # Fallback if shoulder-to-hip distance is zero (unlikely with good detection)
                         # Use the ratio relative to image height as a less reliable estimate
                         length_ratio_adjusted = hair_length_pixels / effective_height

                         # Apply previous scoring logic based on image height ratio
                         if length_ratio_adjusted < 0.05:  # Very short hair
                             length_score = length_ratio_adjusted * 400  # 0-20 score
                         elif length_ratio_adjusted < 0.15:  # Short hair
                              length_score = 20 + (length_ratio_adjusted - 0.05) * 300 # 20-50 score
                         elif length_ratio_adjusted < 0.3:  # Medium hair (mid-back)
                             length_score = 50 + (length_ratio_adjusted - 0.15) * 200  # 50-80 score
                         elif length_ratio_adjusted < 0.6:  # Long hair
                             length_score = 80 + (length_ratio_adjusted - 0.3) * 66.67  # 80-100 score
                         else:  # Very long hair
                             length_score = 100 # Cap at 100

                else:
                     # If no landmarks, use the ratio relative to image height as the only estimate
                     length_ratio_adjusted = hair_length_pixels / effective_height

                     # Improved scoring logic based on image height ratio
                     if length_ratio_adjusted < 0.1:  # Very short hair
                         length_score = length_ratio_adjusted * 300  # 0-30 score
                     elif length_ratio_adjusted < 0.25:  # Short hair
                          length_score = 30 + (length_ratio_adjusted - 0.1) * 266.67 # 30-70 score
                     elif length_ratio_adjusted < 0.5:  # Medium to long hair
                         length_score = 70 + (length_ratio_adjusted - 0.25) * 120  # 70-100 score
                     else:  # Very long hair
                         length_score = 100 # Cap at 100

                     # If no landmarks, and image is cropped, the length estimate is less reliable.
                     # Apply a penalty if the score is very high, as it might be an overestimation due to cropping.
                     if is_cropped and length_score > 70:
                         length_score = max(50, length_score * 0.85) # Apply a moderate penalty


            else:
                length_score = 5  # Minimal score if no hair detected

            return float(max(0, min(100, length_score)))


        except Exception as e:
            logger.error(f"Error in hair length analysis: {str(e)}")
            # Return a default score that reflects uncertainty or inability to measure
            # A slightly lower score might be appropriate if body analysis failed.
            return 10.0  # Default score on error

    def _analyze_hair_thickness(self, hair_region, hair_bbox):
        """
        Analyze hair thickness using enhanced techniques including pixel density,
        contrast analysis, and thickness heatmap generation.
        Returns score 0-100
        """
        try:
            # Try enhanced thickness analysis first
            from enhanced_hair_analyzer import enhanced_analyzer
            
            enhanced_result = enhanced_analyzer.enhanced_thickness_analysis(hair_region)
            if enhanced_result and enhanced_result.get('confidence', 0) > 0.5:
                return enhanced_result['thickness_score']
            
        except ImportError:
            logger.info("Enhanced analyzer not available, using standard thickness analysis")
        except Exception as e:
            logger.warning(f"Enhanced thickness analysis failed: {e}, falling back to standard method")
        
        # Fallback to original method
        try:
            gray = cv2.cvtColor(hair_region, cv2.COLOR_BGR2GRAY)
            height, width = gray.shape

            horizontal_spread_pixels = 0
            if hair_bbox is not None:
                _, _, w, _ = hair_bbox
                horizontal_spread_pixels = w
            else:
                 horizontal_spread_pixels = width # Fallback


            # 1. Multi-scale texture analysis (including improved LBP)
            def calculate_lbp_variance(image, radius=1, n_points=8):
                """Calculate Local Binary Pattern and its variance"""
                lbp = np.zeros_like(image, dtype=np.uint8)
                for i in range(radius, image.shape[0]-radius):
                    for j in range(radius, image.shape[1]-radius):
                        center = image[i, j]
                        code = 0
                        # neighbors = [] # Unused variable
                        for k in range(n_points):
                            angle = 2 * np.pi * k / n_points
                            x = i + radius * np.cos(angle)
                            y = j + radius * np.sin(angle)

                            # Bilinear interpolation
                            x1, y1 = int(x), int(y)
                            x2, y2 = min(x1 + 1, image.shape[0] - 1), min(y1 + 1, image.shape[1] - 1)

                            if x1 >= 0 and y1 >= 0:
                                dx, dy = x - x1, y - y1
                                pixel_value = (image[x1, y1] * (1-dx) * (1-dy) +
                                             image[x2, y1] * dx * (1-dy) +
                                             image[x1, y2] * (1-dx) * dy +
                                             image[x2, y2] * dx * dy)

                                if pixel_value >= center:
                                    code |= 1 << k
                        lbp[i, j] = code

                if lbp.size > 0:
                    return np.var(lbp)
                else:
                    return 0.0


            # Calculate LBP variance at multiple scales
            lbp_variance_small = calculate_lbp_variance(gray, radius=1, n_points=8)
            lbp_variance_medium = calculate_lbp_variance(gray, radius=2, n_points=16)

            variance_scores = []
            for ksize in [(3, 3), (5, 5), (7, 7)]:
                 blurred = cv2.GaussianBlur(gray, ksize, 0)
                 kernel = np.ones((ksize[0]*2+1, ksize[1]*2+1), np.float32) / ((ksize[0]*2+1)*(ksize[1]*2+1)) # Larger kernel
                 mean = cv2.filter2D(blurred.astype(np.float32), -1, kernel)
                 sqr_mean = cv2.filter2D((blurred.astype(np.float32))**2, -1, kernel)
                 local_variance = sqr_mean - mean**2
                 avg_variance = np.mean(local_variance)
                 variance_scores.append(avg_variance)

            # 2. Improved Edge density analysis
            edges_canny = cv2.Canny(gray, 60, 180) # Tighter thresholds

            sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=5) # Larger kernel
            sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=5)
            sobel_magnitude = np.sqrt(sobel_x**2 + sobel_y**2)

            # Analyze distribution of edge magnitudes
            edge_magnitude_mean = np.mean(sobel_magnitude)
            # edge_magnitude_std = np.std(sobel_magnitude) # Unused variable

            # 3. Hair strand analysis (refined contour filtering)
            contours, _ = cv2.findContours(edges_canny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            hair_strand_count = 0
            total_strand_area = 0
            strand_aspect_ratios = []

            for contour in contours:
                area = cv2.contourArea(contour)
                perimeter = cv2.arcLength(contour, True)

                if area > 20 and perimeter > 30:  # Increased minimum size
                    x, y, w, h = cv2.boundingRect(contour)
                    aspect_ratio = max(w, h) / (min(w, h) + 1e-6) if (min(w, h) + 1e-6) > 0 else 0 # Avoid div by zero

                    # Hair strands tend to be elongated and not too wide
                    if aspect_ratio > 3 and area < height * width * 0.05 and w < width * 0.2:
                        hair_strand_count += 1
                        total_strand_area += area
                        strand_aspect_ratios.append(aspect_ratio)

            avg_strand_aspect_ratio = np.mean(strand_aspect_ratios) if strand_aspect_ratios else 0

            # 4. Pixel intensity histogram analysis
            hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
            hist_norm = hist / np.sum(hist)

            # Analyze darkness distribution - thicker hair might be darker
            dark_pixel_ratio = np.sum(hist_norm[:50]) # Pixels in the dark range
            mid_tone_contrast = np.sum(hist_norm[50:200] * np.arange(150)) # Contrast in mid-tones

            # 5. Calculate thickness score based on multiple factors
            variance_score = np.mean(variance_scores) / 300  # Normalized
            lbp_score = (100 - min(100, (lbp_variance_small + lbp_variance_medium) / 10)) # Lower LBP variance is smoother/thicker looking? Needs validation.
            edge_density_score = min(100.0, (np.sum(edges_canny > 0) / (height * width)) * 1500) # Higher density = more hair
            edge_magnitude_score = min(100.0, edge_magnitude_mean / 2) # Higher magnitude = more prominent hair edges

            strand_analysis_score = min(100.0, (hair_strand_count / (height * width) * 5000) + (total_strand_area / (height * width) * 200)) # Density and area of strands
            aspect_ratio_score = min(100.0, avg_strand_aspect_ratio * 5) # Higher aspect ratio might indicate individual strands

            intensity_score = min(100.0, dark_pixel_ratio * 200 + mid_tone_contrast * 0.5)

            horizontal_spread_score = min(100.0, (horizontal_spread_pixels / width) * 150) # Wider spread = thicker

            # Improved weighted combination for more accurate thickness assessment
            thickness_score = (
                variance_score * 0.08 +
                lbp_score * 0.08 +
                edge_density_score * 0.25 +  # Increased - more hair strands = thicker
                edge_magnitude_score * 0.12 +
                strand_analysis_score * 0.25 +  # Increased - strand count is key indicator
                aspect_ratio_score * 0.05 +
                intensity_score * 0.12 +  # Slightly increased - darkness matters for thickness
                horizontal_spread_score * 0.25  # Increased - physical width is most important
            )


            # Realistic scoring adjustments - refined thresholds
            if thickness_score < 10:  # Very thin/fine hair
                final_score = thickness_score * 1.5  # 0-15 range
            elif thickness_score < 30:  # Thin to medium hair
                final_score = 15 + (thickness_score - 10) * 1.75  # 15-50 range
            elif thickness_score < 60:  # Medium to thick hair
                final_score = 50 + (thickness_score - 30) * 1.5  # 50-95 range
            else:  # Very thick hair
                final_score = 95 + min((thickness_score - 60) * 0.2, 5.0)  # 95-100 range # Ensure float literal

            return float(max(5.0, min(100.0, final_score))) # Ensure float literals

        except Exception as e:
            logger.error(f"Error in hair thickness analysis: {str(e)}")
            return 20.0  # Default reasonable score

    def _analyze_hair_silkiness(self, hair_region):
        """
        Analyze hair silkiness using advanced smoothness, shine, and texture analysis
        with refined metrics and weighting.
        Returns score 0-100
        """
        try:
            gray = cv2.cvtColor(hair_region, cv2.COLOR_BGR2GRAY)
            height, width = gray.shape

            # Convert to Lab color space for better luminance analysis
            lab = cv2.cvtColor(hair_region, cv2.COLOR_BGR2LAB)
            l_channel = lab[:, :, 0]  # Luminance channel
            a_channel = lab[:, :, 1]  # Green-Magenta channel
            b_channel = lab[:, :, 2]  # Blue-Yellow channel


            # 1. Advanced smoothness analysis
            # Calculate multiple gradient measures
            grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=5) # Increased kernel size
            grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=5)
            magnitude = np.sqrt(grad_x**2 + grad_y**2)
            mean_magnitude = np.mean(magnitude)
            std_magnitude = np.std(magnitude) # Added standard deviation

            # Use Laplacian for detecting fine texture variations
            laplacian = cv2.Laplacian(gray, cv2.CV_64F)
            laplacian_var = np.var(laplacian)

            # Calculate structure tensor for directional smoothness
            sobel_x_smooth = cv2.GaussianBlur(grad_x**2, (7, 7), 0) # Increased kernel size
            sobel_y_smooth = cv2.GaussianBlur(grad_y**2, (7, 7), 0)
            sobel_xy_smooth = cv2.GaussianBlur(grad_x * grad_y, (7, 7), 0)

            # Calculate coherence (measure of how uniform the texture direction is)
            det = sobel_x_smooth * sobel_y_smooth - sobel_xy_smooth**2
            trace = sobel_x_smooth + sobel_y_smooth
            coherence = np.mean(np.sqrt(det) / (trace + 1e-6))

            # 2. Shine and highlight detection (refined)
            # Detect bright spots that indicate shine
            # Use adaptive thresholding to find highlights
            adaptive_thresh = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 21, -5 # Adjusted block size and C
            )

            # Count bright regions (potential shine areas) and analyze their properties
            contours_shine, _ = cv2.findContours(adaptive_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            shine_area_ratio = 0
            shine_count = len(contours_shine)
            shine_compactness_scores = [] # Added compactness

            for contour in contours_shine:
                area = cv2.contourArea(contour)
                perimeter = cv2.arcLength(contour, True)
                if perimeter > 0:
                     compactness = (4 * np.pi * area) / (perimeter**2) # Circle has compactness of 1
                     shine_compactness_scores.append(compactness)
                shine_area_ratio += area

            shine_area_ratio /= (height * width)
            avg_shine_compactness = np.mean(shine_compactness_scores) if shine_compactness_scores else 0


            # Analyze shine patterns using luminance channel
            # Calculate local standard deviation to detect shine variations
            kernel_size = 11 # Increased kernel size
            kernel = np.ones((kernel_size, kernel_size), np.float32) / (kernel_size**2)

            l_mean = cv2.filter2D(l_channel.astype(np.float32), -1, kernel)
            l_sqr_mean = cv2.filter2D((l_channel.astype(np.float32))**2, -1, kernel)
            l_variance = l_sqr_mean - l_mean**2

            # High variance in luminance indicates good shine distribution
            shine_variance = np.mean(l_variance)
            shine_variance_std = np.std(l_variance) # Added standard deviation

            # Analyze color channels for specific hair health indicators (less established, experimental)
            # Variance in 'a' and 'b' channels might relate to color uniformity/vibrancy
            a_variance = np.var(a_channel)
            b_variance = np.var(b_channel)


            # 3. Texture uniformity analysis (using refined LBP)
            def calculate_texture_uniformity(image, radius=1, n_points=8):
                """Calculate Local Binary Pattern and its entropy for texture uniformity"""
                lbp = np.zeros_like(image, dtype=np.uint8)

                for i in range(radius, image.shape[0] - radius):
                    for j in range(radius, image.shape[1] - radius):
                        center = image[i, j]
                        code = 0
                        # neighbors = [] # Unused variable
                        for k in range(n_points):
                            angle = 2 * np.pi * k / n_points
                            x = i + radius * np.cos(angle)
                            y = j + radius * np.sin(angle)

                            # Bilinear interpolation
                            x1, y1 = int(x), int(y)
                            x2, y2 = min(x1 + 1, image.shape[0] - 1), min(y1 + 1, image.shape[1] - 1)

                            if x1 >= 0 and y1 >= 0:
                                dx, dy = x - x1, y - y1
                                pixel_value = (image[x1, y1] * (1-dx) * (1-dy) +
                                             image[x2, y1] * dx * (1-dy) +
                                             image[x1, y2] * (1-dx) * dy +
                                             image[x2, y2] * dx * dy)

                                if pixel_value >= center:
                                    code |= 1 << k
                        lbp[i, j] = code

                if lbp.size > 0:
                    hist, _ = np.histogram(lbp.ravel(), bins=256, range=(0, 256))
                    hist = hist.astype(float)
                    hist = hist[hist > 0]
                    # Higher entropy indicates more texture variation (less silky)
                    entropy = -np.sum(hist * np.log2(hist / np.sum(hist))) if np.sum(hist) > 0 else 0
                    return entropy
                else:
                    return 0.0

            texture_entropy_medium = calculate_texture_uniformity(gray, radius=2, n_points=16)

            # 4. Edge coherence analysis (refined)
            edges = cv2.Canny(gray, 60, 180) # Tighter thresholds

            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            edge_smoothness_scores = []
            for contour in contours:
                if len(contour) > 15:  # Increased minimum length
                    epsilon = 0.01 * cv2.arcLength(contour, True) # Tighter approximation
                    approx = cv2.approxPolyDP(contour, epsilon, True)
                    smoothness = len(contour) / max(len(approx), 1)
                    edge_smoothness_scores.append(smoothness)

            avg_edge_smoothness = np.mean(edge_smoothness_scores) if edge_smoothness_scores else 1.0 # Default to 1.0 if no contours

            # 5. Calculate final silkiness score
            # Normalize individual metrics
            smoothness_score = max(0.0, 100.0 - float(mean_magnitude / 4.0))  # Lower mean gradient = smoother
            laplacian_score = max(0.0, 100.0 - float(laplacian_var / 150.0))  # Lower variance = smoother
            coherence_score = min(100.0, float(coherence * 1500.0))  # Higher coherence = more uniform structure

            # Shine scoring
            shine_area_score = min(100.0, float(shine_area_ratio * 800.0))  # Higher shine area is good
            shine_count_score = min(100.0, float(shine_count * 2.0)) # More shine spots can be good
            shine_compactness_score = min(100.0, float(avg_shine_compactness * 80.0)) # Compact, rounder shine spots are often desirable
            variance_shine_score = min(100.0, float(shine_variance / 15.0))  # Good shine distribution

            # Texture scoring
            texture_score = max(0.0, 100.0 - float(texture_entropy_medium / 4.0))  # Lower entropy = more uniform/silky texture
            edge_score = min(100.0, float(avg_edge_smoothness * 8.0))  # Smoother edges = more silky

            # Experimental: color channel variance (lower variance might suggest more uniform color, healthy hair)
            color_uniformity_score = max(0.0, 100.0 - float(a_variance/50.0 + b_variance/50.0))


            # Improved weighted combination for more accurate silkiness assessment
            silkiness_score = (
                smoothness_score * 0.25 + # Primary indicator of silkiness
                laplacian_score * 0.15 +   # Fine texture variations
                coherence_score * 0.20 +   # Structural uniformity - key for silkiness
                shine_area_score * 0.12 +  # Natural shine areas
                shine_count_score * 0.05 + # Added
                shine_compactness_score * 0.05 + # Added
                variance_shine_score * 0.10 +
                texture_score * 0.15 + # Increased weight
                edge_score * 0.05 +
                color_uniformity_score * 0.05 # Added (experimental)
            )

            # Apply realistic scoring adjustments - refined thresholds
            if silkiness_score < 10:  # Very rough/damaged hair
                final_score = silkiness_score * 0.8 # 0-8 range
            elif silkiness_score < 30:  # Somewhat rough hair
                final_score = 8 + (silkiness_score - 10) * 1.85 # 8-45 range
            elif silkiness_score < 65:  # Medium silkiness
                final_score = 45 + (silkiness_score - 30) * 1.57 # 45-100 range
            else:  # Very silky hair
                final_score = 100.0 # Cap at 100

            return float(max(5.0, min(100.0, final_score))) # Ensure float literals

        except Exception as e:
            logger.error(f"Error in hair silkiness analysis: {str(e)}")
            return 25.0  # Default reasonable score

    def _count_hair_pixels(self, hair_region):
        """Count approximate number of hair pixels"""
        gray = cv2.cvtColor(hair_region, cv2.COLOR_BGR2GRAY)

        # Use adaptive thresholding to segment hair
        thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                     cv2.THRESH_BINARY_INV, 15, 5) # Adjusted block size and C

        # Use morphological operations to clean up the mask
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        cleaned_thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
        cleaned_thresh = cv2.morphologyEx(cleaned_thresh, cv2.MORPH_CLOSE, kernel)


        # Count dark pixels (potential hair)
        hair_pixels = np.sum(cleaned_thresh > 0)

        return int(hair_pixels)

    def _analyze_hair_texture(self, hair_region):
        """
        Analyze hair texture using advanced pattern recognition and wavelet analysis
        Returns score 0-100
        """
        try:
            gray = cv2.cvtColor(hair_region, cv2.COLOR_BGR2GRAY)
            height, width = gray.shape

            # 1. Multi-scale texture analysis using Local Binary Patterns
            def local_binary_pattern(image, radius=3, n_points=24):
                """Calculate Local Binary Pattern for texture analysis"""
                lbp = np.zeros_like(image, dtype=np.uint8)

                for i in range(radius, image.shape[0] - radius):
                    for j in range(radius, image.shape[1] - radius):
                        center = image[i, j]
                        code = 0

                        # Sample points around the center
                        for k in range(n_points):
                            angle = 2 * np.pi * k / n_points
                            x = i + radius * np.cos(angle)
                            y = j + radius * np.sin(angle)

                            # Bilinear interpolation for sub-pixel accuracy
                            x1, y1 = int(x), int(y)
                            x2, y2 = min(x1 + 1, image.shape[0] - 1), min(y1 + 1, image.shape[1] - 1) # Added boundary check

                            if x1 >= 0 and y1 >= 0: # Added boundary check
                                dx, dy = x - x1, y - y1
                                pixel_value = (image[x1, y1] * (1-dx) * (1-dy) +
                                             image[x2, y1] * dx * (1-dy) +
                                             image[x1, y2] * (1-dx) * dy +
                                             image[x2, y2] * dx * dy)

                                if pixel_value >= center:
                                    code |= 1 << k

                        lbp[i, j] = code

                return lbp

            # Calculate LBP at multiple scales
            lbp_small = local_binary_pattern(gray, radius=1, n_points=8)
            lbp_medium = local_binary_pattern(gray, radius=2, n_points=16)
            lbp_large = local_binary_pattern(gray, radius=3, n_points=24)

            # 2. Wavelet-based texture analysis (using Gabor filters)
            def gabor_texture_analysis(image):
                """Analyze texture using Gabor filters"""
                gabor_responses = []

                # Multiple orientations and frequencies - added more frequencies
                for theta in [0, 45, 90, 135]:  # Degrees
                    for frequency in [0.1, 0.2, 0.3, 0.4, 0.5]: # Added more frequencies
                        kernel = cv2.getGaborKernel((21, 21), 5, np.radians(theta),
                                                  2*np.pi*frequency, 0.5, 0, ktype=cv2.CV_32F)
                        filtered = cv2.filter2D(image, cv2.CV_8UC3, kernel)
                        gabor_responses.append(np.mean(np.abs(filtered)))

                return gabor_responses

            gabor_features = gabor_texture_analysis(gray)

            # 3. Gray Level Co-occurrence Matrix (GLCM) features (added more directions)
            def glcm_features(image, distances=[1], angles=[0, np.pi/4, np.pi/2, 3*np.pi/4]): # Added more angles
                """Calculate GLCM texture features"""
                # Reduce gray levels for computational efficiency
                image_reduced = np.clip(image // 32, 0, 255).astype(np.uint8)  # 8 gray levels
                max_val = np.max(image_reduced) + 1

                # Calculate co-occurrence matrix
                glcm = graycomatrix(image_reduced, distances=distances, angles=angles, levels=max_val, symmetric=True, normed=True)

                # Calculate texture features
                contrast = graycoprops(glcm, 'contrast').mean()
                homogeneity = graycoprops(glcm, 'homogeneity').mean()
                energy = graycoprops(glcm, 'energy').mean()
                correlation = graycoprops(glcm, 'correlation').mean() # Added correlation
                dissimilarity = graycoprops(glcm, 'dissimilarity').mean() # Added dissimilarity

                return contrast, homogeneity, energy, correlation, dissimilarity

            try:
                contrast, homogeneity, energy, correlation, dissimilarity = glcm_features(gray)
            except NameError:
                # Fallback values if GLCM not available
                contrast, homogeneity, energy, correlation, dissimilarity = 0.5, 0.5, 0.5, 0.5, 0.5


            # 4. Edge density and orientation analysis (refined)
            edges = cv2.Canny(gray, 70, 200) # Tighter thresholds
            edge_density = np.sum(edges > 0) / (height * width)

            sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=5) # Increased kernel size
            sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=5)

            magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
            orientation = np.arctan2(sobel_y, sobel_x + 1e-10)

            # Calculate orientation uniformity using entropy
            orientation_hist, _ = np.histogram(orientation[magnitude > np.mean(magnitude)],
                                             bins=36, range=(-np.pi, np.pi))
            orientation_hist = orientation_hist.astype(float)
            orientation_hist = orientation_hist[orientation_hist > 0]
            orientation_entropy = -np.sum(orientation_hist * np.log2(orientation_hist / np.sum(orientation_hist))) if np.sum(orientation_hist) > 0 else 0

            orientation_uniformity = max(0.0, 100.0 - (float(orientation_entropy) / 4.0)) # Lower entropy is more uniform

            # 5. Fractal dimension estimation (refined)
            def box_counting_fractal(image, max_box_size=64):
                """Estimate fractal dimension using box counting"""
                # Threshold image - using Otsu's thresholding for better adaptability
                _, binary = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                binary = binary // 255 # Convert to 0 and 1

                scales = []
                counts = []

                # Increased range and smaller step for box sizes
                for box_size in range(2, min(max_box_size, min(height, width)//2), 1):
                    count = 0
                    for i in range(0, height - box_size + 1, box_size): # Ensure full coverage
                        for j in range(0, width - box_size + 1, box_size):
                            box = binary[i:i+box_size, j:j+box_size]
                            if np.sum(box) > 0:  # Box contains structure
                                count += 1

                    if count > 0:
                        scales.append(np.log(1.0 / box_size))
                        counts.append(np.log(count))

                if len(scales) > 1:
                    # Linear regression to find fractal dimension
                    fractal_dim = np.polyfit(scales, counts, 1)[0]
                    return abs(fractal_dim)
                else:
                    return 1.5  # Default value

            fractal_dimension = box_counting_fractal(gray)


            # 6. Combine features for texture scoring
            # Calculate individual scores
            lbp_variance = np.var(lbp_medium)
            lbp_score = max(0.0, 100.0 - min(100.0, float(lbp_variance) / 15.0))  # Lower variance = more uniform texture

            gabor_consistency = 100.0 - min(100.0, float(np.std(gabor_features)) * 30.0)  # More consistent response = specific texture pattern

            glcm_texture_score = (float(homogeneity) * 40.0) + (float(energy) * 30.0) + (100.0 - min(100.0, float(contrast) * 8.0)) + (float(correlation) * 20.0) + (max(0.0, 100.0 - float(dissimilarity) * 50.0)) # Weighted GLCM features

            edge_texture_score = min(100.0, edge_density * 1200.0) * (orientation_uniformity / 100.0) # Edge density * orientation uniformity

            fractal_score = max(0.0, 100.0 - min(100.0, float(abs(fractal_dimension - 1.8)) * 60.0))  # Adjust ideal fractal dimension and sensitivity

            # 7. Calculate final texture score - adjust weights based on testing
            texture_score = (
                lbp_score * 0.20 +
                gabor_consistency * 0.20 +
                glcm_texture_score * 0.30 + # Increased weight for GLCM
                edge_texture_score * 0.15 +
                fractal_score * 0.15
            )

            # Apply realistic scoring adjustments - refined thresholds
            if texture_score < 15:  # Very coarse/rough texture
                final_score = texture_score * 0.6 # 0-9 range
            elif texture_score < 35:  # Somewhat coarse texture
                final_score = 9 + (texture_score - 15) * 1.75 # 9-44 range
            elif texture_score < 70:  # Medium texture
                final_score = 44 + (texture_score - 35) * 1.6 # 44-100 range
            else:  # Very fine, smooth texture
                final_score = 100.0 # Cap at 100


            return float(max(5.0, min(100.0, final_score)))


        except Exception as e:
            logger.error(f"Error in hair texture analysis: {str(e)}")
            return 30.0  # Default reasonable score

    def _generate_hair_comment(self, length_score, thickness_score, silkiness_score, overall_score=None, color_vibrancy=None, hairstyle=None):
        """
        Generates a realistic comment about the hair based on the analysis scores.
        Uses the enhanced comment system for more natural responses.
        """
        try:
            # Try to use enhanced analyzer if available
            from enhanced_hair_analyzer import enhanced_analyzer
            
            analysis_result = {
                'hair_length_score': length_score,
                'hair_thickness_score': thickness_score,
                'hair_silkiness_score': silkiness_score,
                'overall_score': overall_score or ((length_score + thickness_score + silkiness_score) / 3),
                'color_vibrancy': color_vibrancy or 50,
                'hairstyle': hairstyle or 'unknown'
            }
            
            return enhanced_analyzer.generate_realistic_comment(analysis_result)
            
        except ImportError:
            # Fallback to original system if enhanced analyzer not available
            comment = ""

            # Comments based on length
            if length_score < 30:
                comment += "Your hair is quite short."
            elif length_score < 70:
                comment += "You have medium-length hair."
            else:
                comment += "You have long, beautiful hair!"

            # Comments based on thickness (adding to existing comment)
            if thickness_score < 30:
                comment += " It appears to be on the thinner side."
            elif thickness_score < 70:
                comment += " It has medium thickness."
            else:
                comment += " It is wonderfully thick and full."

            # Comments based on silkiness (adding to existing comment)
            if silkiness_score < 40:
                comment += " It could use some extra care for improved silkiness."
            elif silkiness_score < 75:
                comment += " It has a good level of silkiness."
            else:
                comment += " It's incredibly silky and smooth!"

            # Adding some motivational/aspirational comments based on combined scores
            if length_score < 50 and thickness_score > 60:
                 comment += " Great thickness, with potential to grow into magnificent long hair!"
            elif length_score > 80 and silkiness_score > 80:
                 comment += " Truly queen-like hair, long and incredibly silky!"
            elif length_score > 60 and length_score < 80 and thickness_score > 50:
                 comment += " Lovely mid-back length hair with good body."

            return comment.strip() # Remove leading/trailing whitespace