# Hair Analysis Bot

## Overview
The Hair Analysis Bot is a sophisticated Telegram bot complemented by a Flask web interface. Its primary purpose is to analyze hair characteristics from user-submitted photos using advanced computer vision and machine learning techniques. Key capabilities include sophisticated hair style detection, glamorous hair color naming, and personalized hair care recommendations. The project aims to provide a comprehensive, engaging, and personalized hair analysis experience, leveraging AI for beauty insights.

## User Preferences
- **Communication Style**: Beauty influencer personality with encouraging, fun messages
- **Technical Approach**: Computer vision over heavy ML for better performance
- **Message Format**: Multiple messages for better readability (analysis + tips)
- **Color Naming**: Glamorous, creative names over basic color descriptions

## System Architecture
The bot features a modular design, with each advanced capability implemented in separate, testable Python modules. It relies heavily on computer vision libraries like OpenCV and MediaPipe, deliberately avoiding heavy TensorFlow dependencies for better performance and lighter footprint. All data, including user authentication and analysis results, are stored in JSON files, eliminating the need for a traditional database (e.g., PostgreSQL).

### Core Features & Implementations:
- **Comprehensive Authentication & Access Control**: Features user registration with unique login codes, Telegram ID verification, admin password protection for sensitive commands, temporary admin sessions, and activity tracking. Authentication data is stored securely in JSON files.
- **AI-Enhanced Hair Analysis Engine**: Features advanced computer vision-based hair color detection using k-means clustering and HSV color classification. Provides accurate color identification (black, brown, blonde, red, etc.) with personalized hair care recommendations. Includes advanced thickness analysis using pixel density and contrast, improved braid detection via pattern recognition, and multi-scale texture analysis (LBP variance). The system prioritizes AI analysis with graceful fallback to traditional methods.
- **"Try This Look" Challenge System**: A complete framework for daily, weekly, and seasonal style challenges. It incorporates a computer vision-based style matching algorithm, a point system for rewards, and various challenge categories.
- **Smart Auto-Reply System**: Generates personalized recommendations based on hair analysis scores (thickness, silkiness, color). It provides targeted care advice, ranking-based responses, and achievement recognition.
- **Advanced Hair Style Detection**: Utilizes computer vision for classifying various hairstyles (e.g., ponytails, braids, curls, bobs) through texture analysis, edge detection, and pattern recognition. Each detected style is accompanied by personality-driven messages.
- **Glamorous Hair Color Names**: Replaces basic color names with sophisticated, beauty influencer-style alternatives (e.g., "Chestnut Chocolate Swirl") based on RGB-to-name mapping.
- **Hair Dye Suggestions**: AI-driven recommendations for complementary hair colors, delivered with a confident, emoji-rich personality.
- **Personalized Hair Care Tips**: Custom recommendations based on individual hair analysis scores, including solutions for priority issues, weekly routines, emergency fixes, and style-specific advice.
- **Enhanced Bot Learning Flow**: An interactive system allowing the bot to learn new hairstyles from user input. It detects unfamiliar styles, prompts users for names, and builds a dataset of user-taught hairstyles.
- **Enhanced Photo Management System**: Implements a "Top-3 Cleanup" system for leaderboards, automatically retaining only the best photos. Admins can manually trigger cleanup and dynamically create new leaderboard categories.
- **Enhanced AI Makeover System**: A robust virtual hairstyle overlay system with significant improvements to color handling, aspect ratio preservation, and image quality. Features proper BGR/RGB conversion, RGBA alpha channel support, PNG format saving, aspect-ratio preserving resize logic, comprehensive debug logging, and fallback error handling. Uses MediaPipe for segmentation and PIL for superior image processing.
- **Enhanced Admin Management System**: Provides direct access to admin functionalities via the `/admin` command, offering separate commands for cleanup, statistics, learning, leaderboard reset, dynamic category creation, and automated data cleanup (`/data_clean`).

### UI/UX Decisions:
- **Simplified Language**: Bot responses are designed to use everyday language, avoiding overly complex technical terms.
- **Clear Message Formatting**: Analysis results, tips, and scores are delivered in a comprehensive yet readable format, often split into multiple messages for clarity.
- **Personality-Driven Messaging**: All interactions are infused with an encouraging, beauty influencer-like tone.

## External Dependencies
- **Core Libraries**: `opencv-python`, `mediapipe`, `numpy`, `pillow`, `scipy` (for advanced filtering).
- **Bot Framework**: `python-telegram-bot`.
- **Web Framework**: `flask`, `gunicorn`.
- **Environment Variables**:
    - `TELEGRAM_BOT_TOKEN`: Required for Telegram API access.
    - `SESSION_SECRET`: Flask session secret key.