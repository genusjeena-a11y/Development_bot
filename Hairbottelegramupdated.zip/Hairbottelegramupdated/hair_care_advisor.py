"""
Personalized Hair Care Tips Based on Analysis Scores
Provides specific advice for different hair characteristics and weaknesses
"""

import numpy as np

class HairCareAdvisor:
    def __init__(self):
        self.care_tips = {
            'silkiness': {
                'low': [
                    "Dry ends? Coconut oil + silk pillowcase = game changer! 🥥✨",
                    "Try a deep conditioning mask 2x per week - your hair will thank you! 💆‍♀️",
                    "Argan oil before blow drying = instant silk upgrade! 🌟",
                    "Switch to sulfate-free shampoo for softer, silkier hair! 🧴",
                    "Cold water rinse at the end of your shower = instant shine boost! ❄️"
                ],
                'medium': [
                    "You're on the right track! Weekly hair masks will take you to the next level! 💫",
                    "Add a leave-in conditioner for that extra silky touch! ✨",
                    "Heat protectant is your best friend for maintaining that smoothness! 🛡️"
                ],
                'high': [
                    "Your hair is already silky perfection! Keep doing what you're doing! 👑",
                    "Maintain that silk with weekly oil treatments! 🌟",
                    "Your hair care routine is clearly working - you're glowing! ✨"
                ]
            },
            
            'thickness': {
                'low': [
                    "Volume boost time! Try a root lifting spray before styling! 🚀",
                    "Dry shampoo at the roots = instant volume magic! ✨",
                    "Consider a volumizing mousse - it's a game changer! 💨",
                    "Blow dry upside down for natural volume and lift! 🔄",
                    "Layer cuts can create the illusion of thicker hair! ✂️"
                ],
                'medium': [
                    "Your thickness is perfect! Maintain it with protein treatments! 💪",
                    "Regular trims keep your hair looking full and healthy! ✂️",
                    "You've got great natural volume - enhance it with the right products! 🌟"
                ],
                'high': [
                    "Thick hair queen! You're blessed with natural volume! 👑",
                    "Thinning shears can help manage that gorgeous thickness! ✂️",
                    "Your thick hair is a gift - embrace those voluminous styles! 💫"
                ]
            },
            
            'length': {
                'low': [
                    "Growing out your hair? Biotin supplements can help! 💊",
                    "Scalp massages stimulate growth - make it a daily ritual! 💆‍♀️",
                    "Protective styles at night = less breakage, more length! 🌙",
                    "Regular trims prevent split ends from traveling up! ✂️",
                    "Silk scrunchies > regular hair ties for length retention! 🎀"
                ],
                'medium': [
                    "Perfect length for versatile styling! Protect those ends! 🛡️",
                    "Your length is ideal - focus on maintaining healthy ends! ✨",
                    "Regular deep conditioning keeps medium hair looking luscious! 💧"
                ],
                'high': [
                    "Rapunzel vibes! Your long hair is absolutely stunning! 👑",
                    "Long hair care tip: Braid it before bed to prevent tangles! 🌙",
                    "Your length is goals - maintain it with gentle handling! ✨"
                ]
            },
            
            'texture': {
                'low': [
                    "Smooth texture goals! Sea salt spray can add some natural texture! 🌊",
                    "Texturizing spray before styling creates beautiful movement! 💨",
                    "Your smooth hair is perfect for sleek styles! ✨",
                    "Add some waves with braids overnight for texture variety! 🌙"
                ],
                'medium': [
                    "Perfect texture balance! Your hair has great natural movement! 💫",
                    "Enhance your natural texture with curl-defining cream! 🌀",
                    "Your texture is ideal for so many different styles! 🌟"
                ],
                'high': [
                    "Textured hair goddess! Your natural pattern is beautiful! 👑",
                    "Define those curls with leave-in conditioner and gel! 💧",
                    "Your texture is your superpower - embrace it! ⚡"
                ]
            }
        }
        
        self.hairstyle_specific_tips = {
            'curly': [
                "Curly girl method: No sulfates, no silicones, lots of moisture! 💧",
                "Plop your curls with a microfiber towel - no more frizz! 🌀",
                "Sleep on a satin pillowcase to maintain those gorgeous curls! ✨",
                "Scrunch, don't brush - your curls will love you for it! 💕"
            ],
            
            'straight': [
                "Heat protectant is NON-NEGOTIABLE for straight hair styling! 🛡️",
                "Cool shot button on your blow dryer = locks in that sleek look! ❄️",
                "Overnight braids give straight hair gorgeous waves! 🌙",
                "Dry shampoo adds texture and volume to fine straight hair! ✨"
            ],
            
            'wavy': [
                "Scrunch with mousse while damp for defined waves! 🌊",
                "Diffuse on low heat to enhance your natural wave pattern! 💨",
                "Sea salt spray is your best friend for beachy waves! 🏖️",
                "Don't brush when dry - it breaks up your wave pattern! 🚫"
            ],
            
            'ponytail': [
                "Silk scrunchies prevent breakage at the ponytail! 🎀",
                "Change your ponytail position daily to prevent dents! 🔄",
                "Tease at the crown for a fuller ponytail look! 👑",
                "Wrap a strand of hair around the elastic for a polished finish! ✨"
            ],
            
            'bun': [
                "Use bobby pins that match your hair color for seamless buns! 📎",
                "Texture spray before styling makes buns easier to create! 💨",
                "Don't pull too tight - your scalp will thank you! 💆‍♀️",
                "Donut buns create fuller, more voluminous updos! 🍩"
            ],
            
            'braids': [
                "Braid on slightly damp hair for longer-lasting styles! 💧",
                "Use texturizing spray for better grip and hold! 💨",
                "Sleep in loose braids for gorgeous waves the next day! 🌙",
                "Don't braid too tight - your edges need love too! 💕"
            ]
        }
        
        self.color_care_tips = {
            'blonde': [
                "Purple shampoo once a week keeps brassiness away! 💜",
                "UV protection is crucial for maintaining blonde tones! ☀️",
                "Deep conditioning weekly prevents blonde breakage! 💧",
                "Toner touch-ups keep your blonde looking fresh! ✨"
            ],
            
            'brown': [
                "Color-safe shampoo preserves your gorgeous brown tones! 🤎",
                "Gloss treatments add incredible shine to brown hair! ✨",
                "Cold water rinses prevent color fading! ❄️",
                "Regular trims keep brown hair looking vibrant! ✂️"
            ],
            
            'black': [
                "Oil treatments make black hair absolutely luminous! 🖤",
                "Silk pillowcases prevent frizz and maintain shine! ✨",
                "Regular deep conditioning keeps black hair healthy! 💧",
                "Heat protection is essential for black hair styling! 🛡️"
            ],
            
            'red': [
                "Color-depositing shampoo maintains red vibrancy! ❤️",
                "Minimize heat styling to prevent red from fading! 🔥",
                "Cool water washes preserve red pigments! ❄️",
                "UV protection is crucial for red hair longevity! ☀️"
            ],
            
            'dyed': [
                "Color-safe products are non-negotiable for fantasy colors! 🌈",
                "Dry shampoo extends time between washes! 🧴",
                "Cold water only - hot water is color's worst enemy! ❄️",
                "Touch-up those roots before they become too obvious! ✨"
            ]
        }
    
    def get_personalized_tips(self, hair_analysis_results):
        """
        Generate personalized hair care tips based on analysis results
        
        Args:
            hair_analysis_results: Dictionary containing hair analysis scores
            
        Returns:
            dict: Personalized care recommendations
        """
        tips = {
            'priority_issues': [],
            'general_care': [],
            'styling_tips': [],
            'color_care': [],
            'weekly_routine': [],
            'emergency_fixes': []
        }
        
        # Analyze scores and identify priority issues
        silkiness_score = hair_analysis_results.get('hair_silkiness_score', 50)
        thickness_score = hair_analysis_results.get('hair_thickness_score', 50)
        length_score = hair_analysis_results.get('hair_length_score', 50)
        texture_score = hair_analysis_results.get('hair_texture_score', 50)
        
        hairstyle = hair_analysis_results.get('hairstyle', 'unknown')
        hair_color = hair_analysis_results.get('hair_color_class', 'brown')
        
        # Priority issues (scores < 60)
        if silkiness_score < 60:
            tips['priority_issues'].extend([
                "🚨 SILKINESS ALERT: Your hair needs some serious moisture!",
                np.random.choice(self.care_tips['silkiness']['low'])
            ])
        
        if thickness_score < 60:
            tips['priority_issues'].extend([
                "🚨 VOLUME BOOST NEEDED: Time to add some thickness!",
                np.random.choice(self.care_tips['thickness']['low'])
            ])
        
        if length_score < 60:
            tips['priority_issues'].extend([
                "🚨 LENGTH GOALS: Let's work on growing that hair!",
                np.random.choice(self.care_tips['length']['low'])
            ])
        
        # General care based on scores
        for category, score in [('silkiness', silkiness_score), ('thickness', thickness_score), 
                               ('length', length_score), ('texture', texture_score)]:
            if score >= 80:
                level = 'high'
            elif score >= 60:
                level = 'medium'
            else:
                level = 'low'
            
            if category in self.care_tips and level in self.care_tips[category]:
                tips['general_care'].append(np.random.choice(self.care_tips[category][level]))
        
        # Hairstyle-specific tips
        if hairstyle in self.hairstyle_specific_tips:
            tips['styling_tips'].extend(np.random.choice(self.hairstyle_specific_tips[hairstyle], 2, replace=False))
        
        # Color-specific care
        if hair_color in self.color_care_tips:
            tips['color_care'].extend(np.random.choice(self.color_care_tips[hair_color], 2, replace=False))
        
        # Weekly routine suggestions
        tips['weekly_routine'] = self._create_weekly_routine(hair_analysis_results)
        
        # Emergency fixes for immediate improvement
        tips['emergency_fixes'] = self._get_emergency_fixes(hair_analysis_results)
        
        return tips
    
    def _create_weekly_routine(self, results):
        """Create a weekly hair care routine based on analysis"""
        routine = []
        
        silkiness_score = results.get('hair_silkiness_score', 50)
        thickness_score = results.get('hair_thickness_score', 50)
        
        # Monday
        routine.append("💆‍♀️ MONDAY: Scalp massage + oil treatment")
        
        # Wednesday
        if silkiness_score < 60:
            routine.append("💧 WEDNESDAY: Deep conditioning mask (20 mins)")
        else:
            routine.append("✨ WEDNESDAY: Light protein treatment")
        
        # Friday
        if thickness_score < 60:
            routine.append("🚀 FRIDAY: Volumizing treatment + root massage")
        else:
            routine.append("🌟 FRIDAY: Glossing treatment for shine")
        
        # Sunday
        routine.append("✂️ SUNDAY: Trim check + protective styling")
        
        return routine
    
    def _get_emergency_fixes(self, results):
        """Get quick fixes for immediate hair improvement"""
        fixes = []
        
        silkiness_score = results.get('hair_silkiness_score', 50)
        
        if silkiness_score < 50:
            fixes.extend([
                "🚨 INSTANT FIX: Apply hair oil to damp ends NOW",
                "💨 QUICK WIN: Cold water rinse = instant shine",
                "⚡ EMERGENCY: Silk scarf around pillow tonight"
            ])
        
        fixes.extend([
            "🌟 PRO TIP: Dry shampoo at roots for instant volume",
            "✨ QUICK GLOW: Face-framing highlights with concealer",
            "💫 INSTANT UPGRADE: Change your part for face-lifting effect"
        ])
        
        return fixes
    
    def format_tips_for_message(self, tips):
        """Format tips into a readable message for the bot"""
        message_parts = []
        
        if tips['priority_issues']:
            message_parts.append("🚨 **PRIORITY FIXES:**")
            for tip in tips['priority_issues'][:2]:  # Limit to 2 priority issues
                message_parts.append(f"• {tip}")
            message_parts.append("")
        
        if tips['general_care']:
            message_parts.append("💫 **GENERAL CARE:**")
            for tip in tips['general_care'][:2]:  # Limit to 2 general tips
                message_parts.append(f"• {tip}")
            message_parts.append("")
        
        if tips['emergency_fixes']:
            message_parts.append("⚡ **QUICK FIXES:**")
            for tip in tips['emergency_fixes'][:2]:  # Limit to 2 quick fixes
                message_parts.append(f"• {tip}")
        
        return "\n".join(message_parts)