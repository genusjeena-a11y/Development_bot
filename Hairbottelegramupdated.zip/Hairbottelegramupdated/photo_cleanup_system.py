"""
Automatic Photo Cleanup System
Removes photos that are not part of the leaderboard to save storage space
"""
import os
import time
import logging
from typing import Set, List, Dict
from photo_manager import photo_manager

logger = logging.getLogger(__name__)

class PhotoCleanupSystem:
    def __init__(self, upload_folder: str = 'uploads'):
        self.upload_folder = upload_folder
        # Clean up photos older than 24 hours that aren't in leaderboard
        self.cleanup_age_threshold = 24 * 60 * 60  # 24 hours in seconds
        
    def get_leaderboard_photo_ids(self) -> Set[str]:
        """Get set of unique IDs that are currently in leaderboards"""
        try:
            all_photos = photo_manager.get_all_photos()
            return set(all_photos.keys())
        except Exception as e:
            logger.error(f"Error getting leaderboard photos: {e}")
            return set()
    
    def get_upload_folder_files(self) -> List[str]:
        """Get list of all files in upload folder"""
        try:
            if not os.path.exists(self.upload_folder):
                return []
            
            files = []
            for filename in os.listdir(self.upload_folder):
                if filename.lower().endswith(('.jpg', '.jpeg', '.png', '.gif')):
                    files.append(filename)
            return files
        except Exception as e:
            logger.error(f"Error listing upload folder files: {e}")
            return []
    
    def extract_unique_id_from_filename(self, filename: str) -> str:
        """Extract unique ID from filename (assumes format: unique_id.jpg)"""
        return os.path.splitext(filename)[0]
    
    def is_file_old_enough_for_cleanup(self, filepath: str) -> bool:
        """Check if file is old enough to be cleaned up"""
        try:
            file_age = time.time() - os.path.getmtime(filepath)
            return file_age > self.cleanup_age_threshold
        except Exception as e:
            logger.error(f"Error checking file age for {filepath}: {e}")
            return False
    
    def cleanup_unused_photos(self) -> Dict[str, int]:
        """
        Clean up photos that are not in leaderboard and are old enough
        
        Returns:
            Dict with cleanup statistics
        """
        stats = {
            'checked': 0,
            'removed': 0,
            'kept_in_leaderboard': 0,
            'kept_too_recent': 0,
            'errors': 0
        }
        
        try:
            # Get current leaderboard photo IDs
            leaderboard_photo_ids = self.get_leaderboard_photo_ids()
            
            # Get all files in upload folder
            upload_files = self.get_upload_folder_files()
            
            for filename in upload_files:
                stats['checked'] += 1
                filepath = os.path.join(self.upload_folder, filename)
                unique_id = self.extract_unique_id_from_filename(filename)
                
                # Skip .gitkeep file
                if filename == '.gitkeep':
                    continue
                
                # Keep files that are in leaderboard
                if unique_id in leaderboard_photo_ids:
                    stats['kept_in_leaderboard'] += 1
                    continue
                
                # Keep files that are too recent
                if not self.is_file_old_enough_for_cleanup(filepath):
                    stats['kept_too_recent'] += 1
                    continue
                
                # Remove old unused files
                try:
                    os.remove(filepath)
                    stats['removed'] += 1
                    logger.info(f"Cleaned up unused photo: {filename}")
                except Exception as e:
                    stats['errors'] += 1
                    logger.error(f"Error removing file {filepath}: {e}")
            
            logger.info(f"Photo cleanup completed: {stats}")
            return stats
            
        except Exception as e:
            logger.error(f"Error during photo cleanup: {e}")
            stats['errors'] += 1
            return stats
    
    def get_cleanup_summary(self, stats: Dict[str, int]) -> str:
        """Generate a human-readable cleanup summary"""
        if stats['checked'] == 0:
            return "🧹 No photos to check for cleanup."
        
        summary = f"🧹 **Photo Cleanup Summary:**\n"
        summary += f"• Checked: {stats['checked']} files\n"
        summary += f"• Removed: {stats['removed']} old unused photos\n"
        summary += f"• Kept (in leaderboard): {stats['kept_in_leaderboard']}\n"
        summary += f"• Kept (too recent): {stats['kept_too_recent']}\n"
        
        if stats['errors'] > 0:
            summary += f"• Errors: {stats['errors']}\n"
        
        return summary
    
    def schedule_periodic_cleanup(self):
        """Schedule periodic cleanup (can be called periodically)"""
        # This method can be enhanced with a scheduler like APScheduler
        return self.cleanup_unused_photos()

# Global instance
photo_cleanup = PhotoCleanupSystem()