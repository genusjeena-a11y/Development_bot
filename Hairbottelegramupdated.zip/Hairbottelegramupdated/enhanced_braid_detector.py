"""
Enhanced Braid Detection System with advanced pattern recognition
"""
import cv2
import numpy as np
import logging
from typing import Dict, Tuple, List, Optional
from scipy import ndimage
from scipy.signal import find_peaks
from sklearn.cluster import DBSCAN

logger = logging.getLogger(__name__)

class EnhancedBraidDetector:
    """Enhanced braid detection with multiple pattern recognition techniques"""
    
    def __init__(self):
        self.braid_types = {
            'simple_braid': {'complexity': 1, 'segments': 3},
            'french_braid': {'complexity': 2, 'segments': 4},
            'dutch_braid': {'complexity': 2, 'segments': 4},
            'fishtail_braid': {'complexity': 3, 'segments': 6},
            'waterfall_braid': {'complexity': 3, 'segments': 5},
            'crown_braid': {'complexity': 4, 'segments': 8},
            'boxer_braid': {'complexity': 2, 'segments': 4}
        }
    
    def detect_braids_enhanced(self, image_path: str, hair_region: np.ndarray = None) -> Dict:
        """
        Enhanced braid detection with multiple techniques
        
        Returns:
            Dict containing braid detection results
        """
        try:
            # Load image if not provided hair region
            if hair_region is None:
                image = cv2.imread(image_path)
                if image is None:
                    return self._create_negative_result("Could not load image")
                
                # Extract hair region (simplified - would use actual hair segmentation)
                hair_region = self._extract_hair_region(image)
            
            if hair_region is None or hair_region.size == 0:
                return self._create_negative_result("No hair region detected")
            
            # Convert to grayscale
            if len(hair_region.shape) == 3:
                gray_hair = cv2.cvtColor(hair_region, cv2.COLOR_RGB2GRAY)
            else:
                gray_hair = hair_region.copy()
            
            # Apply multiple detection techniques
            results = {}
            
            # 1. Pattern-based detection
            pattern_result = self._detect_braid_patterns_advanced(gray_hair)
            results['pattern_detection'] = pattern_result
            
            # 2. Frequency domain analysis
            frequency_result = self._detect_braids_frequency_analysis(gray_hair)
            results['frequency_analysis'] = frequency_result
            
            # 3. Texture-based detection
            texture_result = self._detect_braids_texture_analysis(gray_hair)
            results['texture_analysis'] = texture_result
            
            # 4. Contour-based detection
            contour_result = self._detect_braids_contour_analysis(gray_hair)
            results['contour_analysis'] = contour_result
            
            # 5. Line detection for braid structure
            line_result = self._detect_braid_lines(gray_hair)
            results['line_detection'] = line_result
            
            # Combine all results
            final_result = self._combine_braid_detection_results(results)
            
            # Add specific braid type detection if braid is detected
            if final_result['is_braid']:
                braid_type = self._classify_braid_type(gray_hair, results)
                final_result['braid_type'] = braid_type
                final_result['braid_complexity'] = self.braid_types.get(braid_type, {}).get('complexity', 1)
            
            return final_result
            
        except Exception as e:
            logger.error(f"Error in enhanced braid detection: {e}")
            return self._create_negative_result(f"Detection error: {e}")
    
    def _detect_braid_patterns_advanced(self, gray_hair: np.ndarray) -> Dict:
        """Advanced pattern detection using multiple techniques"""
        
        # 1. Repetitive segment detection
        segments_detected = self._detect_repetitive_segments(gray_hair)
        
        # 2. Diagonal pattern detection
        diagonal_patterns = self._detect_diagonal_patterns(gray_hair)
        
        # 3. Weaving pattern detection
        weaving_patterns = self._detect_weaving_patterns(gray_hair)
        
        # 4. Interlacing detection
        interlacing_score = self._detect_interlacing_patterns(gray_hair)
        
        pattern_confidence = (segments_detected + diagonal_patterns + weaving_patterns + interlacing_score) / 4
        
        return {
            'confidence': pattern_confidence,
            'segments_detected': segments_detected,
            'diagonal_patterns': diagonal_patterns,
            'weaving_patterns': weaving_patterns,
            'interlacing_score': interlacing_score
        }
    
    def _detect_repetitive_segments(self, gray_hair: np.ndarray) -> float:
        """Detect repetitive segments characteristic of braids"""
        h, w = gray_hair.shape
        
        # Analyze horizontal projections for repeating patterns
        horizontal_proj = np.sum(gray_hair, axis=1)
        
        # Smooth the projection
        smoothed_proj = ndimage.gaussian_filter1d(horizontal_proj, sigma=2)
        
        # Find peaks (high intensity areas - potential braid segments)
        peaks, _ = find_peaks(smoothed_proj, height=np.mean(smoothed_proj) * 0.8, distance=5)
        
        if len(peaks) < 3:
            return 0.0
        
        # Check for regularity in peak spacing
        peak_distances = np.diff(peaks)
        if len(peak_distances) > 1:
            distance_consistency = 1.0 - (np.std(peak_distances) / np.mean(peak_distances))
            segment_score = min(1.0, len(peaks) / 8) * distance_consistency
        else:
            segment_score = 0.0
        
        return max(0.0, min(100.0, segment_score * 100))
    
    def _detect_diagonal_patterns(self, gray_hair: np.ndarray) -> float:
        """Detect diagonal patterns typical in braids"""
        
        # Create kernels for different diagonal directions
        kernel_45 = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=np.float32)
        kernel_135 = np.array([[1, 0, -1], [2, 0, -2], [1, 0, -1]], dtype=np.float32)
        
        # Apply kernels
        diag_45 = cv2.filter2D(gray_hair.astype(np.float32), -1, kernel_45)
        diag_135 = cv2.filter2D(gray_hair.astype(np.float32), -1, kernel_135)
        
        # Combine responses
        diagonal_response = np.sqrt(diag_45**2 + diag_135**2)
        
        # Calculate diagonal pattern strength
        diagonal_strength = np.mean(diagonal_response)
        diagonal_score = min(100.0, diagonal_strength / 50.0 * 100)
        
        return diagonal_score
    
    def _detect_weaving_patterns(self, gray_hair: np.ndarray) -> float:
        """Detect weaving patterns characteristic of braids"""
        
        # Apply Gabor filters at different orientations
        orientations = [0, 30, 60, 90, 120, 150]
        responses = []
        
        for angle in orientations:
            theta = np.radians(angle)
            kernel = cv2.getGaborKernel((15, 15), 3, theta, 10, 0.5, 0, ktype=cv2.CV_32F)
            filtered = cv2.filter2D(gray_hair, cv2.CV_8UC3, kernel)
            responses.append(np.mean(np.abs(filtered)))
        
        # Look for multiple strong responses (indicating weaving)
        strong_responses = [r for r in responses if r > np.mean(responses)]
        weaving_score = min(100.0, len(strong_responses) / len(orientations) * 100)
        
        return weaving_score
    
    def _detect_interlacing_patterns(self, gray_hair: np.ndarray) -> float:
        """Detect interlacing patterns specific to braids"""
        
        # Use morphological operations to detect interlacing
        kernel_horizontal = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 3))
        kernel_vertical = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 7))
        
        # Opening operations to detect patterns
        horizontal_pattern = cv2.morphologyEx(gray_hair, cv2.MORPH_OPEN, kernel_horizontal)
        vertical_pattern = cv2.morphologyEx(gray_hair, cv2.MORPH_OPEN, kernel_vertical)
        
        # Calculate pattern interaction
        pattern_interaction = cv2.bitwise_and(horizontal_pattern, vertical_pattern)
        interlacing_strength = np.sum(pattern_interaction) / np.sum(gray_hair + 1)
        
        return min(100.0, interlacing_strength * 500)
    
    def _detect_braids_frequency_analysis(self, gray_hair: np.ndarray) -> Dict:
        """Use frequency domain analysis to detect repetitive patterns"""
        
        # Apply FFT to detect periodic patterns
        f_transform = np.fft.fft2(gray_hair)
        f_shift = np.fft.fftshift(f_transform)
        magnitude_spectrum = np.log(np.abs(f_shift) + 1)
        
        # Analyze frequency peaks
        h, w = magnitude_spectrum.shape
        center_h, center_w = h//2, w//2
        
        # Look for peaks away from center (indicating periodic patterns)
        mask = np.zeros((h, w))
        cv2.circle(mask, (center_w, center_h), 30, 1, -1)  # Exclude low frequencies
        
        masked_spectrum = magnitude_spectrum * (1 - mask)
        
        # Find significant peaks
        threshold = np.mean(masked_spectrum) + 2 * np.std(masked_spectrum)
        significant_peaks = np.sum(masked_spectrum > threshold)
        
        # More peaks suggest more regular patterns (like braids)
        frequency_score = min(100.0, significant_peaks * 2)
        
        return {
            'confidence': frequency_score,
            'significant_peaks': significant_peaks,
            'frequency_regularity': frequency_score / 100.0
        }
    
    def _detect_braids_texture_analysis(self, gray_hair: np.ndarray) -> Dict:
        """Analyze texture patterns specific to braids"""
        
        # Local Binary Pattern analysis
        from skimage.feature import local_binary_pattern
        
        lbp = local_binary_pattern(gray_hair, 8, 1, method='uniform')
        lbp_hist, _ = np.histogram(lbp.ravel(), bins=10, density=True)
        
        # Braids typically have specific LBP patterns
        # Look for patterns indicating transitions and repetitions
        texture_complexity = np.sum(lbp_hist > 0.05)  # Number of significant patterns
        
        # Calculate texture directionality
        sobelx = cv2.Sobel(gray_hair, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(gray_hair, cv2.CV_64F, 0, 1, ksize=3)
        
        gradient_magnitude = np.sqrt(sobelx**2 + sobely**2)
        gradient_direction = np.arctan2(sobely, sobelx)
        
        # Analyze direction consistency (braids have structured directions)
        direction_variance = np.var(gradient_direction[gradient_magnitude > np.mean(gradient_magnitude)])
        direction_score = max(0.0, 100.0 - direction_variance * 20)
        
        texture_score = (texture_complexity * 10 + direction_score) / 2
        
        return {
            'confidence': min(100.0, texture_score),
            'texture_complexity': texture_complexity,
            'direction_score': direction_score
        }
    
    def _detect_braids_contour_analysis(self, gray_hair: np.ndarray) -> Dict:
        """Analyze contours for braid-like structures"""
        
        # Edge detection
        edges = cv2.Canny(gray_hair, 50, 150)
        
        # Find contours
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        braid_like_contours = 0
        total_contour_length = 0
        
        for contour in contours:
            # Analyze contour properties
            area = cv2.contourArea(contour)
            perimeter = cv2.arcLength(contour, True)
            
            if area > 50 and perimeter > 50:  # Significant contours only
                # Calculate contour complexity (bending)
                epsilon = 0.02 * perimeter
                approx = cv2.approxPolyDP(contour, epsilon, True)
                
                # Braids have complex, curved contours
                if len(approx) > 6:  # Complex shape
                    rect = cv2.boundingRect(contour)
                    aspect_ratio = rect[3] / rect[2]  # height/width
                    
                    # Braid-like if elongated and complex
                    if aspect_ratio > 0.5:
                        braid_like_contours += 1
                        total_contour_length += perimeter
        
        contour_score = min(100.0, braid_like_contours * 15)
        
        return {
            'confidence': contour_score,
            'braid_like_contours': braid_like_contours,
            'total_contour_length': total_contour_length
        }
    
    def _detect_braid_lines(self, gray_hair: np.ndarray) -> Dict:
        """Detect line structures typical in braids"""
        
        # Hough line detection
        edges = cv2.Canny(gray_hair, 50, 150)
        
        # Detect lines
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=30, 
                               minLineLength=20, maxLineGap=10)
        
        if lines is None:
            return {'confidence': 0.0, 'line_count': 0, 'line_angles': []}
        
        # Analyze line patterns
        line_angles = []
        for line in lines:
            x1, y1, x2, y2 = line[0]
            angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
            line_angles.append(angle)
        
        # Group similar angles
        angle_groups = []
        for angle in line_angles:
            grouped = False
            for group in angle_groups:
                if abs(angle - np.mean(group)) < 15:  # Within 15 degrees
                    group.append(angle)
                    grouped = True
                    break
            if not grouped:
                angle_groups.append([angle])
        
        # Braids typically have 2-3 dominant line directions
        significant_groups = [g for g in angle_groups if len(g) > 2]
        line_structure_score = min(100.0, len(significant_groups) * 30)
        
        return {
            'confidence': line_structure_score,
            'line_count': len(lines),
            'line_angles': line_angles,
            'dominant_directions': len(significant_groups)
        }
    
    def _combine_braid_detection_results(self, results: Dict) -> Dict:
        """Combine all detection method results"""
        
        # Extract confidence scores
        pattern_conf = results['pattern_detection']['confidence']
        frequency_conf = results['frequency_analysis']['confidence']
        texture_conf = results['texture_analysis']['confidence']
        contour_conf = results['contour_analysis']['confidence']
        line_conf = results['line_detection']['confidence']
        
        # Weighted combination
        combined_confidence = (
            pattern_conf * 0.35 +      # Most important
            texture_conf * 0.25 +      # Very important
            frequency_conf * 0.20 +    # Important
            contour_conf * 0.15 +      # Moderate
            line_conf * 0.05           # Supporting evidence
        )
        
        # Determine if it's a braid based on threshold
        is_braid = combined_confidence > 60.0
        
        # Additional confidence boosters
        if (pattern_conf > 70 and texture_conf > 60):
            combined_confidence = min(100.0, combined_confidence * 1.1)
        
        if (frequency_conf > 70 and line_conf > 50):
            combined_confidence = min(100.0, combined_confidence * 1.05)
        
        return {
            'is_braid': is_braid,
            'confidence': combined_confidence,
            'pattern_score': pattern_conf,
            'texture_score': texture_conf,
            'frequency_score': frequency_conf,
            'contour_score': contour_conf,
            'line_score': line_conf,
            'detection_details': results
        }
    
    def _classify_braid_type(self, gray_hair: np.ndarray, results: Dict) -> str:
        """Classify the specific type of braid"""
        
        pattern_details = results['pattern_detection']
        texture_details = results['texture_analysis']
        line_details = results['line_detection']
        
        segments = pattern_details.get('segments_detected', 0)
        complexity = texture_details.get('texture_complexity', 0)
        directions = line_details.get('dominant_directions', 0)
        
        # Simple classification logic based on detected features
        if complexity > 8 and directions > 3:
            if segments > 60:
                return 'crown_braid'
            else:
                return 'fishtail_braid'
        elif complexity > 6 and directions > 2:
            if pattern_details.get('weaving_patterns', 0) > 70:
                return 'french_braid'
            else:
                return 'dutch_braid'
        elif directions > 2:
            return 'waterfall_braid'
        elif segments > 40:
            return 'boxer_braid'
        else:
            return 'simple_braid'
    
    def _extract_hair_region(self, image: np.ndarray) -> np.ndarray:
        """Basic hair region extraction - placeholder for actual segmentation"""
        # This would be replaced with proper hair segmentation
        # For now, return the upper portion of the image
        h, w = image.shape[:2]
        return image[:h//2, :]
    
    def _create_negative_result(self, reason: str) -> Dict:
        """Create a negative detection result"""
        return {
            'is_braid': False,
            'confidence': 0.0,
            'braid_type': 'none',
            'error': reason,
            'pattern_score': 0.0,
            'texture_score': 0.0,
            'frequency_score': 0.0,
            'contour_score': 0.0,
            'line_score': 0.0
        }

# Global instance
enhanced_braid_detector = EnhancedBraidDetector()