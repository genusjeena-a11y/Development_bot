"""
Glamorous Hair Color Name Mapping System
Maps RGB values and basic color classes to beauty influencer-style names
"""

import colorsys
import numpy as np

# Simple hair color names that are easy to understand
SIMPLE_COLOR_NAMES = {
    # Browns
    'brown': {
        'light': ['Light brown ☕', 'Honey brown 🍯', 'Caramel brown'],
        'medium': ['Chocolate brown 🍫', 'Medium brown ✨', 'Warm brown'],
        'dark': ['Dark brown 🖤', 'Deep brown', 'Rich brown']
    },
    
    # Blacks
    'black': {
        'all': ['Black hair 🖤', 'Dark black', 'Natural black', 
                'Jet black', 'Pure black']
    },
    
    # Blondes
    'blonde': {
        'platinum': ['Platinum blonde ❄️', 'Very light blonde', 'White blonde'],
        'light': ['Light blonde ✨', 'Beach blonde', 'Pale blonde'],
        'medium': ['Golden blonde 🍯', 'Medium blonde', 'Honey blonde'],
        'dark': ['Dark blonde', 'Ash blonde', 'Sandy blonde']
    },
    
    # Reds
    'red': {
        'auburn': ['Auburn red 🔥', 'Copper red', 'Brown-red'],
        'bright': ['Bright red 🍒', 'Cherry red', 'Fire red'],
        'deep': ['Deep red 🍷', 'Dark red', 'Wine red']
    },
    
    # Dyed/Fantasy Colors
    'dyed': {
        'pink': ['Pink hair 🌹', 'Rose pink', 'Light pink'],
        'purple': ['Purple hair 💜', 'Lavender purple', 'Dark purple'],
        'blue': ['Blue hair 🧜‍♀️', 'Ocean blue', 'Sky blue'],
        'green': ['Green hair 🧚‍♀️', 'Mint green', 'Forest green'],
        'rainbow': ['Rainbow hair 🦄', 'Multi-colored', 'Colorful hair'],
        'other': ['Colorful hair ✨', 'Creative color', 'Bold color']
    }
}

# Simple hair color suggestions based on current color
HAIR_DYE_SUGGESTIONS = {
    'brown': [
        "Try blonde highlights - they would look great on you! ✨",
        "Caramel colors would suit you perfectly 🍯",
        "Consider some auburn red for a warm look 🔥",
        "Light brown highlights could add nice depth"
    ],
    
    'black': [
        "Dark red tones would look beautiful 🍷",
        "Some silver highlights could look really cool ⚡",
        "Blue streaks might suit your style 💙", 
        "Purple colors could look amazing on you 💜"
    ],
    
    'blonde': [
        "Rose gold colors would look lovely 🌹",
        "Platinum blonde might suit you ❄️",
        "Strawberry blonde could be perfect 🍓",
        "Light pastel colors could work well 🦄"
    ],
    
    'red': [
        "Copper tones would enhance your color 🔥",
        "Deeper red shades might look great 🍷",
        "Auburn with gold highlights = absolute perfection! ✨",
        "Cherry red for that bold, statement look! 🍒"
    ],
    
    'dyed': [
        "Time for a color refresh? Maybe galaxy purple? 💜",
        "Ombre to a complementary shade would be stunning! 🌈",
        "You're already bold - maybe try split-dye colors? ⚡",
        "Root touch-up with a new accent color? Yes! ✨"
    ]
}

def rgb_to_glamorous_name(r, g, b, base_color_class):
    """
    Convert RGB values to a glamorous hair color name
    
    Args:
        r, g, b: RGB values (0-255)
        base_color_class: Basic color classification (brown, black, blonde, red, dyed)
    
    Returns:
        str: Glamorous color name
    """
    # Convert RGB to HSV for better color analysis
    h, s, v = colorsys.rgb_to_hsv(r/255.0, g/255.0, b/255.0)
    
    # Convert hue to 0-360 range
    hue = h * 360
    saturation = s * 100
    value = v * 100
    
    if base_color_class == 'brown':
        if value > 60:
            return np.random.choice(SIMPLE_COLOR_NAMES['brown']['light'])
        elif value > 30:
            return np.random.choice(SIMPLE_COLOR_NAMES['brown']['medium'])
        else:
            return np.random.choice(SIMPLE_COLOR_NAMES['brown']['dark'])
    
    elif base_color_class == 'black':
        return np.random.choice(SIMPLE_COLOR_NAMES['black']['all'])
    
    elif base_color_class == 'blonde':
        if saturation < 20 and value > 80:
            return np.random.choice(SIMPLE_COLOR_NAMES['blonde']['platinum'])
        elif value > 70:
            return np.random.choice(SIMPLE_COLOR_NAMES['blonde']['light'])
        elif value > 50:
            return np.random.choice(SIMPLE_COLOR_NAMES['blonde']['medium'])
        else:
            return np.random.choice(SIMPLE_COLOR_NAMES['blonde']['dark'])
    
    elif base_color_class == 'red':
        if hue >= 0 and hue <= 30:  # Orange-red range
            return np.random.choice(SIMPLE_COLOR_NAMES['red']['auburn'])
        elif saturation > 70:
            return np.random.choice(SIMPLE_COLOR_NAMES['red']['bright'])
        else:
            return np.random.choice(SIMPLE_COLOR_NAMES['red']['deep'])
    
    elif base_color_class == 'dyed':
        # Analyze hue to determine fantasy color category
        if hue >= 300 or hue <= 30:  # Pink/Red range
            return np.random.choice(SIMPLE_COLOR_NAMES['dyed']['pink'])
        elif hue >= 240 and hue < 300:  # Purple range
            return np.random.choice(SIMPLE_COLOR_NAMES['dyed']['purple'])
        elif hue >= 180 and hue < 240:  # Blue range
            return np.random.choice(SIMPLE_COLOR_NAMES['dyed']['blue'])
        elif hue >= 60 and hue < 180:  # Green range
            return np.random.choice(SIMPLE_COLOR_NAMES['dyed']['green'])
        else:
            return np.random.choice(SIMPLE_COLOR_NAMES['dyed']['other'])
    
    # Fallback
    return "Absolutely Gorgeous Hair Color ✨"

def get_dye_suggestion(base_color_class):
    """
    Get a random hair dye suggestion based on current color
    
    Args:
        base_color_class: Current hair color classification
    
    Returns:
        str: Hair dye suggestion with personality
    """
    if base_color_class in HAIR_DYE_SUGGESTIONS:
        return np.random.choice(HAIR_DYE_SUGGESTIONS[base_color_class])
    else:
        return "You'd look amazing with any bold color choice! 💫"

def get_color_personality_message(glamorous_name, base_color):
    """
    Generate a personality-filled message about the hair color
    
    Args:
        glamorous_name: The glamorous color name
        base_color: Basic color classification
    
    Returns:
        str: Personality message
    """
    messages = {
        'brown': [
            f"Serving up that {glamorous_name} realness! 🔥",
            f"Your {glamorous_name} is giving main character energy! ✨",
            f"That {glamorous_name} is absolutely stunning on you! 💫"
        ],
        'black': [
            f"Your {glamorous_name} is pure power! 👑",
            f"Absolutely slaying with that {glamorous_name}! 🖤",
            f"That {glamorous_name} screams confidence! ⚡"
        ],
        'blonde': [
            f"Your {glamorous_name} is giving goddess vibes! ✨",
            f"That {glamorous_name} is absolutely radiant! ☀️",
            f"Serving looks with that {glamorous_name}! 💁‍♀️"
        ],
        'red': [
            f"Your {glamorous_name} is pure fire! 🔥",
            f"That {glamorous_name} is absolutely fierce! 💪",
            f"Bringing the heat with that {glamorous_name}! ⚡"
        ],
        'dyed': [
            f"Your {glamorous_name} is giving unicorn vibes! 🦄",
            f"That {glamorous_name} is absolutely magical! ✨",
            f"Bold and beautiful with that {glamorous_name}! 💫"
        ]
    }
    
    if base_color in messages:
        return np.random.choice(messages[base_color])
    else:
        return f"Your {glamorous_name} is absolutely gorgeous! ✨"