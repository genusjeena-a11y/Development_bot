"""
AI-Powered Hair Analysis System
Provides accurate hair color detection and personalized hair care recommendations
Uses computer vision and color analysis algorithms
"""

import cv2
import numpy as np
from PIL import Image, ImageStat
import colorsys
import logging
from typing import Dict, List, Tuple, Optional
import os
import json

logger = logging.getLogger(__name__)

class AIHairAnalyzer:
    def __init__(self):
        """Initialize the AI Hair Analyzer with color mappings and care knowledge"""
        
        # Hair color categories with HSV ranges and RGB references
        self.hair_colors = {
            'black': {
                'hsv_range': [(0, 0, 0), (180, 255, 50)],
                'rgb_ref': (30, 20, 20),
                'keywords': ['black', 'very dark', 'jet black', 'raven']
            },
            'dark_brown': {
                'hsv_range': [(10, 50, 20), (25, 255, 100)],
                'rgb_ref': (101, 67, 33),
                'keywords': ['dark brown', 'chocolate', 'espresso', 'mocha']
            },
            'brown': {
                'hsv_range': [(8, 50, 50), (30, 200, 150)],
                'rgb_ref': (139, 90, 43),
                'keywords': ['brown', 'chestnut', 'caramel', 'amber']
            },
            'light_brown': {
                'hsv_range': [(15, 30, 80), (35, 150, 200)],
                'rgb_ref': (160, 116, 80),
                'keywords': ['light brown', 'honey', 'golden brown', 'hazelnut']
            },
            'dirty_blonde': {
                'hsv_range': [(20, 25, 120), (40, 120, 220)],
                'rgb_ref': (167, 133, 106),
                'keywords': ['dirty blonde', 'ash blonde', 'mousy', 'sandy']
            },
            'blonde': {
                'hsv_range': [(18, 20, 150), (35, 100, 255)],
                'rgb_ref': (218, 165, 32),
                'keywords': ['blonde', 'golden', 'platinum', 'wheat']
            },
            'light_blonde': {
                'hsv_range': [(20, 10, 200), (40, 60, 255)],
                'rgb_ref': (255, 228, 181),
                'keywords': ['light blonde', 'platinum blonde', 'bleached', 'white blonde']
            },
            'red': {
                'hsv_range': [(0, 50, 50), (15, 255, 200)],
                'rgb_ref': (165, 42, 42),
                'keywords': ['red', 'auburn', 'ginger', 'copper', 'strawberry']
            },
            'gray': {
                'hsv_range': [(0, 0, 60), (180, 30, 180)],
                'rgb_ref': (128, 128, 128),
                'keywords': ['gray', 'grey', 'silver', 'salt and pepper']
            },
            'white': {
                'hsv_range': [(0, 0, 180), (180, 30, 255)],
                'rgb_ref': (245, 245, 245),
                'keywords': ['white', 'silver white', 'snow white']
            }
        }
        
        # Hair care recommendations database
        self.hair_care_tips = {
            'black': {
                'shampoo': "Use sulfate-free shampoos to maintain natural oils and prevent dryness",
                'conditioning': "Deep condition weekly with moisturizing masks containing shea butter or argan oil",
                'styling': "Protect from heat damage with thermal protectants. Use leave-in conditioners",
                'maintenance': "Trim every 8-10 weeks. Sleep on silk pillowcases to reduce breakage",
                'products': ["Argan oil", "Shea butter masks", "Silk protein treatments", "UV protection sprays"]
            },
            'dark_brown': {
                'shampoo': "Color-safe shampoos with gentle cleansing agents to prevent fading",
                'conditioning': "Protein treatments every 2 weeks to strengthen hair structure",
                'styling': "Use heat protectant before styling. Avoid excessive brushing when wet",
                'maintenance': "Regular trims every 6-8 weeks. Use wide-tooth combs on wet hair",
                'products': ["Color-protecting conditioner", "Keratin treatments", "Anti-frizz serums", "Root touch-up sprays"]
            },
            'brown': {
                'shampoo': "Clarifying shampoo once a week to remove buildup, gentle daily shampoo",
                'conditioning': "Alternate between moisturizing and protein treatments",
                'styling': "Scrunch with mousse for natural waves. Use diffuser for curly textures",
                'maintenance': "Trim every 6-8 weeks. Regular scalp massages for healthy growth",
                'products': ["Volumizing mousse", "Color-enhancing treatments", "Split-end repair serums", "Scalp scrubs"]
            },
            'light_brown': {
                'shampoo': "Purple-toned shampoo occasionally to prevent brassiness",
                'conditioning': "Weekly deep conditioning with honey or coconut oil masks",
                'styling': "Beach wave sprays for effortless texture. Avoid over-washing",
                'maintenance': "Trim every 8 weeks. Protect from sun exposure to prevent lightening",
                'products': ["Purple shampoo", "Coconut oil masks", "Sea salt sprays", "UV protection"]
            },
            'dirty_blonde': {
                'shampoo': "Dry shampoo between washes. Use clarifying shampoo weekly",
                'conditioning': "Focus conditioner on mid-lengths and ends, avoid roots",
                'styling': "Texturizing sprays for volume. Avoid heavy oils near roots",
                'maintenance': "Trim every 6-8 weeks. Use boar bristle brushes for natural oils distribution",
                'products': ["Dry shampoo", "Texturizing spray", "Light leave-in conditioner", "Boar bristle brush"]
            },
            'blonde': {
                'shampoo': "Purple shampoo 2-3 times weekly to combat yellow tones",
                'conditioning': "Intensive moisture treatments due to potential chemical processing",
                'styling': "Minimize heat styling. Use cold water for final rinse to seal cuticles",
                'maintenance': "Trim every 4-6 weeks. Regular toning appointments if color-treated",
                'products': ["Purple shampoo", "Bond-building treatments", "Toning masks", "Heat protection"]
            },
            'light_blonde': {
                'shampoo': "Gentle, sulfate-free purple shampoos. Alternate with moisturizing shampoos",
                'conditioning': "Weekly protein treatments and deep conditioning masks",
                'styling': "Minimal heat styling. Use silk scrunchies and avoid tight hairstyles",
                'maintenance': "Trim every 4-6 weeks. Professional treatments every 6 weeks",
                'products': ["Bond repair treatments", "Intensive moisture masks", "Silk accessories", "Professional toners"]
            },
            'red': {
                'shampoo': "Color-depositing shampoos to maintain vibrancy",
                'conditioning': "Antioxidant-rich treatments to prevent color fading",
                'styling': "Cold water rinses to seal color. Limit sun exposure",
                'maintenance': "Trim every 6-8 weeks. Use color-safe styling products",
                'products': ["Color-depositing shampoo", "Antioxidant treatments", "Color-sealing glosses", "Sun protection"]
            },
            'gray': {
                'shampoo': "Blue or silver-toned shampoos to enhance natural color",
                'conditioning': "Rich moisturizing treatments as gray hair tends to be drier",
                'styling': "Embrace natural texture. Use lightweight oils for shine",
                'maintenance': "Regular trims for healthy appearance. Consider professional color enhancement",
                'products': ["Silver shampoo", "Rich moisturizing masks", "Shine-enhancing oils", "Texture creams"]
            },
            'white': {
                'shampoo': "Gentle, moisturizing shampoos. Avoid harsh chemicals",
                'conditioning': "Weekly deep conditioning with natural oils",
                'styling': "Gentle styling techniques. Avoid heat when possible",
                'maintenance': "Regular professional treatments. Protect from environmental damage",
                'products': ["Gentle moisturizing shampoo", "Natural oil treatments", "Protective styling products", "Silk accessories"]
            }
        }

    def extract_hair_region(self, image_path: str) -> Optional[np.ndarray]:
        """Extract hair region from image using computer vision"""
        try:
            # Load image
            img = cv2.imread(image_path)
            if img is None:
                logger.error(f"Could not load image: {image_path}")
                return None
            
            # Convert to different color spaces for analysis
            rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
            lab_img = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
            
            # Focus on upper portion of image where hair typically appears
            height, width = img.shape[:2]
            hair_region = rgb_img[:int(height*0.6), :]  # Top 60% of image
            
            return hair_region
            
        except Exception as e:
            logger.error(f"Error extracting hair region: {e}")
            return None

    def analyze_dominant_colors(self, hair_region: np.ndarray, num_colors: int = 5) -> List[Tuple[Tuple[int, int, int], float]]:
        """Analyze dominant colors in hair region using k-means clustering"""
        try:
            # Reshape image to list of pixels
            pixels = hair_region.reshape(-1, 3)
            
            # Remove very dark pixels (likely shadows/background)
            bright_pixels = pixels[np.sum(pixels, axis=1) > 60]
            
            if len(bright_pixels) == 0:
                bright_pixels = pixels
            
            # Use k-means to find dominant colors
            from sklearn.cluster import KMeans
            
            # Limit number of pixels for performance
            if len(bright_pixels) > 10000:
                indices = np.random.choice(len(bright_pixels), 10000, replace=False)
                bright_pixels = bright_pixels[indices]
            
            kmeans = KMeans(n_clusters=min(num_colors, len(bright_pixels)), random_state=42, n_init='auto')
            kmeans.fit(bright_pixels)
            
            # Get colors and their frequencies
            colors = kmeans.cluster_centers_.astype(int)
            labels = kmeans.labels_
            
            color_counts = []
            for i, color in enumerate(colors):
                count = int(np.sum(labels == i))
                percentage = count / len(labels) if len(labels) > 0 else 0
                color_counts.append((tuple(color), percentage))
            
            # Sort by frequency
            color_counts.sort(key=lambda x: x[1], reverse=True)
            
            return color_counts
            
        except Exception as e:
            logger.error(f"Error analyzing dominant colors: {e}")
            return []

    def classify_hair_color(self, dominant_colors: List[Tuple[Tuple[int, int, int], float]]) -> str:
        """Classify hair color based on dominant colors"""
        if not dominant_colors:
            return 'unknown'
        
        try:
            # Get the most dominant color
            primary_color = dominant_colors[0][0]
            
            # Convert RGB to HSV for better color classification
            r, g, b = [x/255.0 for x in primary_color]
            h, s, v = colorsys.rgb_to_hsv(r, g, b)
            h = int(h * 180)  # Convert to OpenCV HSV range
            s = int(s * 255)
            v = int(v * 255)
            
            # Calculate color distance to each hair color category
            best_match = 'unknown'
            min_distance = float('inf')
            
            for color_name, color_data in self.hair_colors.items():
                # Check if HSV values fall within range
                hsv_min, hsv_max = color_data['hsv_range']
                
                # Calculate distance from HSV ranges
                h_dist = 0 if hsv_min[0] <= h <= hsv_max[0] else min(abs(h - hsv_min[0]), abs(h - hsv_max[0]))
                s_dist = 0 if hsv_min[1] <= s <= hsv_max[1] else min(abs(s - hsv_min[1]), abs(s - hsv_max[1]))
                v_dist = 0 if hsv_min[2] <= v <= hsv_max[2] else min(abs(v - hsv_min[2]), abs(v - hsv_max[2]))
                
                total_distance = h_dist + s_dist + v_dist
                
                if total_distance < min_distance:
                    min_distance = total_distance
                    best_match = color_name
            
            # Additional logic for specific color classification
            if v < 50:  # Very dark
                return 'black'
            elif v > 200 and s < 60:  # Very light with low saturation
                return 'light_blonde' if s < 30 else 'blonde'
            elif h < 20 and s > 100:  # Red tones
                return 'red'
            
            return best_match
            
        except Exception as e:
            logger.error(f"Error classifying hair color: {e}")
            return 'unknown'

    def get_color_name(self, color_category: str) -> str:
        """Get a beautiful name for the hair color"""
        color_names = {
            'black': 'Midnight Black',
            'dark_brown': 'Rich Chocolate Brown', 
            'brown': 'Warm Chestnut Brown',
            'light_brown': 'Golden Honey Brown',
            'dirty_blonde': 'Sophisticated Ash Blonde',
            'blonde': 'Radiant Golden Blonde',
            'light_blonde': 'Luminous Platinum Blonde',
            'red': 'Vibrant Auburn Red',
            'gray': 'Elegant Silver Gray',
            'white': 'Beautiful Snow White',
            'unknown': 'Unique Natural Color'
        }
        return color_names.get(color_category, 'Beautiful Hair Color')

    def generate_personalized_tips(self, color_category: str, hair_thickness: float, hair_health: float) -> Dict[str, str]:
        """Generate personalized hair care tips based on analysis"""
        if color_category not in self.hair_care_tips:
            color_category = 'brown'  # Default fallback
        
        base_tips = self.hair_care_tips[color_category].copy()
        
        # Customize tips based on thickness and health
        if hair_thickness < 0.3:  # Fine hair
            base_tips['styling'] += " Use volumizing products and avoid heavy oils that can weigh hair down."
            base_tips['products'].append("Volumizing spray")
        elif hair_thickness > 0.7:  # Thick hair
            base_tips['styling'] += " Use smoothing serums and consider layered cuts to manage volume."
            base_tips['products'].append("Smoothing serum")
        
        if hair_health < 0.4:  # Damaged hair
            base_tips['conditioning'] += " Focus on protein treatments and avoid heat styling until health improves."
            base_tips['products'].extend(["Protein treatment", "Deep repair mask"])
        elif hair_health > 0.8:  # Healthy hair
            base_tips['maintenance'] += " Your hair is in excellent condition! Maintain with regular trims and protective styling."
        
        return base_tips

    def analyze_hair_image(self, image_path: str, hair_thickness: float = 0.5, hair_health: float = 0.5) -> Dict:
        """Complete AI-powered hair analysis"""
        try:
            logger.info(f"Starting AI hair analysis for: {image_path}")
            
            # Extract hair region
            hair_region = self.extract_hair_region(image_path)
            if hair_region is None:
                return {'error': 'Could not extract hair region from image'}
            
            # Analyze dominant colors
            dominant_colors = self.analyze_dominant_colors(hair_region)
            if not dominant_colors:
                return {'error': 'Could not analyze hair colors'}
            
            # Classify hair color
            color_category = self.classify_hair_color(dominant_colors)
            color_name = self.get_color_name(color_category)
            
            # Generate personalized tips
            care_tips = self.generate_personalized_tips(color_category, hair_thickness, hair_health)
            
            # Prepare result
            result = {
                'color_category': color_category,
                'color_name': color_name,
                'dominant_colors': dominant_colors[:3],  # Top 3 colors
                'care_tips': care_tips,
                'confidence': min(dominant_colors[0][1] * 100, 95) if dominant_colors else 50,
                'analysis_success': True
            }
            
            logger.info(f"Hair analysis completed: {color_name} ({color_category})")
            return result
            
        except Exception as e:
            logger.error(f"Error in AI hair analysis: {e}")
            return {
                'error': f'Analysis failed: {str(e)}',
                'analysis_success': False
            }

# Global instance
ai_hair_analyzer = AIHairAnalyzer()