"""
Advanced Hair Style Detection using MobileNetV2
Detects ponytails, braids, curls, buns, and messy styles
"""

import cv2
import numpy as np
import mediapipe as mp
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class HairStyleDetector:
    def __init__(self):
        self.img_height = 224
        self.img_width = 224
        
        # Hair style categories
        self.hairstyle_categories = [
            'straight_long',
            'straight_short', 
            'wavy',
            'curly',
            'ponytail',
            'bun',
            'braids',
            'messy',
            'bob',
            'pixie'
        ]
        
        # Initialize MediaPipe for face detection
        self.mp_face_detection = mp.solutions.face_detection
        self.face_detection = self.mp_face_detection.FaceDetection(
            model_selection=0, min_detection_confidence=0.5)
        
        # Build a simple feature-based classifier for now
        # In production, you would load a pre-trained model
        self.model = self._build_simple_classifier()
    
    def _build_simple_classifier(self):
        """
        Build a simple feature-based classifier for hair style detection
        In production, replace this with a trained MobileNetV2 model
        """
        # For now, we'll use computer vision techniques
        # This is a placeholder for the actual ML model
        return None
    
    def _preprocess_image(self, image_path):
        """Preprocess image for analysis"""
        try:
            img = cv2.imread(image_path)
            if img is None:
                raise ValueError(f"Could not load image from {image_path}")
            
            # Convert BGR to RGB
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            return img_rgb
        except Exception as e:
            logger.error(f"Error preprocessing image: {e}")
            return None
    
    def _detect_hair_region(self, image):
        """Detect and extract hair region using face detection"""
        try:
            results = self.face_detection.process(image)
            
            if results.detections:
                detection = results.detections[0]  # Use first face
                bbox = detection.location_data.relative_bounding_box
                
                h, w, _ = image.shape
                
                # Convert relative coordinates to absolute
                x = int(bbox.xmin * w)
                y = int(bbox.ymin * h)
                width = int(bbox.width * w)
                height = int(bbox.height * h)
                
                # Expand region above face for hair
                hair_y = max(0, y - int(height * 1.5))
                hair_height = y - hair_y + int(height * 0.3)
                
                hair_region = image[hair_y:hair_y + hair_height, x:x + width]
                return hair_region, (x, hair_y, width, hair_height)
            else:
                # If no face detected, use top portion of image
                h, w, _ = image.shape
                hair_region = image[:int(h * 0.6), :]
                return hair_region, (0, 0, w, int(h * 0.6))
                
        except Exception as e:
            logger.error(f"Error detecting hair region: {e}")
            h, w, _ = image.shape
            return image[:int(h * 0.6), :], (0, 0, w, int(h * 0.6))
    
    def _analyze_hair_texture(self, hair_region):
        """Analyze hair texture to determine style characteristics"""
        if hair_region is None or hair_region.size == 0:
            return {}
        
        try:
            # Convert to grayscale for texture analysis
            gray = cv2.cvtColor(hair_region, cv2.COLOR_RGB2GRAY)
            
            # Calculate texture features
            features = {}
            
            # Edge density (for detecting curls/waves)
            edges = cv2.Canny(gray, 50, 150)
            edge_density = np.sum(edges > 0) / edges.size
            features['edge_density'] = edge_density
            
            # Standard deviation (for texture roughness)
            features['texture_std'] = np.std(gray)
            
            # Gradient magnitude (for directional patterns)
            grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            grad_magnitude = np.sqrt(grad_x**2 + grad_y**2)
            features['gradient_mean'] = np.mean(grad_magnitude)
            
            # Hair length estimation (height of hair region)
            features['length_ratio'] = hair_region.shape[0] / hair_region.shape[1]
            
            return features
            
        except Exception as e:
            logger.error(f"Error analyzing hair texture: {e}")
            return {}
    
    def _classify_hairstyle(self, features, hair_region):
        """Classify hairstyle based on extracted features"""
        if not features:
            return 'unknown', 0.5
        
        try:
            # Enhanced rule-based classification with better thresholds
            edge_density = features.get('edge_density', 0)
            texture_std = features.get('texture_std', 0)
            gradient_mean = features.get('gradient_mean', 0)
            length_ratio = features.get('length_ratio', 1)
            
            # Advanced texture analysis for better straight vs curly detection
            gray = cv2.cvtColor(hair_region, cv2.COLOR_RGB2GRAY) if hair_region is not None else None
            
            # Calculate additional features for better classification
            curl_score = 0
            if gray is not None:
                # Analyze curvature using Hough circles
                try:
                    circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, 20,
                                             param1=50, param2=30, minRadius=5, maxRadius=50)
                    curl_score = len(circles[0]) if circles is not None else 0
                except:
                    curl_score = 0
                
                # Analyze directional variance for curl detection
                sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
                sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
                orientation = np.arctan2(sobel_y, sobel_x)
                orientation_var = np.var(orientation)
            else:
                orientation_var = 0
            
            # Improved classification logic
            # High edge density + high texture variance + high orientation variance = curly
            # Low edge density + low texture variance + low orientation variance = straight
            
            curl_indicators = 0
            if edge_density > 0.25:  # Increased threshold for curly detection
                curl_indicators += 1
            if texture_std > 50:  # Increased threshold
                curl_indicators += 1
            if orientation_var > 2.0:  # New threshold for orientation variance
                curl_indicators += 1
            if curl_score > 3:  # Circular patterns detected
                curl_indicators += 1
                
            # Classify based on curl indicators and length
            if curl_indicators >= 3:
                return 'curly', 0.9
            elif curl_indicators >= 2:
                return 'wavy', 0.8
            elif length_ratio > 1.8:  # Increased threshold for long hair
                if gradient_mean > 25 and texture_std < 35:  # Straight and long
                    return 'straight_long', 0.8
                else:
                    return 'messy', 0.6
            elif length_ratio < 0.6:  # Decreased threshold for short hair
                if texture_std < 20 and edge_density < 0.1:  # Very smooth and short
                    return 'pixie', 0.8
                else:
                    return 'bob', 0.7
            else:
                # Medium length hair - analyze patterns
                if self._detect_ponytail_pattern(hair_region):
                    return 'ponytail', 0.8
                elif self._detect_bun_pattern(hair_region):
                    return 'bun', 0.8
                elif self._detect_braid_pattern(hair_region):
                    return 'braids', 0.8
                elif curl_indicators == 0 and texture_std < 30:  # Straight medium
                    return 'straight_medium', 0.7
                else:
                    return 'straight_short', 0.6
                    
        except Exception as e:
            logger.error(f"Error classifying hairstyle: {e}")
            return 'unknown', 0.5
    
    def _detect_ponytail_pattern(self, hair_region):
        """Detect ponytail by looking for concentrated hair mass"""
        if hair_region is None or hair_region.size == 0:
            return False
        
        try:
            gray = cv2.cvtColor(hair_region, cv2.COLOR_RGB2GRAY)
            
            # Look for vertical concentration of hair
            h, w = gray.shape
            center_region = gray[:, w//3:2*w//3]
            
            # Check if hair is concentrated in center (ponytail characteristic)
            center_mean = np.mean(center_region)
            side_mean = (np.mean(gray[:, :w//3]) + np.mean(gray[:, 2*w//3:])) / 2
            
            return center_mean < side_mean * 0.8  # Dark hair concentrated in center
            
        except Exception as e:
            logger.error(f"Error detecting ponytail: {e}")
            return False
    
    def _detect_bun_pattern(self, hair_region):
        """Detect bun by looking for circular/oval concentrated mass"""
        if hair_region is None or hair_region.size == 0:
            return False
        
        try:
            gray = cv2.cvtColor(hair_region, cv2.COLOR_RGB2GRAY)
            
            # Look for concentrated circular mass (typical of buns)
            h, w = gray.shape
            center_h, center_w = h//2, w//2
            
            # Check concentration in center area
            center_region = gray[center_h-h//4:center_h+h//4, center_w-w//4:center_w+w//4]
            
            if center_region.size > 0:
                center_std = np.std(center_region)
                overall_std = np.std(gray)
                
                # Buns typically have low variation in center (smooth, concentrated)
                return center_std < overall_std * 0.7
            
            return False
            
        except Exception as e:
            logger.error(f"Error detecting bun: {e}")
            return False
    
    def _detect_braid_pattern(self, hair_region):
        """Enhanced braid detection using advanced pattern recognition"""
        if hair_region is None or hair_region.size == 0:
            return False
        
        try:
            # Try enhanced braid detection first
            from enhanced_braid_detector import enhanced_braid_detector
            
            # Save hair region as temporary image for analysis
            import tempfile
            import os
            
            with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as tmp_file:
                temp_path = tmp_file.name
                cv2.imwrite(temp_path, hair_region)
            
            try:
                # Run enhanced detection
                braid_result = enhanced_braid_detector.detect_braids_enhanced(temp_path, hair_region)
                
                # Clean up temp file
                os.unlink(temp_path)
                
                # Return True if braid detected with reasonable confidence
                return braid_result.get('is_braid', False) and braid_result.get('confidence', 0) > 50
                
            except Exception as enhanced_error:
                logger.warning(f"Enhanced braid detection failed: {enhanced_error}, falling back to basic detection")
                os.unlink(temp_path)
                
                # Fallback to original detection
                return self._detect_braid_pattern_basic(hair_region)
                
        except ImportError:
            # Enhanced detector not available, use basic detection
            return self._detect_braid_pattern_basic(hair_region)
    
    def _detect_braid_pattern_basic(self, hair_region):
        """Basic braid detection (original method)"""
        try:
            gray = cv2.cvtColor(hair_region, cv2.COLOR_RGB2GRAY)
            
            # Look for repetitive vertical patterns (characteristic of braids)
            edges = cv2.Canny(gray, 30, 100)
            
            # Analyze vertical patterns
            h, w = edges.shape
            if h > 20:
                # Check for repetitive horizontal lines (braid segments)
                horizontal_projection = np.sum(edges, axis=1)
                
                # Look for multiple peaks (braid segments)
                peaks = []
                for i in range(1, len(horizontal_projection)-1):
                    if (horizontal_projection[i] > horizontal_projection[i-1] and 
                        horizontal_projection[i] > horizontal_projection[i+1]):
                        peaks.append(i)
                
                # Braids typically have 3+ visible segments
                return len(peaks) >= 3
            
            return False
            
        except Exception as e:
            logger.error(f"Error detecting braids: {e}")
            return False
    
    def detect_hairstyle(self, image_path):
        """
        Main function to detect hairstyle from image
        
        Args:
            image_path: Path to the image file
            
        Returns:
            dict: Contains hairstyle classification and confidence
        """
        try:
            # Preprocess image
            image = self._preprocess_image(image_path)
            if image is None:
                return {'hairstyle': 'unknown', 'confidence': 0.0, 'error': 'Could not load image'}
            
            # Detect hair region
            hair_region, bbox = self._detect_hair_region(image)
            
            # Analyze hair texture and features
            features = self._analyze_hair_texture(hair_region)
            
            # Classify hairstyle
            hairstyle, confidence = self._classify_hairstyle(features, hair_region)
            
            return {
                'hairstyle': hairstyle,
                'confidence': confidence,
                'features': features,
                'hair_bbox': bbox
            }
            
        except Exception as e:
            logger.error(f"Error in hairstyle detection: {e}")
            return {'hairstyle': 'unknown', 'confidence': 0.0, 'error': str(e)}
    
    def get_hairstyle_message(self, hairstyle, confidence):
        """Generate personality-filled message about detected hairstyle"""
        
        messages = {
            'straight_long': [
                "Rocking that sleek straight goddess look! ✨",
                "Your straight hair is giving mermaid vibes! 🧜‍♀️",
                "That silky straight perfection though! 💫"
            ],
            'straight_short': [
                "Short and sweet perfection! 💁‍♀️",
                "That chic bob is absolutely stunning! ✨",
                "Serving sophisticated vibes with that cut! 👑"
            ],
            'wavy': [
                "Those waves are pure magic! 🌊",
                "Beachy wave goddess energy! 🏖️",
                "Your waves are absolutely dreamy! ✨"
            ],
            'curly': [
                "Curl power activated! Your curls are GORGEOUS! 💪",
                "Those curls are giving life! Absolutely stunning! 🌀",
                "Curly queen serving looks! 👑"
            ],
            'ponytail': [
                "Rocking that ponytail like a warrior princess! 💪",
                "Ponytail perfection - sporty and chic! ⚡",
                "That high pony is giving boss energy! 👑"
            ],
            'bun': [
                "Bun game strong! Elegant and effortless! 🎯",
                "That bun is serving sophisticated vibes! ✨",
                "Messy bun or elegant updo? Either way, you're slaying! 💫"
            ],
            'braids': [
                "Rocking that tight braid like a warrior princess! 💪",
                "Braid perfection! Your styling game is on point! ✨",
                "Those braids are absolutely gorgeous! 🌟"
            ],
            'messy': [
                "Messy Queen energy! That effortless look is perfect! 👑",
                "Bedhead chic - sometimes messy is the best look! ✨",
                "That 'I woke up like this' vibe is everything! 💫"
            ],
            'bob': [
                "Bob perfection! Classic and chic! 💁‍♀️",
                "That bob is giving main character energy! ⚡",
                "Serving looks with that perfect bob! ✨"
            ],
            'pixie': [
                "Pixie power! Short hair, bold personality! ⚡",
                "That pixie cut is absolutely fierce! 💪",
                "Short and stunning - pixie perfection! ✨"
            ],
            'unknown': [
                "Your unique style is absolutely gorgeous! ✨",
                "Serving your own signature look! 💫",
                "That personal style is everything! 👑"
            ]
        }
        
        if hairstyle in messages:
            return np.random.choice(messages[hairstyle])
        else:
            return "Your hairstyle is absolutely stunning! ✨"