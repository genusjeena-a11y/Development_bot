"""
User Conversation State Manager
Tracks user states for interactive learning and multi-step conversations
"""
import json
import time
import os
from typing import Dict, Optional, Any
import logging

logger = logging.getLogger(__name__)

class UserConversationState:
    def __init__(self):
        self.state_file = 'user_states.json'
        self.states = self.load_states()
        # States expire after 10 minutes of inactivity
        self.state_timeout = 600  # 10 minutes in seconds
        
    def load_states(self) -> Dict:
        """Load user states from file"""
        try:
            if os.path.exists(self.state_file):
                with open(self.state_file, 'r') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            logger.error(f"Error loading user states: {e}")
            return {}
    
    def save_states(self):
        """Save user states to file"""
        try:
            with open(self.state_file, 'w') as f:
                json.dump(self.states, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving user states: {e}")
    
    def set_waiting_for_hairstyle_name(self, user_id: str, photo_path: str, unique_id: str, detected_style: str):
        """Set user state to waiting for hairstyle name"""
        self.states[str(user_id)] = {
            'state': 'waiting_for_hairstyle_name',
            'photo_path': photo_path,
            'unique_id': unique_id,
            'detected_style': detected_style,
            'timestamp': time.time()
        }
        self.save_states()
        logger.info(f"User {user_id} is now waiting to provide hairstyle name")
    
    def is_waiting_for_hairstyle_name(self, user_id: str) -> bool:
        """Check if user is waiting to provide hairstyle name"""
        user_state = self.states.get(str(user_id))
        if not user_state:
            return False
        
        # Check if state has expired
        if time.time() - user_state.get('timestamp', 0) > self.state_timeout:
            self.clear_user_state(user_id)
            return False
        
        return user_state.get('state') == 'waiting_for_hairstyle_name'
    
    def get_learning_context(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Get the learning context for a user"""
        user_state = self.states.get(str(user_id))
        if not user_state or user_state.get('state') != 'waiting_for_hairstyle_name':
            return None
        
        return {
            'photo_path': user_state.get('photo_path'),
            'unique_id': user_state.get('unique_id'),
            'detected_style': user_state.get('detected_style'),
            'timestamp': user_state.get('timestamp')
        }
    
    def clear_user_state(self, user_id: str):
        """Clear the state for a specific user"""
        if str(user_id) in self.states:
            del self.states[str(user_id)]
            self.save_states()
            logger.info(f"Cleared state for user {user_id}")
    
    def cleanup_expired_states(self):
        """Remove expired user states"""
        current_time = time.time()
        expired_users = []
        
        for user_id, state in self.states.items():
            if current_time - state.get('timestamp', 0) > self.state_timeout:
                expired_users.append(user_id)
        
        for user_id in expired_users:
            del self.states[user_id]
        
        if expired_users:
            self.save_states()
            logger.info(f"Cleaned up expired states for {len(expired_users)} users")
    
    def set_makeover_mode(self, user_id: str, selected_style: str):
        """Set user to makeover mode"""
        self.states[str(user_id)] = {
            'state': 'makeover_mode',
            'selected_style': selected_style,
            'timestamp': time.time()
        }
        self.save_states()
    
    def is_in_makeover_mode(self, user_id: str) -> bool:
        """Check if user is in makeover mode"""
        user_state = self.states.get(str(user_id))
        if not user_state:
            return False
        
        # Check if state has expired
        if time.time() - user_state.get('timestamp', 0) > self.state_timeout:
            self.clear_user_state(user_id)
            return False
        
        return user_state.get('state') == 'makeover_mode'

# Global instance
user_state_manager = UserConversationState()