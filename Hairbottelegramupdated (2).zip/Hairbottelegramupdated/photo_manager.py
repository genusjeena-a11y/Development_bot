"""
Photo Manager - Local storage for unique IDs and photo management
No database dependency, all data stored in local JSON files
"""
import json
import os
import uuid
import glob
from datetime import datetime
from typing import Dict, List, Optional

class PhotoManager:
    def __init__(self, data_file='photo_data.json', upload_folder='uploads'):
        self.data_file = data_file
        self.upload_folder = upload_folder
        self.data = self._load_data()
        
        # Ensure upload folder exists
        os.makedirs(upload_folder, exist_ok=True)
    
    def _load_data(self) -> Dict:
        """Load photo data from JSON file"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                pass
        
        # Return default structure
        return {
            'photos': {},  # unique_id -> {name, nationality, scores, timestamp}
            'leaderboards': {
                'overall': [],
                'length': [],
                'thickness': [],
                'silkiness': []
            }
        }
    
    def _save_data(self):
        """Save photo data to JSON file"""
        try:
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving photo data: {e}")
    
    def add_photo(self, person_name: str, nationality: str, scores: Dict) -> str:
        """Add a new photo entry and return unique ID"""
        unique_id = str(uuid.uuid4())
        
        self.data['photos'][unique_id] = {
            'name': person_name,
            'nationality': nationality,
            'scores': scores,
            'timestamp': datetime.now().isoformat()
        }
        
        self._save_data()
        return unique_id
    
    def get_photo_info(self, unique_id: str) -> Optional[Dict]:
        """Get photo information by unique ID"""
        return self.data['photos'].get(unique_id)
    
    def update_leaderboards(self, leaderboards: Dict):
        """Update leaderboard data"""
        self.data['leaderboards'] = leaderboards
        self._save_data()
    
    def get_leaderboards(self) -> Dict:
        """Get current leaderboard data"""
        return self.data['leaderboards']
    
    def reset_leaderboard(self, category: str):
        """Reset a specific leaderboard category"""
        if category in self.data['leaderboards']:
            self.data['leaderboards'][category] = []
            self._save_data()
    
    def reset_all_leaderboards(self):
        """Reset all leaderboard categories"""
        self.data['leaderboards'] = {
            'overall': [],
            'length': [],
            'thickness': [],
            'silkiness': []
        }
        self._save_data()
    
    def reset_all_data(self):
        """Reset all data including photos and leaderboards"""
        # Reset leaderboards
        self.data['leaderboards'] = {
            'overall': [],
            'length': [],
            'thickness': [],
            'silkiness': []
        }
        
        # Clear all photo data
        self.data['photos'] = {}
        
        # Delete all photo files
        photo_files = glob.glob(os.path.join(self.upload_folder, '*.jpg'))
        photo_files.extend(glob.glob(os.path.join(self.upload_folder, '*.jpeg')))
        photo_files.extend(glob.glob(os.path.join(self.upload_folder, '*.png')))
        
        deleted_count = 0
        for photo_file in photo_files:
            try:
                os.remove(photo_file)
                deleted_count += 1
            except Exception as e:
                print(f"Error deleting {photo_file}: {e}")
        
        self._save_data()
        return {'deleted_photos': deleted_count}
    
    def get_all_photos(self) -> Dict:
        """Get all photo data"""
        return self.data['photos']
    
    def cleanup_photos_keep_top3(self):
        """Keep only top 3 photos in each category, remove all others"""
        # Get top 3 unique IDs from each leaderboard category
        protected_ids = set()
        for category_name, category_entries in self.data['leaderboards'].items():
            # Keep top 3 entries from each category
            top_3_entries = category_entries[:3]
            for entry in top_3_entries:
                if isinstance(entry, dict) and 'unique_id' in entry:
                    protected_ids.add(entry['unique_id'])
        
        # Find all photo files in upload folder
        photo_files = glob.glob(os.path.join(self.upload_folder, '*.jpg'))
        photo_files.extend(glob.glob(os.path.join(self.upload_folder, '*.jpeg')))
        photo_files.extend(glob.glob(os.path.join(self.upload_folder, '*.png')))
        
        deleted_count = 0
        kept_count = 0
        for photo_file in photo_files:
            filename = os.path.basename(photo_file)
            file_id = filename.split('.')[0]  # Remove extension
            
            # If this photo ID is not in top 3 of any category, delete it
            if file_id not in protected_ids:
                try:
                    os.remove(photo_file)
                    # Also remove from data if exists
                    if file_id in self.data['photos']:
                        del self.data['photos'][file_id]
                    deleted_count += 1
                except Exception as e:
                    print(f"Error deleting {photo_file}: {e}")
            else:
                kept_count += 1
        
        # Remove photos from leaderboards that are not in top 3
        for category_name in self.data['leaderboards']:
            # Keep only top 3 entries
            self.data['leaderboards'][category_name] = self.data['leaderboards'][category_name][:3]
        
        self._save_data()
        return {'deleted': deleted_count, 'kept': kept_count, 'protected_ids': len(protected_ids)}

    def cleanup_unused_photos(self):
        """Remove photos not in any leaderboard (legacy method)"""
        # Get all unique IDs currently in leaderboards
        used_ids = set()
        for category_entries in self.data['leaderboards'].values():
            for entry in category_entries:
                if isinstance(entry, dict) and 'unique_id' in entry:
                    used_ids.add(entry['unique_id'])
        
        # Find all photo files in upload folder
        photo_files = glob.glob(os.path.join(self.upload_folder, '*.jpg'))
        photo_files.extend(glob.glob(os.path.join(self.upload_folder, '*.jpeg')))
        photo_files.extend(glob.glob(os.path.join(self.upload_folder, '*.png')))
        
        deleted_count = 0
        for photo_file in photo_files:
            filename = os.path.basename(photo_file)
            file_id = filename.split('.')[0]  # Remove extension
            
            # If this photo ID is not in leaderboards, delete it
            if file_id not in used_ids:
                try:
                    os.remove(photo_file)
                    # Also remove from data if exists
                    if file_id in self.data['photos']:
                        del self.data['photos'][file_id]
                    deleted_count += 1
                except Exception as e:
                    print(f"Error deleting {photo_file}: {e}")
        
        if deleted_count > 0:
            self._save_data()
            print(f"Cleaned up {deleted_count} unused photos")
        
        return deleted_count
    
    def get_photo_path(self, unique_id: str) -> Optional[str]:
        """Get full path to photo file"""
        # Try different extensions
        for ext in ['.jpg', '.jpeg', '.png']:
            photo_path = os.path.join(self.upload_folder, f"{unique_id}{ext}")
            if os.path.exists(photo_path):
                return photo_path
        return None
    
    def photo_exists(self, unique_id: str) -> bool:
        """Check if photo file exists"""
        return self.get_photo_path(unique_id) is not None
    
    def get_short_id(self, unique_id: str) -> str:
        """Get shortened version of unique ID for display"""
        return unique_id[:8] if unique_id else ""
    
    def add_new_category(self, category_name: str) -> bool:
        """Add a new leaderboard category"""
        category_key = category_name.lower().replace(' ', '_')
        
        if category_key in self.data['leaderboards']:
            return False  # Category already exists
        
        self.data['leaderboards'][category_key] = []
        self._save_data()
        return True
    
    def get_category_names(self) -> List[str]:
        """Get list of all category names"""
        return list(self.data['leaderboards'].keys())

# Global instance
photo_manager = PhotoManager()