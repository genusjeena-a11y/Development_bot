#!/bin/bash

echo "🔥 Starting Replit cleanup..."

# Clean pip cache
echo "📦 Cleaning pip cache..."
rm -rf ~/.cache/pip

# Remove Python __pycache__ files
echo "🧽 Removing __pycache__ folders..."
find . -type d -name "__pycache__" -exec rm -rf {} +

# Clear temporary files (safe in Replit)
echo "🗑 Clearing /tmp directory..."
rm -rf /tmp/*

# Remove unnecessary log files over 2MB
echo "🪵 Deleting large .log files (>2MB)..."
find . -type f -name "*.log" -size +2M -exec rm -f {} +

# Delete unused virtual environments (if you have old ones)
echo "🧼 Removing old virtual environments (if any)..."
find . -type d -name "venv" -exec rm -rf {} +

# Optional: Clean npm cache if using Node.js
echo "📦 Cleaning Node/npm cache (if present)..."
rm -rf ~/.npm
rm -rf ~/.cache/yarn

echo "✅ Replit cleanup done! You just Marie Kondo’d your project 🎉"
