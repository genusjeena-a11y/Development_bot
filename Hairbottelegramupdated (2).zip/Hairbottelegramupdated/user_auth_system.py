import json
import os
import random
import string
import time
import logging
from typing import Dict, Optional, Tuple

logger = logging.getLogger(__name__)

class UserAuthSystem:
    def __init__(self, auth_file='user_auth.json'):
        self.auth_file = auth_file
        self.users = self._load_users()
        self.pending_registrations = {}  # temp storage for login codes
        
    def _load_users(self) -> Dict:
        """Load user data from JSON file"""
        if os.path.exists(self.auth_file):
            try:
                with open(self.auth_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                logger.error(f"Error loading user auth data from {self.auth_file}")
                pass
        
        return {}
    
    def _save_users(self):
        """Save user data to JSON file"""
        try:
            with open(self.auth_file, 'w', encoding='utf-8') as f:
                json.dump(self.users, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving user auth data: {e}")
    
    def _generate_login_code(self) -> str:
        """Generate a unique 6-digit login code"""
        return ''.join(random.choices(string.digits, k=6))
    
    def initiate_registration(self, telegram_id: str, username: str = None) -> str:
        """Start the registration process and return login code"""
        login_code = self._generate_login_code()
        
        # Store pending registration with expiry (10 minutes)
        self.pending_registrations[telegram_id] = {
            'login_code': login_code,
            'username': username,
            'expires': time.time() + 600,  # 10 minutes
            'attempts': 0
        }
        
        logger.info(f"Registration initiated for {telegram_id} with code {login_code}")
        return login_code
    
    def verify_login_code(self, telegram_id: str, provided_code: str) -> Tuple[bool, str]:
        """Verify login code and complete registration"""
        if telegram_id not in self.pending_registrations:
            return False, "No registration process found. Please start with /start again."
        
        pending = self.pending_registrations[telegram_id]
        
        # Check if expired
        if time.time() > pending['expires']:
            del self.pending_registrations[telegram_id]
            return False, "Login code expired. Please start with /start again."
        
        # Check attempts
        if pending['attempts'] >= 3:
            del self.pending_registrations[telegram_id]
            return False, "Too many failed attempts. Please start with /start again."
        
        # Verify code
        if provided_code != pending['login_code']:
            pending['attempts'] += 1
            return False, f"Invalid login code. {3 - pending['attempts']} attempts remaining."
        
        # Create user account
        user_data = {
            'telegram_id': telegram_id,
            'username': pending.get('username', f'User_{telegram_id}'),
            'created_at': time.time(),
            'is_admin': False,
            'submissions_count': 0,
            'last_activity': time.time()
        }
        
        self.users[telegram_id] = user_data
        self._save_users()
        
        # Clean up pending registration
        del self.pending_registrations[telegram_id]
        
        logger.info(f"User {telegram_id} successfully registered")
        return True, "Account created successfully! You can now submit photos."
    
    def is_user_registered(self, telegram_id: str) -> bool:
        """Check if user is registered"""
        return str(telegram_id) in self.users
    
    def get_user(self, telegram_id: str) -> Optional[Dict]:
        """Get user data"""
        return self.users.get(str(telegram_id))
    
    def update_user_activity(self, telegram_id: str):
        """Update user's last activity timestamp"""
        if str(telegram_id) in self.users:
            self.users[str(telegram_id)]['last_activity'] = time.time()
            self._save_users()
    
    def delete_user_account(self, telegram_id: str) -> bool:
        """Delete user account when they delete chat"""
        if str(telegram_id) in self.users:
            del self.users[str(telegram_id)]
            self._save_users()
            logger.info(f"User account {telegram_id} deleted")
            return True
        return False
    
    def increment_user_submissions(self, telegram_id: str):
        """Increment user's submission count"""
        if str(telegram_id) in self.users:
            self.users[str(telegram_id)]['submissions_count'] += 1
            self.update_user_activity(telegram_id)
    
    def is_admin(self, telegram_id: str) -> bool:
        """Check if user has admin privileges"""
        user = self.get_user(telegram_id)
        return user and user.get('is_admin', False)
    
    def grant_admin_access(self, telegram_id: str):
        """Grant admin access to user (temporary for session)"""
        if str(telegram_id) in self.users:
            # Create temporary admin session (expires in 30 minutes)
            self.users[str(telegram_id)]['temp_admin'] = time.time() + 1800
            self._save_users()
    
    def grant_temp_admin(self, telegram_id: str) -> bool:
        """Alias for grant_admin_access for consistency"""
        if str(telegram_id) in self.users:
            self.grant_admin_access(telegram_id)
            return True
        return False
    
    def has_temp_admin(self, telegram_id: str) -> bool:
        """Check if user has temporary admin access"""
        user = self.get_user(telegram_id)
        if not user:
            return False
        
        temp_admin = user.get('temp_admin', 0)
        if temp_admin > time.time():
            return True
        
        # Clean up expired temp admin
        if 'temp_admin' in self.users[str(telegram_id)]:
            del self.users[str(telegram_id)]['temp_admin']
            self._save_users()
        
        return False
    
    def get_user_stats(self) -> Dict:
        """Get overall user statistics"""
        total_users = len(self.users)
        active_users = sum(1 for user in self.users.values() 
                          if time.time() - user.get('last_activity', 0) < 86400)  # 24 hours
        total_submissions = sum(user.get('submissions_count', 0) for user in self.users.values())
        
        return {
            'total_users': total_users,
            'active_users_24h': active_users,
            'total_submissions': total_submissions
        }
    
    def cleanup_expired_registrations(self):
        """Clean up expired pending registrations"""
        current_time = time.time()
        expired_keys = [
            telegram_id for telegram_id, data in self.pending_registrations.items()
            if current_time > data['expires']
        ]
        
        for key in expired_keys:
            del self.pending_registrations[key]