"""
AI Makeover System - Virtual hairstyle overlay using computer vision
Handles user photo + reference hairstyle processing and blending
"""
import os
import cv2
import numpy as np
import uuid
import glob
import mediapipe as mp
from PIL import Image, ImageFilter
import logging
from typing import Dict, Tuple, Optional
import json
import time

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class AIMakeoverSystem:
    def __init__(self, temp_folder='makeover_temp'):
        self.temp_folder = temp_folder
        self.user_sessions = {}  # Track user makeover sessions
        
        # Create temp folder
        os.makedirs(temp_folder, exist_ok=True)
        
        # Initialize MediaPipe
        self.mp_selfie = mp.solutions.selfie_segmentation
        self.mp_face_mesh = mp.solutions.face_mesh
        self.mp_drawing = mp.solutions.drawing_utils
        
        # Initialize models
        self.selfie_segmentation = self.mp_selfie.SelfieSegmentation(model_selection=1)
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            static_image_mode=True,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5
        )
    
    def can_user_makeover(self, user_id: str, is_admin: bool = False) -> Tuple[bool, str]:
        """Check if user can start a new makeover session"""
        if is_admin:
            return True, "Admin access granted"
        
        # Check if user has active session
        if user_id in self.user_sessions:
            session = self.user_sessions[user_id]
            if session.get('status') == 'active':
                return False, "You already have an active makeover session. Complete it first or wait for it to expire."
        
        return True, "Ready for makeover"
    
    def start_makeover_session(self, user_id: str) -> str:
        """Start a new makeover session for user"""
        session_id = str(uuid.uuid4())
        
        self.user_sessions[user_id] = {
            'session_id': session_id,
            'status': 'active',
            'created_at': time.time(),
            'user_photo': None,
            'reference_photo': None,
            'step': 'waiting_user_photo'  # waiting_user_photo -> waiting_reference_photo -> processing -> completed
        }
        
        return session_id
    
    def save_user_photo(self, user_id: str, photo_path: str) -> bool:
        """Save user's photo to session"""
        if user_id not in self.user_sessions:
            return False
        
        session = self.user_sessions[user_id]
        if session['step'] != 'waiting_user_photo':
            return False
        
        # Generate unique filename
        user_photo_id = str(uuid.uuid4())
        user_photo_path = os.path.join(self.temp_folder, f"{user_photo_id}_user.jpg")
        
        # Copy photo to temp folder
        try:
            import shutil
            shutil.copy2(photo_path, user_photo_path)
            
            session['user_photo'] = user_photo_path
            session['user_photo_id'] = user_photo_id
            session['step'] = 'waiting_reference_photo'
            
            return True
        except Exception as e:
            logger.error(f"Error saving user photo: {e}")
            return False
    
    def save_reference_photo(self, user_id: str, photo_path: str) -> bool:
        """Save reference hairstyle photo to session"""
        if user_id not in self.user_sessions:
            return False
        
        session = self.user_sessions[user_id]
        if session['step'] != 'waiting_reference_photo':
            return False
        
        # Generate unique filename
        ref_photo_id = str(uuid.uuid4())
        ref_photo_path = os.path.join(self.temp_folder, f"{ref_photo_id}_ref.jpg")
        
        # Copy photo to temp folder
        try:
            import shutil
            shutil.copy2(photo_path, ref_photo_path)
            
            session['reference_photo'] = ref_photo_path
            session['reference_photo_id'] = ref_photo_id
            session['step'] = 'processing'
            
            return True
        except Exception as e:
            logger.error(f"Error saving reference photo: {e}")
            return False
    
    def get_session_status(self, user_id: str) -> Dict:
        """Get current session status"""
        if user_id not in self.user_sessions:
            return {'status': 'no_session'}
        
        return self.user_sessions[user_id]
    
    def segment_hair(self, image_path: str) -> Tuple[np.ndarray, np.ndarray]:
        """Extract hair region from image using MediaPipe"""
        try:
            # Load image with proper error handling
            image = cv2.imread(image_path)
            if image is None:
                raise ValueError(f"Could not load image: {image_path}")
            
            logger.info(f"Loaded image shape: {image.shape}, dtype: {image.dtype}")
            logger.info(f"Image mode: BGR (OpenCV default)")
            
            # Convert BGR to RGB for MediaPipe processing
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            logger.info(f"Converted to RGB shape: {image_rgb.shape}, dtype: {image_rgb.dtype}")
            
            # Get segmentation mask
            results = self.selfie_segmentation.process(image_rgb)
            
            # Create hair mask (approximate - selfie segmentation gives person mask)
            # We'll use this as base and refine using color/texture analysis
            person_mask = results.segmentation_mask
            logger.info(f"Person mask shape: {person_mask.shape}, dtype: {person_mask.dtype}")
            
            # Convert to binary mask
            binary_mask = (person_mask > 0.5).astype(np.uint8) * 255
            logger.info(f"Binary mask shape: {binary_mask.shape}, dtype: {binary_mask.dtype}")
            
            # Refine mask to focus on hair region using face landmarks
            refined_mask = self._refine_hair_mask(image_rgb, binary_mask)
            logger.info(f"Refined mask shape: {refined_mask.shape}, dtype: {refined_mask.dtype}")
            
            # Return RGB image (not BGR) for consistent processing
            return image_rgb, refined_mask
            
        except Exception as e:
            logger.error(f"Error in hair segmentation: {e}")
            raise
    
    def _refine_hair_mask(self, image_rgb: np.ndarray, person_mask: np.ndarray) -> np.ndarray:
        """Refine mask to focus on hair region using multiple techniques"""
        try:
            h, w = person_mask.shape
            
            # Step 1: Exclude face region using landmarks
            hair_mask = self._exclude_face_from_person_mask(image_rgb, person_mask)
            
            # Step 2: Focus on upper region (hair area)
            hair_mask[int(h*0.7):, :] = 0  # Remove lower 30%
            
            # Step 3: Color-based refinement
            color_hair_mask = self._detect_hair_by_color_analysis(image_rgb)
            if color_hair_mask is not None:
                # Combine with color detection
                hair_mask = cv2.bitwise_and(hair_mask, color_hair_mask)
            
            # Step 4: Morphological operations to clean up
            kernel = np.ones((3, 3), np.uint8)
            hair_mask = cv2.morphologyEx(hair_mask, cv2.MORPH_CLOSE, kernel)
            hair_mask = cv2.morphologyEx(hair_mask, cv2.MORPH_OPEN, kernel)
            
            # Step 5: Gaussian blur for smooth edges
            hair_mask = cv2.GaussianBlur(hair_mask, (5, 5), 1)
            
            return hair_mask
            
        except Exception as e:
            logger.error(f"Error refining hair mask: {e}")
            # Fallback: return upper portion of person mask
            hair_mask = np.zeros_like(person_mask)
            hair_mask[:int(h*0.5), :] = person_mask[:int(h*0.5), :]
            return hair_mask
    
    def _exclude_face_from_person_mask(self, image_rgb: np.ndarray, person_mask: np.ndarray) -> np.ndarray:
        """Remove face area from person mask to isolate hair"""
        try:
            results = self.face_mesh.process(image_rgb)
            h, w = image_rgb.shape[:2]
            
            if not results.multi_face_landmarks:
                # No face found, just use upper portion
                hair_mask = person_mask.copy()
                hair_mask[int(h*0.6):, :] = 0
                return hair_mask
            
            # Create face exclusion mask
            face_mask = np.zeros((h, w), dtype=np.uint8)
            
            for face_landmarks in results.multi_face_landmarks:
                # Get face oval points (simplified)
                face_points = []
                # Key face contour indices
                face_indices = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288,
                               397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136,
                               172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109]
                
                for idx in face_indices[:20]:  # Use fewer points for stability
                    if idx < len(face_landmarks.landmark):
                        x = int(face_landmarks.landmark[idx].x * w)
                        y = int(face_landmarks.landmark[idx].y * h)
                        face_points.append((x, y))
                
                if len(face_points) > 3:
                    face_points = np.array(face_points, dtype=np.int32)
                    cv2.fillPoly(face_mask, [face_points], 255)
            
            # Hair = person - face
            hair_mask = cv2.bitwise_and(person_mask, cv2.bitwise_not(face_mask))
            
            return hair_mask
            
        except Exception as e:
            logger.warning(f"Face exclusion failed: {e}")
            return person_mask
    
    def _detect_hair_by_color_analysis(self, image_rgb: np.ndarray) -> Optional[np.ndarray]:
        """Detect hair using color analysis in HSV space"""
        try:
            hsv = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2HSV)
            h, w = image_rgb.shape[:2]
            
            # Define hair color ranges in HSV
            hair_color_ranges = [
                # Black/Dark brown hair
                ((0, 0, 0), (180, 255, 70)),
                # Brown hair
                ((8, 30, 20), (25, 255, 200)),
                # Blonde hair  
                ((15, 20, 80), (35, 255, 255)),
                # Red/Auburn hair
                ((0, 100, 50), (15, 255, 255)),
                # Gray/Silver hair
                ((0, 0, 150), (180, 50, 255))
            ]
            
            combined_mask = np.zeros((h, w), dtype=np.uint8)
            
            for lower, upper in hair_color_ranges:
                color_mask = cv2.inRange(hsv, lower, upper)
                combined_mask = cv2.bitwise_or(combined_mask, color_mask)
            
            # Clean up the mask
            kernel = np.ones((5, 5), np.uint8)
            combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_CLOSE, kernel)
            combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_OPEN, kernel)
            
            # Only return if significant hair area detected
            hair_area_ratio = np.sum(combined_mask > 0) / (h * w)
            if hair_area_ratio > 0.02:  # At least 2% of image
                return combined_mask
            else:
                return None
                
        except Exception as e:
            logger.warning(f"Color-based hair detection failed: {e}")
            return None
    
    def align_and_transform_hair(self, user_image: np.ndarray, ref_image: np.ndarray, 
                                ref_hair_mask: np.ndarray) -> np.ndarray:
        """Align and transform reference hair to fit user's head with proper aspect ratio handling"""
        try:
            logger.info("Starting hair alignment and transformation")
            
            # Get face landmarks for both images
            user_face = self._get_face_landmarks(user_image)
            ref_face = self._get_face_landmarks(ref_image)
            
            user_h, user_w = user_image.shape[:2]
            ref_h, ref_w = ref_image.shape[:2]
            
            logger.info(f"User image dimensions: {user_w}x{user_h}")
            logger.info(f"Reference image dimensions: {ref_w}x{ref_h}")
            logger.info(f"Reference mask shape: {ref_hair_mask.shape}")
            
            if user_face is None or ref_face is None:
                logger.warning("Face landmarks not found, using aspect-ratio preserving resize")
                # Fallback: proper aspect ratio resize
                return self._resize_with_aspect_ratio(ref_hair_mask, (user_w, user_h))
            
            # Calculate transformation matrix
            transform_matrix = self._calculate_hair_transform(user_face, ref_face, user_image.shape[:2])
            
            # Apply transformation to reference hair
            transformed_hair = cv2.warpAffine(ref_hair_mask, transform_matrix, (user_w, user_h))
            
            logger.info(f"Transformed hair shape: {transformed_hair.shape}")
            return transformed_hair
            
        except Exception as e:
            logger.error(f"Error in hair alignment: {e}")
            # Fallback: aspect-ratio preserving resize
            h, w = user_image.shape[:2]
            return self._resize_with_aspect_ratio(ref_hair_mask, (w, h))
    
    def _resize_with_aspect_ratio(self, image: np.ndarray, target_size: Tuple[int, int], 
                                 maintain_aspect: bool = True) -> np.ndarray:
        """Resize image while maintaining aspect ratio or force-fitting as needed"""
        try:
            target_w, target_h = target_size
            orig_h, orig_w = image.shape[:2]
            
            logger.info(f"Resizing from {orig_w}x{orig_h} to {target_w}x{target_h}")
            
            if maintain_aspect:
                # Calculate aspect ratios
                orig_aspect = orig_w / orig_h
                target_aspect = target_w / target_h
                
                if orig_aspect > target_aspect:
                    # Image is wider, fit to width
                    new_w = target_w
                    new_h = int(target_w / orig_aspect)
                else:
                    # Image is taller, fit to height
                    new_h = target_h
                    new_w = int(target_h * orig_aspect)
                
                # Resize with aspect ratio preserved
                resized = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)
                
                # Create padded result if needed
                result = np.zeros((target_h, target_w), dtype=image.dtype)
                
                # Center the resized image
                y_offset = (target_h - new_h) // 2
                x_offset = (target_w - new_w) // 2
                
                result[y_offset:y_offset+new_h, x_offset:x_offset+new_w] = resized
                
                logger.info(f"Aspect-ratio preserved resize: {new_w}x{new_h} with padding")
                return result
            else:
                # Force resize to exact dimensions (may distort)
                logger.info("Force resizing to exact dimensions")
                return cv2.resize(image, (target_w, target_h), interpolation=cv2.INTER_LANCZOS4)
                
        except Exception as e:
            logger.error(f"Error in resize_with_aspect_ratio: {e}")
            # Simple fallback
            return cv2.resize(image, target_size, interpolation=cv2.INTER_LANCZOS4)
    
    def _get_face_landmarks(self, image: np.ndarray) -> Optional[Dict]:
        """Get key face landmarks for alignment"""
        try:
            results = self.face_mesh.process(image)
            
            if not results.multi_face_landmarks:
                return None
            
            face_landmarks = results.multi_face_landmarks[0]
            h, w = image.shape[:2]
            
            # Key landmark indices for alignment
            key_points = {
                'forehead_center': 9,   # Top of forehead
                'left_temple': 127,     # Left temple
                'right_temple': 356,    # Right temple
                'nose_tip': 1,          # Nose tip
                'chin': 175             # Chin
            }
            
            landmarks = {}
            for name, idx in key_points.items():
                landmark = face_landmarks.landmark[idx]
                landmarks[name] = (int(landmark.x * w), int(landmark.y * h))
            
            return landmarks
            
        except Exception as e:
            logger.error(f"Error getting face landmarks: {e}")
            return None
    
    def _calculate_hair_transform(self, user_landmarks: Dict, ref_landmarks: Dict, target_shape: Tuple) -> np.ndarray:
        """Calculate transformation matrix to align reference hair with user's head"""
        try:
            # Use key points for alignment
            user_points = np.array([
                user_landmarks['forehead_center'],
                user_landmarks['left_temple'],
                user_landmarks['right_temple']
            ], dtype=np.float32)
            
            ref_points = np.array([
                ref_landmarks['forehead_center'],
                ref_landmarks['left_temple'],
                ref_landmarks['right_temple']
            ], dtype=np.float32)
            
            # Calculate affine transformation
            transform_matrix = cv2.getAffineTransform(ref_points, user_points)
            
            return transform_matrix
            
        except Exception as e:
            logger.error(f"Error calculating transformation: {e}")
            # Return identity matrix as fallback
            return np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32)
    
    def blend_hair(self, user_image: np.ndarray, reference_hair: np.ndarray, 
                   user_hair_mask: np.ndarray, transformed_ref_hair: np.ndarray) -> np.ndarray:
        """Blend reference hair onto user image with proper RGBA handling and color conversion"""
        try:
            logger.info("Starting advanced hair blending process")
            logger.info(f"User image shape: {user_image.shape}, dtype: {user_image.dtype}")
            logger.info(f"Reference hair shape: {reference_hair.shape}, dtype: {reference_hair.dtype}")
            logger.info(f"User hair mask shape: {user_hair_mask.shape}, dtype: {user_hair_mask.dtype}")
            logger.info(f"Transformed ref hair shape: {transformed_ref_hair.shape}, dtype: {transformed_ref_hair.dtype}")
            
            # Step 1: Ensure all images are in RGB format and same data type
            result_image = user_image.copy().astype(np.uint8)
            
            # Convert reference hair to RGB if needed (it should already be RGB from segment_hair)
            if len(reference_hair.shape) == 3 and reference_hair.shape[2] == 3:
                ref_hair_rgb = reference_hair.astype(np.uint8)
            else:
                logger.error(f"Unexpected reference hair format: {reference_hair.shape}")
                ref_hair_rgb = reference_hair.astype(np.uint8)
            
            logger.info("All images converted to consistent RGB format")
            
            # Step 2: Create proper alpha mask from transformed reference hair
            # Ensure mask is normalized and proper size
            user_h, user_w = result_image.shape[:2]
            
            if transformed_ref_hair.shape[:2] != (user_h, user_w):
                transformed_ref_hair = self._resize_with_aspect_ratio(
                    transformed_ref_hair, (user_w, user_h), maintain_aspect=False
                )
            
            # Create alpha mask (normalized to 0-1 range)
            alpha_mask = transformed_ref_hair.astype(np.float32) / 255.0
            logger.info(f"Alpha mask shape: {alpha_mask.shape}, min: {alpha_mask.min()}, max: {alpha_mask.max()}")
            
            # Step 3: Resize reference hair to match user image
            if ref_hair_rgb.shape[:2] != (user_h, user_w):
                ref_hair_resized = self._resize_with_aspect_ratio(
                    ref_hair_rgb, (user_w, user_h), maintain_aspect=False
                )
            else:
                ref_hair_resized = ref_hair_rgb
            
            logger.info(f"Reference hair resized to: {ref_hair_resized.shape}")
            
            # Step 4: Apply advanced alpha blending
            # Create 3-channel alpha mask for proper blending
            if len(alpha_mask.shape) == 2:
                alpha_mask_3ch = np.stack([alpha_mask] * 3, axis=-1)
            else:
                alpha_mask_3ch = alpha_mask
            
            # Apply Gaussian blur to alpha mask for smooth transitions
            alpha_mask_3ch = cv2.GaussianBlur(alpha_mask_3ch, (5, 5), 2)
            
            # Ensure all arrays are float32 for precise blending
            result_float = result_image.astype(np.float32)
            ref_float = ref_hair_resized.astype(np.float32)
            alpha_float = alpha_mask_3ch.astype(np.float32)
            
            # Apply alpha blending: result = background * (1 - alpha) + foreground * alpha
            final_result = result_float * (1.0 - alpha_float) + ref_float * alpha_float
            
            # Clip values and convert back to uint8
            final_result = np.clip(final_result, 0, 255).astype(np.uint8)
            
            # Step 5: Post-processing for natural look
            # Apply slight color correction to blend better
            try:
                # Smooth the transition edges
                edge_mask = cv2.Canny(ref_mask_resized, 50, 150)
                edge_mask = cv2.dilate(edge_mask, np.ones((3, 3)), iterations=1)
                edge_region = edge_mask > 0
                
                if np.any(edge_region):
                    final_result[edge_region] = cv2.bilateralFilter(
                        final_result, 9, 75, 75
                    )[edge_region]
                    
            except Exception as e:
                logger.warning(f"Edge smoothing failed: {e}")
            
            logger.info("Hair blending completed successfully")
            return final_result
            
        except Exception as e:
            logger.error(f"Error in hair blending: {e}")
            # Fallback: simple overlay
            try:
                user_h, user_w = user_image.shape[:2]
                ref_resized = cv2.resize(reference_hair, (user_w, user_h))
                mask_resized = cv2.resize(transformed_ref_hair, (user_w, user_h)) / 255.0
                
                if len(mask_resized.shape) == 2:
                    mask_resized = np.stack([mask_resized] * 3, axis=-1)
                
                return (user_image * (1 - mask_resized) + ref_resized * mask_resized).astype(np.uint8)
            except:
                return user_image  # Return original as final fallback
    
    def _alpha_blend(self, bg_image: np.ndarray, fg_image: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """Perform alpha blending of foreground onto background"""
        try:
            # Ensure mask has 3 channels
            if len(mask.shape) == 2:
                mask = np.stack([mask] * 3, axis=-1)
            
            # Normalize mask
            mask = mask.astype(np.float32) / 255.0
            
            # Blend
            result = bg_image.astype(np.float32) * (1 - mask) + fg_image.astype(np.float32) * mask
            
            return result.astype(np.uint8)
            
        except Exception as e:
            logger.error(f"Error in alpha blending: {e}")
            return bg_image
    
    def process_makeover(self, user_id: str) -> Tuple[bool, str, Optional[str]]:
        """Process the complete makeover transformation"""
        try:
            if user_id not in self.user_sessions:
                return False, "No active session found", None
            
            session = self.user_sessions[user_id]
            if session['step'] != 'processing':
                return False, f"Session not ready for processing. Current step: {session['step']}", None
            
            user_photo_path = session['user_photo']
            ref_photo_path = session['reference_photo']
            
            # Step 1: Segment hair from both images
            logger.info(f"Processing makeover for user {user_id}")
            
            user_image, user_hair_mask = self.segment_hair(user_photo_path)
            ref_image, ref_hair_mask = self.segment_hair(ref_photo_path)
            
            # Step 2: Align and transform reference hair
            transformed_ref_hair = self.align_and_transform_hair(user_image, ref_image, ref_hair_mask)
            
            # Step 3: Blend hair onto user image
            final_result = self.blend_hair(user_image, ref_image, user_hair_mask, transformed_ref_hair)
            
            # Step 4: Save result with proper PNG format for transparency support
            result_id = str(uuid.uuid4())
            result_path = os.path.join(self.temp_folder, f"{result_id}_result.png")
            
            logger.info(f"Saving result image to: {result_path}")
            logger.info(f"Final result shape: {final_result.shape}, dtype: {final_result.dtype}")
            
            # Use PIL for better format handling and transparency support
            try:
                # Ensure image is in RGB format for PIL
                if len(final_result.shape) == 3 and final_result.shape[2] == 3:
                    # Create PIL image from RGB array
                    result_pil = Image.fromarray(final_result, mode='RGB')
                    
                    # Save as PNG with high quality
                    result_pil.save(result_path, format='PNG', optimize=True)
                    logger.info("Saved makeover result as PNG using PIL")
                    
                else:
                    logger.error(f"Unexpected result format for PIL: {final_result.shape}")
                    # Fallback to OpenCV with BGR conversion
                    if len(final_result.shape) == 3 and final_result.shape[2] == 3:
                        final_bgr = cv2.cvtColor(final_result, cv2.COLOR_RGB2BGR)
                    else:
                        final_bgr = final_result
                    success = cv2.imwrite(result_path, final_bgr, [cv2.IMWRITE_PNG_COMPRESSION, 1])
                    if not success:
                        raise Exception("OpenCV save failed")
                    
            except Exception as save_error:
                logger.error(f"PIL save failed: {save_error}, trying OpenCV fallback")
                # Fallback to OpenCV 
                if len(final_result.shape) == 3 and final_result.shape[2] == 3:
                    final_bgr = cv2.cvtColor(final_result, cv2.COLOR_RGB2BGR)
                else:
                    final_bgr = final_result
                success = cv2.imwrite(result_path, final_bgr, [cv2.IMWRITE_PNG_COMPRESSION, 1])
                if not success:
                    raise Exception("Both PIL and OpenCV save methods failed")
            
            # Verify file was created and has content
            if not os.path.exists(result_path) or os.path.getsize(result_path) == 0:
                raise Exception("Result image file is empty or not created")
            
            logger.info(f"Result image saved successfully: {os.path.getsize(result_path)} bytes")
            
            # Update session
            session['step'] = 'completed'
            session['result_path'] = result_path
            session['result_id'] = result_id
            
            return True, "Makeover completed successfully!", result_path
            
        except Exception as e:
            logger.error(f"Error processing makeover: {e}")
            return False, f"Error during makeover processing: {str(e)}", None
    
    def cleanup_session(self, user_id: str):
        """Clean up user session and temporary files"""
        try:
            if user_id not in self.user_sessions:
                return
            
            session = self.user_sessions[user_id]
            
            # Delete temporary files
            files_to_delete = []
            if 'user_photo' in session and session['user_photo']:
                files_to_delete.append(session['user_photo'])
            if 'reference_photo' in session and session['reference_photo']:
                files_to_delete.append(session['reference_photo'])
            if 'result_path' in session and session['result_path']:
                files_to_delete.append(session['result_path'])
            
            for file_path in files_to_delete:
                try:
                    if os.path.exists(file_path):
                        os.remove(file_path)
                        logger.info(f"Deleted temporary file: {file_path}")
                except Exception as e:
                    logger.warning(f"Could not delete file {file_path}: {e}")
            
            # Remove session
            del self.user_sessions[user_id]
            logger.info(f"Cleaned up makeover session for user {user_id}")
            
        except Exception as e:
            logger.error(f"Error cleaning up session: {e}")
    
    def cleanup_expired_sessions(self, max_age_hours: int = 2):
        """Clean up sessions older than max_age_hours"""
        try:
            current_time = time.time()
            expired_users = []
            
            for user_id, session in self.user_sessions.items():
                session_age = current_time - session.get('created_at', 0)
                if session_age > (max_age_hours * 3600):  # Convert hours to seconds
                    expired_users.append(user_id)
            
            for user_id in expired_users:
                self.cleanup_session(user_id)
                logger.info(f"Cleaned up expired session for user {user_id}")
                
        except Exception as e:
            logger.error(f"Error during session cleanup: {e}")
    
    def test_with_simple_images(self, user_image_path: str, ref_image_path: str) -> str:
        """Simple test function for makeover functionality with known good images"""
        try:
            logger.info("Starting simple makeover test")
            
            # Load images with proper color handling
            user_img = cv2.imread(user_image_path)
            ref_img = cv2.imread(ref_image_path)
            
            if user_img is None or ref_img is None:
                raise ValueError("Could not load test images")
            
            # Convert to RGB
            user_rgb = cv2.cvtColor(user_img, cv2.COLOR_BGR2RGB)
            ref_rgb = cv2.cvtColor(ref_img, cv2.COLOR_BGR2RGB)
            
            logger.info(f"User image: {user_rgb.shape}, Reference: {ref_rgb.shape}")
            
            # Simple resize and blend test
            h, w = user_rgb.shape[:2]
            ref_resized = self._resize_with_aspect_ratio(ref_rgb, (w, h), maintain_aspect=False)
            
            # Create simple alpha mask (top 30% of image)
            alpha_mask = np.zeros((h, w), dtype=np.float32)
            alpha_mask[:int(h*0.3), :] = 0.7  # 70% opacity for hair area
            
            # Apply alpha blending
            alpha_3ch = np.stack([alpha_mask] * 3, axis=-1)
            result = user_rgb.astype(np.float32) * (1.0 - alpha_3ch) + ref_resized.astype(np.float32) * alpha_3ch
            result = np.clip(result, 0, 255).astype(np.uint8)
            
            # Save test result
            test_result_path = os.path.join(self.temp_folder, "test_makeover.png")
            result_pil = Image.fromarray(result, mode='RGB')
            result_pil.save(test_result_path, format='PNG', optimize=True)
            
            logger.info(f"Simple test completed: {test_result_path}")
            return test_result_path
            
        except Exception as e:
            logger.error(f"Error in simple makeover test: {e}")
            raise
            logger.error(f"Error cleaning up expired sessions: {e}")
    
    def create_test_image(self, path: str, width: int = 500, height: int = 500) -> bool:
        """Create a simple test image for debugging"""
        try:
            # Create a simple test image using OpenCV
            test_image = np.zeros((height, width, 3), dtype=np.uint8)
            test_image[:] = (100, 150, 200)  # Light blue background
            
            # Add some text
            cv2.putText(test_image, "Test Makeover Result", (50, height//2), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            
            # Save image
            success = cv2.imwrite(path, test_image, [cv2.IMWRITE_JPEG_QUALITY, 95])
            
            if success and os.path.exists(path):
                logger.info(f"Test image created successfully: {path}")
                return True
            else:
                logger.error("Failed to create test image")
                return False
                
        except Exception as e:
            logger.error(f"Error creating test image: {e}")
            return False

# Global instance
ai_makeover_system = AIMakeoverSystem()