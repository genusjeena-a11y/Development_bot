import os
import logging
import uuid
import random
import time
from typing import Dict
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler
from werkzeug.utils import secure_filename
from hair_analyzer import HairAnalyzer
from photo_manager import photo_manager
from hairstyle_learning_system import hairstyle_learning
from user_conversation_state import user_state_manager
from photo_cleanup_system import photo_cleanup
from user_auth_system import UserAuthSystem
from ai_makeover_system import ai_makeover_system

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize hair analyzer
hair_analyzer = HairAnalyzer()

class TelegramBot:
    def __init__(self):
        self.bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "your-bot-token-here")
        self.waiting_for_details = {}  # Store user states
        self.upload_folder = 'uploads'
        self.auth_system = UserAuthSystem()  # Initialize authentication system
        
        # Ensure upload folder exists
        os.makedirs(self.upload_folder, exist_ok=True)
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command with authentication"""
        user_id = str(update.effective_user.id)
        username = update.effective_user.username
        
        # Clean up expired registrations
        self.auth_system.cleanup_expired_registrations()
        
        # Check if user is already registered
        if self.auth_system.is_user_registered(user_id):
            # User is registered, show main menu
            self.auth_system.update_user_activity(user_id)
            await self._show_main_menu(update)
            return
        
        # User needs to register - initiate login process
        login_code = self.auth_system.initiate_registration(user_id, username)
        
        welcome_message = f"""
🌟 Welcome to the Hair Analysis Bot! 🌟

To use this bot, you need to create an account with your Telegram ID.

📧 Your Login Code: **{login_code}**

Please reply with this 6-digit code to verify your account and complete registration.

⚠️ This code expires in 10 minutes.
⚠️ You have 3 attempts to enter the correct code.

📋 DISCLAIMER:
By creating an account, you confirm that you will:
• Only submit images you own OR have explicit permission to use
• Not submit nudity, adult content, or inappropriate material
• Use content that is safe and appropriate for public display

Type your login code to continue...
        """
        
        await update.message.reply_text(welcome_message)
    
    async def _show_main_menu(self, update: Update):
        """Show the main menu to authenticated users"""
        welcome_message = """
🌟 Welcome back to the Hair Analysis Bot! 🌟

I analyze hair characteristics and create competitive leaderboards using AI!

🏆 Categories:
- Longest Hair 📏
- Thickest Hair 💪
- Silkiest Hair ✨
- Overall Hair Queen 👑

🎯 What would you like to do?
        """
        
        keyboard = [
            [InlineKeyboardButton("📸 Enter Competition", callback_data='enter_competition')],
            [InlineKeyboardButton("🏆 View Leaderboard", callback_data='view_leaderboard')],
            [InlineKeyboardButton("🧪 AI Makeover (Beta)", callback_data='ai_makeover')],
            [InlineKeyboardButton("❓ Help", callback_data='help')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        help_text = """
🔧 HOW TO USE THIS BOT:

📸 ENTER COMPETITION:
1. Send a clear photo showing hair
2. Provide the person's name when asked
3. Provide their nationality when asked
4. Get instant analysis results with advanced features!

🏆 VIEW LEADERBOARDS:
• Use /leaderboard command
• Visit our website for full rankings with photos

🧠 NEW! AI LEARNING SYSTEM:
• I learn new hairstyles from you!
• When I see unknown styles, I ask for your help
• Use /learn to see my learning progress

💡 Tips for best results:
- Use clear, well-lit photos
- Make sure hair is visible and not covered
- Side or back views work well for length analysis
- Ensure you have permission to use the photo

📋 All Commands:
/start - Main menu with options
/help - This help message
/leaderboard - View current rankings with photos
/challenges - See active style challenges to try
/mystats - View your challenge points and progress
/trythis - Get a new style challenge suggestion
/cleanup - Remove old unused photos (Admin only)
/learn - View hairstyle learning system stats (Admin only)
/stats - Complete system statistics (Admin only)
/reset - Reset leaderboard categories (Admin only)
/new_category - Create new leaderboard categories (Admin only)
/makeover - Preview upcoming AI makeover features
/admin - Admin panel access

🔐 Authentication:
All bot features require registration. Use /start to get your unique login code.
Admin commands require additional password authentication.

🎨 Features:
✨ Hair color analysis in simple language
💇‍♀️ Hairstyle detection and suggestions
💡 Personalized hair care tips
🎯 Hair color ideas based on your current look
🎪 Try new looks with style challenges
        """
        await update.message.reply_text(help_text)
    
    async def leaderboard_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /leaderboard command - Show all 4 categories with photos and detailed info"""
        try:
            # Get leaderboard data from photo manager
            leaderboards = photo_manager.get_leaderboards()
            
            categories = {
                'overall': {'name': '👑 Overall Hair Queen', 'emoji': '👑'},
                'length': {'name': '📏 Longest Hair', 'emoji': '📏'},
                'thickness': {'name': '🧵 Thickest Hair', 'emoji': '🧵'},
                'silkiness': {'name': '🫧 Silkiest Hair', 'emoji': '🫧'}
            }
            
            # Send intro message
            await update.message.reply_text("🏆 COMPLETE HAIR LEADERBOARDS 🏆\n\nShowing all 4 categories with photos and detailed scores...")
            
            has_entries = False
            
            for category_key, category_info in categories.items():
                # Get top 3 for this category
                top_entries = leaderboards.get(category_key, [])[:3]
                
                if top_entries:
                    has_entries = True
                    
                    for i, entry in enumerate(top_entries, 1):
                        # Get photo info
                        photo_info = photo_manager.get_photo_info(entry['unique_id'])
                        photo_path = photo_manager.get_photo_path(entry['unique_id'])
                        
                        if photo_path and photo_info:
                            try:
                                with open(photo_path, 'rb') as photo_file:
                                    # Create detailed caption
                                    rank_emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉"
                                    
                                    caption = f"{rank_emoji} #{i} {category_info['emoji']} {category_info['name']}\n\n"
                                    caption += f"👤 Name: {photo_info['name']}\n"
                                    caption += f"🌍 Nationality: {photo_info['nationality']}\n\n"
                                    
                                    # Detailed scores
                                    scores = photo_info['scores']
                                    caption += f"📊 DETAILED SCORES:\n"
                                    caption += f"📏 Length: {scores.get('hair_length_score', 0):.1f}/100\n"
                                    caption += f"🧵 Thickness: {scores.get('hair_thickness_score', 0):.1f}/100\n" 
                                    caption += f"🫧 Silkiness: {scores.get('hair_silkiness_score', 0):.1f}/100\n"
                                    caption += f"👑 Overall: {scores.get('overall_score', 0):.1f}/100\n\n"
                                    
                                    # Category-specific score highlight
                                    category_score = entry.get('score', 0)
                                    if category_key == 'overall':
                                        caption += f"🏆 Overall Score: {category_score:.1f}/100"
                                    elif category_key == 'length':
                                        caption += f"📏 Length Score: {category_score:.1f}/100"
                                    elif category_key == 'thickness':
                                        caption += f"🧵 Thickness Score: {category_score:.1f}/100"
                                    elif category_key == 'silkiness':
                                        caption += f"🫧 Silkiness Score: {category_score:.1f}/100"
                                    
                                    caption += f"\n\n🆔 ID: {photo_manager.get_short_id(entry['unique_id'])}"
                                    caption += f"\n📅 {photo_info.get('timestamp', '')[:10]}"
                                    
                                    await update.message.reply_photo(
                                        photo=photo_file,
                                        caption=caption
                                    )
                            except Exception as photo_error:
                                logger.error(f"Error sending photo for {photo_info.get('name', 'Unknown')}: {str(photo_error)}")
                                # Send text fallback
                                rank_emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉"
                                text = f"{rank_emoji} #{i} {photo_info.get('name', 'Unknown')} ({photo_info.get('nationality', 'Unknown')})\n"
                                text += f"🏆 Score: {entry.get('score', 0):.1f}/100"
                                await update.message.reply_text(text)
            
            if not has_entries:
                await update.message.reply_text(
                    "🏆 NO ENTRIES YET! 🏆\n\n"
                    "Be the first to compete in all categories!\n\n"
                    "📸 Send me a photo to start your hair analysis and claim the crown! 👑"
                )
            else:
                # Send final message with website link
                await update.message.reply_text(
                    "🌐 VIEW COMPLETE RANKINGS\n\n"
                    "Visit our website to see:\n"
                    "• Full leaderboards for all categories\n"
                    "• More detailed statistics\n"
                    "• Individual submission pages\n\n"
                    "📸 Ready to compete? Send me a photo!"
                )
                
        except Exception as e:
            logger.error(f"Error getting comprehensive leaderboard: {str(e)}")
            await update.message.reply_text(
                "❌ Sorry, couldn't load leaderboards right now. Please try again later!"
            )
    
    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle button callbacks"""
        query = update.callback_query
        user_id = str(query.from_user.id)
        
        # Check if user is registered
        if not self.auth_system.is_user_registered(user_id):
            await query.answer("❌ You need to complete registration first. Use /start to get your login code.")
            return
        
        # Update user activity
        self.auth_system.update_user_activity(user_id)
        
        await query.answer()
        
        if query.data == 'enter_competition':
            await query.edit_message_text(
                "📸 ENTER COMPETITION\n\n"
                "Send me a clear photo showing the person's hair to start the analysis!\n\n"
                "💡 Tips for best results:\n"
                "• Use well-lit photos\n"
                "• Make sure hair is clearly visible\n"
                "• Side or back views work well for length analysis\n"
                "• Ensure you have permission to use the photo\n\n"
                "Ready? Send the photo now! 📷"
            )
            
        elif query.data == 'view_leaderboard':
            # Show simplified leaderboard inline
            await self.show_inline_leaderboard(query)
            
        elif query.data == 'ai_makeover':
            # Handle AI Makeover button
            await self.handle_ai_makeover_start(query)
            
        elif query.data == 'help':
            help_text = """
🔧 HOW TO USE THIS BOT:

📸 ENTER COMPETITION:
1. Click "Enter Competition" button or send a photo
2. Provide the person's name when asked
3. Provide their nationality when asked
4. Get instant analysis results!

🏆 VIEW LEADERBOARDS:
• Click "View Leaderboard" button
• Use /leaderboard command for detailed view
• Visit our website for full rankings

✨ AI MAKEOVER:
1. Click "AI Makeover" button
2. Send your headshot photo
3. Send a reference hairstyle photo
4. Get your virtual makeover result!

💡 Tips for best results:
- Use clear, well-lit photos
- Make sure hair is visible and not covered
- Side or back views work well for length analysis
- Ensure you have permission to use the photo

📋 Commands:
/start - Main menu with options
/help - This help message
/leaderboard - View current rankings with photos

🏆 Categories we analyze:
- Longest Hair 📏
- Thickest Hair 💪
- Silkiest Hair ✨
- Overall Hair Queen 👑
            """
            
            # Add back to menu button
            keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data='back_to_menu')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(help_text, reply_markup=reply_markup)
            
        elif query.data == 'back_to_menu':
            # Show main menu again
            await self.show_main_menu(query)
    
    async def show_main_menu(self, query_or_update):
        """Show the main menu with buttons"""
        welcome_message = """
🌟 Welcome to the Hair Analysis Bot! 🌟

I analyze hair characteristics and create competitive leaderboards using AI!

🏆 Categories:
- Longest Hair 📏
- Thickest Hair 💪
- Silkiest Hair ✨
- Overall Hair Queen 👑

🎯 What would you like to do?
        """
        
        keyboard = [
            [InlineKeyboardButton("📸 Enter Competition", callback_data='enter_competition')],
            [InlineKeyboardButton("🏆 View Leaderboard", callback_data='view_leaderboard')],
            [InlineKeyboardButton("🧪 AI Makeover (Beta)", callback_data='ai_makeover')],
            [InlineKeyboardButton("❓ Help", callback_data='help')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if hasattr(query_or_update, 'edit_message_text'):
            await query_or_update.edit_message_text(welcome_message, reply_markup=reply_markup)
        else:
            await query_or_update.message.reply_text(welcome_message, reply_markup=reply_markup)
    
    async def show_inline_leaderboard(self, query):
        """Show simplified leaderboard inline with back button"""
        try:
            leaderboards = photo_manager.get_leaderboards()
            
            leaderboard_text = "🏆 CURRENT LEADERBOARDS 🏆\n\n"
            
            # Show top 3 from overall category
            overall_entries = leaderboards.get('overall', [])[:3]
            if overall_entries:
                leaderboard_text += "👑 OVERALL HAIR QUEEN:\n"
                for i, entry in enumerate(overall_entries, 1):
                    photo_info = photo_manager.get_photo_info(entry['unique_id'])
                    if photo_info:
                        if i == 1:
                            leaderboard_text += f"🥇 {photo_info['name']} ({photo_info['nationality']}) - {entry.get('score', 0):.1f}/100\n"
                        elif i == 2:
                            leaderboard_text += f"🥈 {photo_info['name']} ({photo_info['nationality']}) - {entry.get('score', 0):.1f}/100\n"
                        elif i == 3:
                            leaderboard_text += f"🥉 {photo_info['name']} ({photo_info['nationality']}) - {entry.get('score', 0):.1f}/100\n"
                leaderboard_text += "\n"
            
            # Show top 3 from length category
            length_entries = leaderboards.get('length', [])[:3]
            if length_entries:
                leaderboard_text += "📏 LONGEST HAIR:\n"
                for i, entry in enumerate(length_entries, 1):
                    photo_info = photo_manager.get_photo_info(entry['unique_id'])
                    if photo_info:
                        if i == 1:
                            leaderboard_text += f"🥇 {photo_info['name']} - {entry.get('score', 0):.1f}/100\n"
                        elif i == 2:
                            leaderboard_text += f"🥈 {photo_info['name']} - {entry.get('score', 0):.1f}/100\n"
                        elif i == 3:
                            leaderboard_text += f"🥉 {photo_info['name']} - {entry.get('score', 0):.1f}/100\n"
                leaderboard_text += "\n"
            
            if not overall_entries and not length_entries:
                leaderboard_text += "No entries yet! Be the first to compete! 📸\n"
            
            leaderboard_text += "\n🌐 Use /leaderboard for detailed view with photos!\n"
            leaderboard_text += "Visit our website for complete rankings!"
            
            # Add navigation buttons
            keyboard = [
                [InlineKeyboardButton("🔙 Back to Menu", callback_data='back_to_menu')],
                [InlineKeyboardButton("📸 Enter Competition", callback_data='enter_competition')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(leaderboard_text, reply_markup=reply_markup)
            
        except Exception as e:
            logger.error(f"Error showing inline leaderboard: {str(e)}")
            await query.edit_message_text(
                "❌ Sorry, couldn't load leaderboards right now. Please try again later!"
            )

    async def handle_photo(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle photo submissions"""
        user_id = str(update.effective_user.id)
        
        # Check if user is registered
        if not self.auth_system.is_user_registered(user_id):
            await update.message.reply_text(
                "❌ You need to complete registration first. Please use /start to get your login code."
            )
            return
        
        # Update user activity
        self.auth_system.update_user_activity(user_id)
        
        user_id_int = int(user_id)  # Convert back for existing logic
        
        try:
            # Get the largest photo size
            photo = update.message.photo[-1]
            
            # Generate unique ID for this submission
            unique_id = str(uuid.uuid4())
            
            # Download photo
            file = await context.bot.get_file(photo.file_id)
            filename = f"{unique_id}.jpg"  # Use unique_id as filename
            file_path = os.path.join(self.upload_folder, filename)
            
            await file.download_to_drive(file_path)
            logger.info(f"Photo downloaded with unique ID {unique_id}: {file_path}")
            
            # FIRST: Check if this is for AI makeover session
            makeover_handled = await self.handle_makeover_photo(update, user_id, file_path)
            
            if makeover_handled:
                # Photo was handled by makeover system, cleanup competition photo
                try:
                    os.remove(file_path)
                except:
                    pass  # Ignore cleanup errors
                return
            
            # NOT makeover - handle as regular competition photo
            # Store photo path, unique ID and ask for details
            self.waiting_for_details[user_id_int] = {
                'unique_id': unique_id,
                'photo_path': file_path,
                'step': 'name'
            }
            
            await update.message.reply_text(
                "📸 Great photo! Now please tell me:\n\n"
                "👤 What is the name of the person in the photo?"
            )
            
        except Exception as e:
            logger.error(f"Error handling photo: {str(e)}")
            await update.message.reply_text(
                "❌ Sorry, there was an error processing your photo. Please try again."
            )
    
    async def handle_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle text messages (login codes, name, nationality, hairstyle learning, and admin commands)"""
        user_id = str(update.effective_user.id)
        text = update.message.text.strip()
        
        # PRIORITY 1: Check if user is trying to verify login code
        if not self.auth_system.is_user_registered(user_id):
            # Check if text looks like a login code (6 digits)
            if text.isdigit() and len(text) == 6:
                success, message = self.auth_system.verify_login_code(user_id, text)
                await update.message.reply_text(message)
                
                if success:
                    # User successfully registered, show main menu
                    await self._show_main_menu(update)
                return
            else:
                # User not registered and didn't provide valid login code
                await update.message.reply_text(
                    "❌ You need to complete registration first. Please use /start to get your login code."
                )
                return
        
        # User is registered, update their activity
        self.auth_system.update_user_activity(user_id)
        
        # Convert user_id back to int for existing logic
        user_id_int = int(user_id)
        
        # Check if user is in admin state
        if hasattr(self, 'admin_states') and user_id_int in self.admin_states:
            if self.admin_states[user_id_int] == 'waiting_for_reset_choice':
                await self._handle_admin_reset_choice(update, text, user_id_int)
                return
            elif self.admin_states[user_id_int] == 'waiting_for_complete_reset_confirmation':
                await self._handle_complete_reset_confirmation(update, text, user_id_int)
                return
        
        # Check if user is in learning mode (waiting to provide hairstyle name)
        if user_state_manager.is_waiting_for_hairstyle_name(user_id):
            learning_context = user_state_manager.get_learning_context(user_id)
            if learning_context:
                # User provided hairstyle name - learn it!
                success = hairstyle_learning.add_new_hairstyle(
                    hairstyle_name=text,
                    photo_path=learning_context['photo_path'],
                    unique_id=learning_context['unique_id']
                )
                
                if success:
                    confirmation = hairstyle_learning.get_learning_confirmation(text)
                    await update.message.reply_text(confirmation)
                    
                    # Also send learning stats
                    total_styles = hairstyle_learning.get_hairstyle_count()
                    await update.message.reply_text(
                        f"🧠 **Learning Stats:**\n"
                        f"• Total known hairstyles: {total_styles}\n"
                        f"• Learning dataset growing! 📈\n\n"
                        f"Now I'll recognize '{text}' in future photos! ✨"
                    )
                else:
                    await update.message.reply_text(
                        "❌ Sorry, I had trouble learning this hairstyle. Please try sending another photo!"
                    )
                
                # Clear learning state
                user_state_manager.clear_user_state(user_id)
                return
        
        # Regular flow - check if user is waiting for details
        if user_id_int not in self.waiting_for_details:
            await update.message.reply_text(
                "Please send me a photo first to start the hair analysis process!"
            )
            return
        
        user_data = self.waiting_for_details[user_id_int]
        
        if user_data['step'] == 'name':
            user_data['person_name'] = text
            user_data['step'] = 'nationality'
            
            await update.message.reply_text(
                f"👤 Name: {text}\n\n"
                "🌍 What is their nationality?"
            )
            
        elif user_data['step'] == 'nationality':
            user_data['nationality'] = text
            
            await update.message.reply_text(
                f"👤 Name: {user_data['person_name']}\n"
                f"🌍 Nationality: {text}\n\n"
                "🔍 Analyzing hair characteristics... Please wait!"
            )
            
            # Process the photo
            await self.process_submission(update, user_data)
            
            # Clean up user data
            del self.waiting_for_details[user_id_int]
            
            # Increment user's submission count
            self.auth_system.increment_user_submissions(user_id)
    
    async def process_submission(self, update: Update, user_data):
        """Process hair analysis and update leaderboards with learning integration"""
        try:
            # Analyze hair from photo
            analysis_result = hair_analyzer.analyze_hair(user_data['photo_path'])
            
            # Check if analysis returned valid results
            if not analysis_result or analysis_result.get('hair_length_score', 0) == 0:
                await update.message.reply_text(
                    "❌ Sorry, I couldn't analyze the hair in this photo. Please try with a clearer image showing hair more prominently."
                )
                return
            
            # Check if detected hairstyle is known or needs learning
            detected_hairstyle = analysis_result.get('hairstyle', 'unknown')
            hairstyle_message = analysis_result.get('hairstyle_message', 'Beautiful hair!')
            
            # Check if this hairstyle is in our known list
            is_known_style = hairstyle_learning.is_hairstyle_known(detected_hairstyle)
            
            if not is_known_style and detected_hairstyle != 'unknown':
                # Unknown hairstyle detected - trigger learning mode
                user_id = update.effective_user.id
                unique_id = str(uuid.uuid4())
                
                # Set user to learning mode
                user_state_manager.set_waiting_for_hairstyle_name(
                    user_id=user_id,
                    photo_path=user_data['photo_path'],
                    unique_id=unique_id,
                    detected_style=detected_hairstyle
                )
                
                # Ask user to name the hairstyle
                learning_prompt = hairstyle_learning.get_learning_prompt()
                await update.message.reply_text(
                    f"🤔 I detected an interesting hairstyle that I haven't seen before!\n\n"
                    f"🤖 My guess: \"{detected_hairstyle}\"\n\n"
                    f"{learning_prompt}"
                )
                
                # Don't add to leaderboard yet - wait for learning
                return
            
            # Known hairstyle or generic detection - proceed normally
            # Store photo data using photo manager
            unique_id = photo_manager.add_photo(
                person_name=user_data['person_name'],
                nationality=user_data['nationality'],
                scores=analysis_result
            )
            
            # Update unique_id in user_data for file management
            user_data['unique_id'] = unique_id
            
            # Rename the photo file to use the new unique_id
            old_path = user_data['photo_path']
            new_filename = f"{unique_id}.jpg"
            new_path = os.path.join(self.upload_folder, new_filename)
            
            try:
                os.rename(old_path, new_path)
                logger.info(f"Photo renamed from {old_path} to {new_path}")
                user_data['photo_path'] = new_path  # Update path for cleanup system
            except Exception as rename_error:
                logger.error(f"Error renaming photo: {rename_error}")
            
            # Calculate rankings and update leaderboards
            self.update_leaderboards()
            
            # Check for challenge completions
            try:
                from challenge_system import challenge_system
                user_id = update.effective_user.id
                challenge_completions = challenge_system.evaluate_challenge_completion(
                    user_id, analysis_result.get('hairstyle', 'unknown'), analysis_result
                )
                
                if challenge_completions:
                    user_data['challenge_completions'] = challenge_completions
            except ImportError:
                logger.info("Challenge system not available")
            except Exception as e:
                logger.warning(f"Challenge evaluation failed: {e}")
            
            # Send results
            await self.send_analysis_results(update, user_data, analysis_result)
            
            # Schedule periodic cleanup of old unused photos
            cleanup_stats = photo_cleanup.cleanup_unused_photos()
            if cleanup_stats['removed'] > 0:
                logger.info(f"Cleaned up {cleanup_stats['removed']} old unused photos")
            
        except Exception as e:
            logger.error(f"Error processing submission: {str(e)}")
            await update.message.reply_text(
                "❌ Sorry, there was an error analyzing your photo. Please try again."
            )
    
    def update_leaderboards(self):
        """Update all leaderboard rankings"""
        try:
            all_photos = photo_manager.get_all_photos()
            
            leaderboards = {
                'overall': [],
                'length': [],
                'thickness': [],
                'silkiness': []
            }
            
            # Create entries for each category
            for unique_id, photo_info in all_photos.items():
                scores = photo_info['scores']
                
                # Overall leaderboard
                leaderboards['overall'].append({
                    'unique_id': unique_id,
                    'score': scores.get('overall_score', 0),
                    'rank': 0  # Will be set after sorting
                })
                
                # Length leaderboard
                leaderboards['length'].append({
                    'unique_id': unique_id,
                    'score': scores.get('hair_length_score', 0),
                    'rank': 0
                })
                
                # Thickness leaderboard
                leaderboards['thickness'].append({
                    'unique_id': unique_id,
                    'score': scores.get('hair_thickness_score', 0),
                    'rank': 0
                })
                
                # Silkiness leaderboard
                leaderboards['silkiness'].append({
                    'unique_id': unique_id,
                    'score': scores.get('hair_silkiness_score', 0),
                    'rank': 0
                })
            
            # Sort and assign ranks
            for category in leaderboards:
                leaderboards[category].sort(key=lambda x: x['score'], reverse=True)
                for rank, entry in enumerate(leaderboards[category], 1):
                    entry['rank'] = rank
            
            # Update photo manager with new leaderboards
            photo_manager.update_leaderboards(leaderboards)
            
        except Exception as e:
            logger.error(f"Error updating leaderboards: {str(e)}")
    
    async def send_analysis_results(self, update: Update, user_data, analysis_result):
        """Send comprehensive analysis results with advanced features to user"""
        try:
            person_name = user_data['person_name']
            nationality = user_data['nationality']
            unique_id = user_data['unique_id']
            
            # Get current rankings
            leaderboards = photo_manager.get_leaderboards()
            
            # Find rankings for this submission
            rankings = {}
            for category, entries in leaderboards.items():
                for entry in entries:
                    if entry['unique_id'] == unique_id:
                        rankings[category] = entry['rank']
                        break
            
            # Extract features from analysis result - simplified language
            hair_color = analysis_result.get('glamorous_color_name', 'Beautiful hair color')
            color_message = analysis_result.get('color_personality_message', 'Your hair color looks great!')
            dye_suggestion = analysis_result.get('dye_suggestion', 'Your current color suits you well!')
            hairstyle = analysis_result.get('hairstyle', 'gorgeous')
            hairstyle_message = analysis_result.get('hairstyle_message', 'Your hairstyle looks great!')
            
            # Get enhanced comment if available
            try:
                from enhanced_hair_analyzer import enhanced_analyzer
                enhanced_comment = enhanced_analyzer.generate_realistic_comment(analysis_result)
                final_comment = enhanced_comment
            except (ImportError, Exception) as e:
                logger.info(f"Using standard comment system: {e}")
                final_comment = analysis_result.get('hair_comment', 'Your hair looks beautiful!')
            
            # Generate smart auto-reply based on scores
            smart_reply = self._generate_smart_auto_reply(analysis_result, rankings)
            
            # Create main results message with simpler language
            results_message = f"""
🎉 HAIR ANALYSIS COMPLETE! 🎉

👤 {person_name} ({nationality})
🆔 ID: {photo_manager.get_short_id(unique_id)}

💇‍♀️ HAIRSTYLE:
{hairstyle_message}

🎨 HAIR COLOR:
{color_message}
You have {hair_color}

💡 COLOR IDEAS:
{dye_suggestion}

✨ OVERALL:
{final_comment}

{smart_reply}

📊 SCORES:
📏 Length: {analysis_result.get('hair_length_score', 0):.1f}/100
🧵 Thickness: {analysis_result.get('hair_thickness_score', 0):.1f}/100
🫧 Silkiness: {analysis_result.get('hair_silkiness_score', 0):.1f}/100
🎨 Texture: {analysis_result.get('hair_texture_score', 0):.1f}/100
👑 Overall Score: {analysis_result.get('overall_score', 0):.1f}/100

🏆 YOUR RANKINGS:
👑 Overall: #{rankings.get('overall', 'N/A')}
📏 Length: #{rankings.get('length', 'N/A')}
🧵 Thickness: #{rankings.get('thickness', 'N/A')}
🫧 Silkiness: #{rankings.get('silkiness', 'N/A')}

🌐 View full leaderboards: /leaderboard
🎯 Try new looks: /challenges
            """
            
            await update.message.reply_text(results_message)
            
            # Send personalized hair care tips if available
            care_tips = analysis_result.get('formatted_care_tips', '')
            if care_tips:
                tips_message = f"""
💡 PERSONALIZED HAIR CARE TIPS FOR YOU:

{care_tips}

✨ Take care of that gorgeous hair - you deserve to shine!
                """
                await update.message.reply_text(tips_message)
            
            # Send congratulations for top rankings
            for category, rank in rankings.items():
                if rank <= 3:
                    category_names = {
                        'overall': '👑 Overall Hair Queen',
                        'length': '📏 Longest Hair',
                        'thickness': '🧵 Thickest Hair',
                        'silkiness': '🫧 Silkiest Hair'
                    }
                    
                    congrats_msg = f"🎊 CONGRATULATIONS! 🎊\n\n"
                    if rank == 1:
                        congrats_msg += f"👑 {person_name} is now #1 in {category_names[category]}! 👑"
                    elif rank == 2:
                        congrats_msg += f"🥈 {person_name} secured 2nd place in {category_names[category]}!"
                    elif rank == 3:
                        congrats_msg += f"🥉 {person_name} earned 3rd place in {category_names[category]}!"
                    
                    await update.message.reply_text(congrats_msg)
                    break  # Only send one congratulations message
            
            # Send challenge completion notifications
            challenge_completions = user_data.get('challenge_completions', [])
            for completion in challenge_completions:
                challenge_msg = f"""
🎯 CHALLENGE COMPLETED! 🎯

You successfully completed the **{completion['style_name']}** challenge!

Match Accuracy: {completion['match_score']:.1f}%
Points Earned: {completion['points_earned']} points
Challenge Type: {completion['challenge_type'].title()}

🌟 Amazing work! Keep trying new looks for more points!
                """.strip()
                await update.message.reply_text(challenge_msg)
            
            # Occasionally suggest new challenges
            if random.random() < 0.3:  # 30% chance
                try:
                    from challenge_system import challenge_system
                    suggestion = challenge_system.get_random_challenge_suggestion()
                    
                    challenge_suggestion_msg = f"""
🎨 **NEW STYLE CHALLENGE** 🎨

Ready for your next hair adventure? 

{suggestion['challenge_text']}

Use /challenges to see all active challenges!
                    """.strip()
                    await update.message.reply_text(challenge_suggestion_msg)
                    
                except (ImportError, Exception) as e:
                    logger.info(f"Challenge suggestion failed: {e}")
            
        except Exception as e:
            logger.error(f"Error sending analysis results: {str(e)}")
            await update.message.reply_text(
                "✅ Analysis completed, but there was an error displaying the results. Use /leaderboard to see current rankings."
            )
    
    def _generate_smart_auto_reply(self, analysis_result: Dict, rankings: Dict) -> str:
        """Generate smart auto-reply based on scores and rankings"""
        
        thickness_score = analysis_result.get('hair_thickness_score', 0)
        silkiness_score = analysis_result.get('hair_silkiness_score', 0)
        overall_score = analysis_result.get('overall_score', 0)
        color_vibrancy = analysis_result.get('hair_vibrancy_score', 0)
        hairstyle = analysis_result.get('hairstyle', '').lower()
        
        replies = []
        
        # Thickness-based responses
        if thickness_score < 30:
            replies.append("💡 **Pro Tip:** Try volume-boosting shampoo and root-lifting spray for extra oomph!")
        elif thickness_score > 80:
            replies.append("🦁 **Thickness Goals!** Your hair has incredible natural volume - absolutely stunning!")
        
        # Silkiness-based responses
        if silkiness_score < 40:
            replies.append("✨ **Hair Care Tip:** Deep conditioning treatments twice a week could work wonders!")
        elif silkiness_score > 85:
            replies.append("🌟 **Silk Heaven!** Your hair looks like it belongs in a luxury shampoo commercial!")
        
        # Color vibrancy responses
        if color_vibrancy and color_vibrancy > 70:
            replies.append("🔥 **Goddess-tier hair detected!** That color is absolutely VIBRANT!")
        
        # Elite status responses (Top 5%)
        if overall_score >= 85:
            replies.append("💎 **ELITE LEVEL ENTRY!** You're in the top 5% - welcome to hair royalty!")
        
        # Ranking-based responses
        for category, rank in rankings.items():
            if rank == 1:
                replies.append(f"👑 **REIGNING CHAMPION!** You're #1 in {category} - absolutely legendary!")
                break
            elif rank <= 3:
                replies.append(f"🏆 **TOP 3 STATUS!** You're #{rank} in {category} - incredible achievement!")
                break
            elif rank <= 10:
                replies.append(f"⭐ **TOP 10!** You're #{rank} in {category} - so close to the podium!")
                break
        
        # Braid-specific responses
        if 'braid' in hairstyle:
            replies.append("🎨 **Braid Artistry!** Those intricate patterns are pure hair sculpture!")
        
        # Combine replies
        if replies:
            return "\n\n" + "\n".join(replies[:2])  # Max 2 smart replies to avoid overwhelming
        
        return ""
    
    async def cleanup_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /cleanup command to remove old unused photos"""
        user_id = str(update.effective_user.id)
        
        try:
            # Check if user is registered
            if not self.auth_system.is_user_registered(user_id):
                await update.message.reply_text("❌ You need to complete registration first. Please use /start to get your login code.")
                return
            
            # Check if user has admin access (regular admin or temporary admin)
            if not (self.auth_system.is_admin(user_id) or self.auth_system.has_temp_admin(user_id)):
                await update.message.reply_text("❌ This command requires admin access. Use /admin to gain access.")
                return
            
            # Update user activity
            self.auth_system.update_user_activity(user_id)
            
            await update.message.reply_text("🧹 Starting top-3 cleanup... This may take a moment.")
            
            # Run top-3 cleanup (keep only top 3 in each category)
            cleanup_stats = photo_manager.cleanup_photos_keep_top3()
            
            # Send summary
            summary = f"""
🧹 **TOP-3 CLEANUP COMPLETED** 🧹

📊 **Statistics:**
• Photos removed: {cleanup_stats['deleted']}
• Photos kept (top 3): {cleanup_stats['kept']}
• Protected categories: {len(photo_manager.get_category_names())}

✅ Only top 3 photos in each category remain!
            """
            await update.message.reply_text(summary)
            
        except Exception as e:
            logger.error(f"Error in cleanup command: {e}")
            await update.message.reply_text("❌ Sorry, there was an error during cleanup. Please try again later.")
    
    async def learn_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /learn command to show learning stats"""
        user_id = str(update.effective_user.id)
        
        try:
            # Check if user is registered
            if not self.auth_system.is_user_registered(user_id):
                await update.message.reply_text("❌ You need to complete registration first. Please use /start to get your login code.")
                return
            
            # Check if user has   access (regular admin or temporary admin)
            if not (self.auth_system.is_admin(user_id) or self.auth_system.has_temp_admin(user_id)):
                await update.message.reply_text("❌ This command requires admin access. Use /admin to gain access.")
                return
            
            # Update user activity
            self.auth_system.update_user_activity(user_id)
            
            total_styles = hairstyle_learning.get_hairstyle_count()
            
            message = f"""
🧠 **HAIRSTYLE LEARNING SYSTEM** 🧠

📊 **Current Stats:**
• Total known hairstyles: {total_styles}
• Learning dataset growing! 📈

🎯 **How Learning Works:**
1. I analyze your hair photo
2. If I detect an unknown style, I ask you to name it
3. I learn from your input and remember it for future photos
4. Next time I see that style, I'll recognize it!

✨ **Recent Learning:**
Send me photos with unique hairstyles to help me learn new styles!

💡 **Tip:** The more diverse hairstyles you show me, the smarter I become!
            """
            
            await update.message.reply_text(message)
            
        except Exception as e:
            logger.error(f"Error in learn command: {e}")
            await update.message.reply_text("❌ Sorry, couldn't load learning stats right now.")
    
    async def makeover_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /makeover command for AI-powered hair makeover mode"""
        try:
            makeover_message = """
💫 **AI HAIR MAKEOVER MODE** 💫

🚧 **Coming Soon!** 🚧

This exciting feature will let you:
• Try different hairstyles virtually
• Preview color changes with AI
• See how you'd look with trending styles
• Get personalized style recommendations

🎨 **Features in Development:**
• Virtual hairstyle overlay
• Color transformation preview
• Style recommendation engine
• Face shape analysis for best styles

📸 **For now:** Send me your current photo for analysis, and I'll suggest amazing styles that would suit you!

✨ Stay tuned for this magical makeover experience!
            """
            
            await update.message.reply_text(makeover_message)
            
        except Exception as e:
            logger.error(f"Error in makeover command: {e}")
            await update.message.reply_text("❌ Sorry, couldn't load makeover mode right now.")
    
    async def challenges_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /challenges command to show active challenges"""
        try:
            from challenge_system import challenge_system
            
            active_challenges = challenge_system.get_active_challenges_for_user()
            daily_challenge = challenge_system.create_daily_challenge()
            weekly_challenge = challenge_system.create_weekly_challenge()
            
            if not active_challenges:
                message = """
🎯 **NO ACTIVE CHALLENGES** 🎯

No challenges are currently running, but I can suggest a style for you to try!

Use /trythis for a random style challenge!
                """.strip()
            else:
                message = "🏆 **ACTIVE CHALLENGES** 🏆\n\n"
                
                for challenge in active_challenges:
                    if challenge['type'] == 'daily':
                        message += f"🌟 **DAILY CHALLENGE**\n"
                    elif challenge['type'] == 'weekly':
                        message += f"⭐ **WEEKLY CHALLENGE**\n"
                    
                    message += f"Style: **{challenge['style_name']}**\n"
                    message += f"Difficulty: {challenge['difficulty']}\n"
                    message += f"Points: {challenge['points']}\n"
                    message += f"Participants: {challenge['participants']}\n"
                    message += f"Completed: {challenge['completions']}\n\n"
                    message += f"💡 {challenge['tips']}\n\n"
                
                message += "📸 Send me a photo when you try these looks!\n"
                message += "Perfect matches earn full points and recognition! ✨"
            
            await update.message.reply_text(message)
            
        except ImportError:
            await update.message.reply_text("❌ Challenge system not available right now.")
        except Exception as e:
            logger.error(f"Error in challenges command: {e}")
            await update.message.reply_text("❌ Sorry, couldn't load challenges right now.")
    
    async def mystats_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /mystats command to show user challenge stats"""
        try:
            from challenge_system import challenge_system
            
            user_id = update.effective_user.id
            stats = challenge_system.get_user_stats(user_id)
            
            message = f"""
🏆 **YOUR CHALLENGE STATS** 🏆

💰 Total Points: {stats['total_points']}
🎯 Challenges Completed: {stats['challenges_completed']}
🌟 Daily Completed: {stats['daily_completed']}
⭐ Weekly Completed: {stats['weekly_completed']}

📈 **RECENT COMPLETIONS:**
            """
            
            if stats['recent_completions']:
                for completion in stats['recent_completions']:
                    message += f"\n• {completion['style_name']} ({completion['points_earned']} pts)"
            else:
                message += "\nNo challenges completed yet! Use /challenges to get started."
            
            message += "\n\n🎨 Keep trying new looks to earn more points!"
            
            await update.message.reply_text(message)
            
        except ImportError:
            await update.message.reply_text("❌ Challenge system not available right now.")
        except Exception as e:
            logger.error(f"Error in mystats command: {e}")
            await update.message.reply_text("❌ Sorry, couldn't load your stats right now.")
    
    async def trythis_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /trythis command to suggest a random challenge"""
        try:
            from challenge_system import challenge_system
            
            suggestion = challenge_system.get_random_challenge_suggestion()
            
            message = f"""
🎨 **STYLE CHALLENGE FOR YOU** 🎨

{suggestion['challenge_text']}

📸 **Ready to try it?** Send me a photo when you're done!
            """
            
            await update.message.reply_text(message)
            
        except ImportError:
            await update.message.reply_text("❌ Challenge system not available right now.")
        except Exception as e:
            logger.error(f"Error in trythis command: {e}")
            await update.message.reply_text("❌ Sorry, couldn't generate a challenge right now.")

    async def admin_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /admin command - direct admin panel access"""
        user_id = str(update.effective_user.id)
        
        try:
            # Check if user is registered
            if not self.auth_system.is_user_registered(user_id):
                await update.message.reply_text("❌ You need to complete registration first. Please use /start to get your login code.")
                return
            
            # Update user activity
            self.auth_system.update_user_activity(user_id)
            
            # Grant temporary admin access directly
            self.auth_system.grant_admin_access(user_id)
            
            # Show admin menu with available commands
            admin_menu = """
🔧 **ADMIN PANEL** 🔧
⏰ Admin access expires in 30 minutes

🛠️ **ADMIN COMMANDS:**

📊 **/stats** - View complete system statistics
🧹 **/cleanup** - Clean up photos (keep only top 3 per category)
🧠 **/learn** - View learning system statistics
🔄 **/reset** - Reset leaderboards or complete data (with confirmation)
📋 **/new_category** - Create new leaderboard categories
🗑️ **/data_clean** - Clean up cache files and temporary data

💡 **Usage:**
• Use any command above to manage the system
• Admin access granted for 30 minutes
• Option 6 in /reset provides complete data reset with YES/NO confirmation

✅ **Admin panel activated successfully!**
            """
            
            await update.message.reply_text(admin_menu)
            
        except Exception as e:
            logger.error(f"Error in admin command: {e}")
            await update.message.reply_text("❌ Error accessing admin panel.")
    
    async def reset_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /reset command to show leaderboard reset options"""
        user_id = str(update.effective_user.id)
        user_id_int = int(user_id)
        
        try:
            # Check if user is registered
            if not self.auth_system.is_user_registered(user_id):
                await update.message.reply_text("❌ You need to complete registration first. Please use /start to get your login code.")
                return
            
            # Check if user has admin access (regular admin or temporary admin)
            if not (self.auth_system.is_admin(user_id) or self.auth_system.has_temp_admin(user_id)):
                await update.message.reply_text("❌ This command requires admin access. Use /admin to gain access.")
                return
            
            # Update user activity
            self.auth_system.update_user_activity(user_id)
            
            # Show reset options
            reset_menu = """
🔄 **RESET OPTIONS** 🔄

Choose what to reset:

1️⃣ Length Leaderboard
2️⃣ Overall Leaderboard  
3️⃣ Thickness Leaderboard
4️⃣ Silkiness Leaderboard
5️⃣ ALL Leaderboards
6️⃣ COMPLETE DATA RESET (All leaderboards + All photos)

⚠️ **WARNING**: This action cannot be undone!
All data in the selected option will be permanently deleted.

**Reply with the number (1-6) of your choice:**
            """
            
            await update.message.reply_text(reset_menu)
            
            # Set admin state for next message
            if not hasattr(self, 'admin_states'):
                self.admin_states = {}
            self.admin_states[user_id_int] = 'waiting_for_reset_choice'
            
        except Exception as e:
            logger.error(f"Error in reset command: {e}")
            await update.message.reply_text("❌ Sorry, couldn't access reset options right now.")
    

    
    async def new_category_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /new_category command to create new leaderboard categories"""
        user_id = str(update.effective_user.id)
        user_id_int = int(user_id)
        
        try:
            # Check if user is registered
            if not self.auth_system.is_user_registered(user_id):
                await update.message.reply_text("❌ You need to complete registration first. Please use /start to get your login code.")
                return
            
            # Check if user has admin access (regular admin or temporary admin)
            if not (self.auth_system.is_admin(user_id) or self.auth_system.has_temp_admin(user_id)):
                await update.message.reply_text("❌ This command requires admin access. Use /admin to gain access.")
                return
            
            # Update user activity
            self.auth_system.update_user_activity(user_id)
            
            # Check if category name is provided
            if not context.args:
                # Show current categories and ask for new one
                current_categories = photo_manager.get_category_names()
                category_list = '\n'.join([f"• {cat.replace('_', ' ').title()}" for cat in current_categories])
                
                response = f"""
📋 **CREATE NEW CATEGORY** 📋

**Current Categories:**
{category_list}

**Usage:** `/new_category <category_name>`

**Examples:**
• `/new_category hair_color`
• `/new_category texture`
• `/new_category volume`

Please provide a category name to create.
                """
                await update.message.reply_text(response)
                return
            
            # Get category name from arguments
            category_name = ' '.join(context.args).strip()
            
            # Validate category name
            if len(category_name) < 2 or len(category_name) > 30:
                await update.message.reply_text("❌ Category name must be between 2 and 30 characters.")
                return
            
            # Create the category
            success = photo_manager.add_new_category(category_name)
            
            if success:
                category_key = category_name.lower().replace(' ', '_')
                response = f"""
✅ **CATEGORY CREATED SUCCESSFULLY** ✅

**New Category:** {category_name.title()}
**Internal Key:** {category_key}

The new category is now available in the leaderboard system!
Users can now submit photos that will be ranked in this category.
                """
                await update.message.reply_text(response)
            else:
                await update.message.reply_text(f"❌ Category '{category_name}' already exists. Please choose a different name.")
            
        except Exception as e:
            logger.error(f"Error in new_category command: {e}")
            await update.message.reply_text("❌ Sorry, couldn't create the category right now.")
    
    async def stats_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /stats command to show user and system statistics"""
        user_id = str(update.effective_user.id)
        
        try:
            # Check if user is registered
            if not self.auth_system.is_user_registered(user_id):
                await update.message.reply_text("❌ You need to complete registration first. Please use /start to get your login code.")
                return
            
            # Check if user has admin access (regular admin or temporary admin)
            if not (self.auth_system.is_admin(user_id) or self.auth_system.has_temp_admin(user_id)):
                await update.message.reply_text("❌ This command requires admin access. Use /admin to gain access.")
                return
            
            # Update user activity
            self.auth_system.update_user_activity(user_id)
            
            # Get user stats
            user_stats = self.auth_system.get_user_stats()
            
            # Get additional system stats
            total_photos = len(os.listdir(self.upload_folder)) if os.path.exists(self.upload_folder) else 0
            total_styles = hairstyle_learning.get_hairstyle_count()
            
            # Get leaderboard stats
            leaderboard_data = photo_manager.get_leaderboard_data()
            total_submissions = len(leaderboard_data.get('photos', {}))
            
            stats_message = f"""
📊 **SYSTEM STATISTICS** 📊

👥 **USER STATS:**
• Total registered users: {user_stats['total_users']}
• Active users (24h): {user_stats['active_users_24h']}
• Total submissions: {user_stats['total_submissions']}

📸 **PHOTO STATS:**
• Photos in storage: {total_photos}
• Competition entries: {total_submissions}

🧠 **LEARNING SYSTEM:**
• Known hairstyles: {total_styles}

🏆 **LEADERBOARDS:**
• Overall entries: {len(leaderboard_data.get('leaderboards', {}).get('overall', []))}
• Length entries: {len(leaderboard_data.get('leaderboards', {}).get('length', []))}
• Thickness entries: {len(leaderboard_data.get('leaderboards', {}).get('thickness', []))}
• Silkiness entries: {len(leaderboard_data.get('leaderboards', {}).get('silkiness', []))}

⏰ **System Time:** {time.strftime('%Y-%m-%d %H:%M:%S UTC')}
            """
            
            await update.message.reply_text(stats_message)
            
        except Exception as e:
            logger.error(f"Error in stats command: {e}")
            await update.message.reply_text("❌ Sorry, couldn't load system statistics right now.")

    async def data_clean_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /data_clean command to clean up cache and temporary files"""
        user_id = str(update.effective_user.id)
        
        try:
            # Check if user is registered
            if not self.auth_system.is_user_registered(user_id):
                await update.message.reply_text("❌ You need to complete registration first. Please use /start to get your login code.")
                return
            
            # Check if user has admin access (regular admin or temporary admin)
            if not (self.auth_system.is_admin(user_id) or self.auth_system.has_temp_admin(user_id)):
                await update.message.reply_text("❌ This command requires admin access. Use /admin to gain access.")
                return
            
            # Update user activity
            self.auth_system.update_user_activity(user_id)
            
            # Show initial processing message
            processing_msg = await update.message.reply_text("🧹 Starting data cleanup process...")
            
            # Track cleanup results
            cleanup_results = {
                'cache_files': 0,
                'temp_files': 0,
                'old_makeovrs': 0,
                'empty_dirs': 0,
                'errors': []
            }
            
            # 1. Clean Python cache files
            try:
                import subprocess
                import glob
                
                # Remove __pycache__ directories
                result = subprocess.run(['find', '.', '-name', '__pycache__', '-type', 'd'], 
                                      capture_output=True, text=True)
                cache_dirs = result.stdout.strip().split('\n') if result.stdout.strip() else []
                
                for cache_dir in cache_dirs:
                    if cache_dir and os.path.exists(cache_dir):
                        subprocess.run(['rm', '-rf', cache_dir])
                        cleanup_results['cache_files'] += 1
                
                # Remove .pyc files
                result = subprocess.run(['find', '.', '-name', '*.pyc', '-type', 'f'], 
                                      capture_output=True, text=True)
                pyc_files = result.stdout.strip().split('\n') if result.stdout.strip() else []
                
                for pyc_file in pyc_files:
                    if pyc_file and os.path.exists(pyc_file):
                        os.remove(pyc_file)
                        cleanup_results['cache_files'] += 1
                        
            except Exception as e:
                cleanup_results['errors'].append(f"Cache cleanup: {str(e)[:50]}")
            
            # 2. Clean makeover temporary files
            try:
                makeover_temp_dir = 'makeover_temp'
                if os.path.exists(makeover_temp_dir):
                    import time
                    current_time = time.time()
                    
                    for filename in os.listdir(makeover_temp_dir):
                        filepath = os.path.join(makeover_temp_dir, filename)
                        if os.path.isfile(filepath):
                            # Remove files older than 1 hour
                            file_age = current_time - os.path.getctime(filepath)
                            if file_age > 3600:  # 1 hour in seconds
                                os.remove(filepath)
                                cleanup_results['old_makeovrs'] += 1
                                
            except Exception as e:
                cleanup_results['errors'].append(f"Makeover cleanup: {str(e)[:50]}")
            
            # 3. Clean up temporary log files and other temp files
            try:
                temp_patterns = ['*.tmp', '*.log', '*.temp', '*~', '.DS_Store']
                for pattern in temp_patterns:
                    for filepath in glob.glob(pattern):
                        if os.path.isfile(filepath):
                            os.remove(filepath)
                            cleanup_results['temp_files'] += 1
                            
            except Exception as e:
                cleanup_results['errors'].append(f"Temp files cleanup: {str(e)[:50]}")
            
            # 4. Clean empty directories
            try:
                for root, dirs, files in os.walk('.', topdown=False):
                    for directory in dirs:
                        dir_path = os.path.join(root, directory)
                        try:
                            # Skip important directories
                            if directory in ['static', 'templates', 'uploads', 'hairstyle_learning_dataset']:
                                continue
                            if os.path.exists(dir_path) and not os.listdir(dir_path):
                                os.rmdir(dir_path)
                                cleanup_results['empty_dirs'] += 1
                        except OSError:
                            pass  # Directory not empty or other error
                            
            except Exception as e:
                cleanup_results['errors'].append(f"Empty dirs cleanup: {str(e)[:50]}")
            
            # Prepare results message
            success_parts = []
            if cleanup_results['cache_files'] > 0:
                success_parts.append(f"🗂️ Cache files: {cleanup_results['cache_files']}")
            if cleanup_results['temp_files'] > 0:
                success_parts.append(f"📄 Temp files: {cleanup_results['temp_files']}")
            if cleanup_results['old_makeovrs'] > 0:
                success_parts.append(f"🎨 Old makeover files: {cleanup_results['old_makeovrs']}")
            if cleanup_results['empty_dirs'] > 0:
                success_parts.append(f"📁 Empty directories: {cleanup_results['empty_dirs']}")
            
            results_message = f"""
🧹 **DATA CLEANUP COMPLETED** 🧹

✅ **CLEANED UP:**
{chr(10).join(success_parts) if success_parts else "• No files needed cleanup"}

⚠️ **ERRORS:** {len(cleanup_results['errors'])}
{chr(10).join([f"• {error}" for error in cleanup_results['errors'][:3]]) if cleanup_results['errors'] else "None"}

🔄 **SYSTEM STATUS:** Optimized and clean
⏰ **Completed at:** {time.strftime('%H:%M:%S UTC')}

The system cache has been cleared and temporary files removed.
Performance should be improved after cleanup.
            """
            
            # Update the processing message
            await processing_msg.edit_text(results_message)
            
        except Exception as e:
            logger.error(f"Error in data_clean command: {e}")
            await update.message.reply_text("❌ Sorry, couldn't complete the data cleanup right now.")

    async def _handle_admin_reset_choice(self, update: Update, choice: str, user_id: int):
        """Handle admin's choice for leaderboard reset"""
        try:
            choice = choice.strip()
            
            if choice == "1":
                # Clear admin state
                if hasattr(self, 'admin_states') and user_id in self.admin_states:
                    del self.admin_states[user_id]
                # Reset Length Leaderboard
                photo_manager.reset_leaderboard('length')
                await update.message.reply_text("✅ Length leaderboard has been reset successfully!")
                
            elif choice == "2":
                # Clear admin state
                if hasattr(self, 'admin_states') and user_id in self.admin_states:
                    del self.admin_states[user_id]
                # Reset Overall Leaderboard
                photo_manager.reset_leaderboard('overall')
                await update.message.reply_text("✅ Overall leaderboard has been reset successfully!")
                
            elif choice == "3":
                # Clear admin state
                if hasattr(self, 'admin_states') and user_id in self.admin_states:
                    del self.admin_states[user_id]
                # Reset Thickness Leaderboard
                photo_manager.reset_leaderboard('thickness')
                await update.message.reply_text("✅ Thickness leaderboard has been reset successfully!")
                
            elif choice == "4":
                # Clear admin state
                if hasattr(self, 'admin_states') and user_id in self.admin_states:
                    del self.admin_states[user_id]
                # Reset Silkiness Leaderboard
                photo_manager.reset_leaderboard('silkiness')
                await update.message.reply_text("✅ Silkiness leaderboard has been reset successfully!")
                
            elif choice == "5":
                # Clear admin state
                if hasattr(self, 'admin_states') and user_id in self.admin_states:
                    del self.admin_states[user_id]
                # Reset ALL Leaderboards
                photo_manager.reset_all_leaderboards()
                await update.message.reply_text("✅ ALL leaderboards have been reset successfully!\n🔄 Complete fresh start!")
                
            elif choice == "6":
                # Show confirmation prompt for complete data reset
                confirmation_message = """
🚨 **COMPLETE DATA RESET CONFIRMATION** 🚨

⚠️ **EXTREME WARNING**: This action will permanently delete:
• ALL leaderboard data
• ALL uploaded photos
• ALL user competition history
• ALL stored analysis results

This is a COMPLETE SYSTEM RESET that cannot be undone!

🔴 **Type 'YES' to confirm complete reset**
🟡 **Type 'NO' to cancel**

Are you absolutely sure you want to proceed?
                """
                
                await update.message.reply_text(confirmation_message)
                
                # Change admin state to wait for YES/NO confirmation
                self.admin_states[user_id] = 'waiting_for_complete_reset_confirmation'
                
            else:
                # Clear admin state
                if hasattr(self, 'admin_states') and user_id in self.admin_states:
                    del self.admin_states[user_id]
                await update.message.reply_text("❌ Invalid choice. Please use /reset to try again.")
                
        except Exception as e:
            logger.error(f"Error handling admin reset: {e}")
            await update.message.reply_text("❌ Error processing reset command.")
    
    async def _handle_complete_reset_confirmation(self, update: Update, confirmation: str, user_id: int):
        """Handle YES/NO confirmation for complete data reset"""
        try:
            confirmation = confirmation.strip().upper()
            
            # Clear admin state
            if hasattr(self, 'admin_states') and user_id in self.admin_states:
                del self.admin_states[user_id]
            
            if confirmation == "YES":
                # Perform complete data reset
                try:
                    result = photo_manager.reset_all_data()
                    deleted_photos = result.get('deleted_photos', 0)
                    
                    success_message = f"""
🚨 **COMPLETE DATA RESET COMPLETED** 🚨

✅ System has been completely reset!

📊 **Reset Summary:**
• All leaderboard data: DELETED
• All photo files: {deleted_photos} files DELETED
• All user competition history: DELETED
• All stored analysis results: DELETED

🔄 The system is now completely fresh and ready for new data.
                    """
                    
                    await update.message.reply_text(success_message)
                    
                except Exception as e:
                    logger.error(f"Error performing complete reset: {e}")
                    await update.message.reply_text("❌ Error occurred during complete reset. Some data may have been partially reset.")
                
            elif confirmation == "NO":
                await update.message.reply_text("✅ Complete data reset has been cancelled. No data was deleted.")
                
            else:
                await update.message.reply_text("❌ Invalid response. Please type exactly 'YES' or 'NO'. Use /reset to try again.")
                
        except Exception as e:
            logger.error(f"Error handling complete reset confirmation: {e}")
            await update.message.reply_text("❌ Error processing confirmation.")
    
    async def handle_ai_makeover_start(self, query):
        """Handle AI makeover button click"""
        try:
            user_id = str(query.from_user.id)
            is_admin = self.auth_system.is_admin(user_id)
            
            # Check if user can start makeover
            can_makeover, message = ai_makeover_system.can_user_makeover(user_id, is_admin)
            
            if not can_makeover:
                await query.edit_message_text(
                    f"❌ AI MAKEOVER NOT AVAILABLE\n\n"
                    f"{message}\n\n"
                    f"💡 You can only have one active makeover session at a time."
                )
                return
            
            # Start makeover session
            session_id = ai_makeover_system.start_makeover_session(user_id)
            
            makeover_instructions = """
⚠️ **EXPERIMENTAL AI MAKEOVER** ⚠️

🧪 **BETA FEATURE NOTICE:**
This AI hairstyle transfer is in early development and may produce unpredictable results. Consider this a fun experimental preview rather than a finished feature!

📸 **STEP 1: YOUR PHOTO**
Send me a clear headshot photo of yourself:
• Front-facing or side profile works best
• Good lighting, clear hair visibility
• Make sure you have permission to use the photo

💇‍♀️ **STEP 2:** Send a reference hairstyle image
🎨 **RESULT:** See the AI's experimental attempt at hair transfer

⚠️ **Expected Issues:**
• Results may look distorted or unnatural
• Colors might not blend properly
• Hair placement may be inaccurate
• This is prototype technology!

⏰ **Note:** Sessions expire after 2 hours
🔄 **Limit:** One attempt per user (admins unlimited)

Ready to test our experimental AI? Send your photo! 📷
            """
            
            # Add back to menu button
            keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data='back_to_menu')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(makeover_instructions, reply_markup=reply_markup)
            
        except Exception as e:
            logger.error(f"Error starting AI makeover: {e}")
            await query.edit_message_text("❌ Sorry, couldn't start AI makeover. Please try again later.")
    
    async def handle_makeover_photo(self, update: Update, user_id: str, photo_path: str):
        """Handle photo uploads for makeover sessions"""
        try:
            session_status = ai_makeover_system.get_session_status(user_id)
            
            if session_status.get('status') != 'active':
                # Not in makeover session, handle as regular competition photo
                return False
            
            current_step = session_status.get('step')
            
            if current_step == 'waiting_user_photo':
                # Save user's photo
                success = ai_makeover_system.save_user_photo(user_id, photo_path)
                
                if success:
                    await update.message.reply_text(
                        "✅ **YOUR PHOTO RECEIVED!**\n\n"
                        "📷 **STEP 2: REFERENCE HAIRSTYLE**\n"
                        "Now send me a photo of the hairstyle you want to try:\n\n"
                        "• Celebrity hairstyle photos work great\n"
                        "• Hair salon style references\n"
                        "• Any hairstyle that catches your eye\n"
                        "• Clear hair visibility is important\n\n"
                        "💡 **Tip:** The better the reference photo, the better your makeover result!\n\n"
                        "Send the reference hairstyle photo now! 💇‍♀️"
                    )
                else:
                    await update.message.reply_text(
                        "❌ Error saving your photo. Please try again or start a new makeover session."
                    )
                
                return True
                
            elif current_step == 'waiting_reference_photo':
                # Save reference photo and start processing
                success = ai_makeover_system.save_reference_photo(user_id, photo_path)
                
                if success:
                    await update.message.reply_text(
                        "✅ **REFERENCE PHOTO RECEIVED!**\n\n"
                        "🎨 **PROCESSING YOUR MAKEOVER...**\n\n"
                        "⚡ AI is working its magic:\n"
                        "• Analyzing your facial features\n"
                        "• Segmenting hair regions\n"
                        "• Aligning the new hairstyle\n"
                        "• Blending everything perfectly\n\n"
                        "⏳ This may take 30-60 seconds...\n\n"
                        "✨ Your stunning makeover is coming right up!"
                    )
                    
                    # Process makeover
                    success, message, result_path = ai_makeover_system.process_makeover(user_id)
                    
                    # Fallback: If processing fails, try a simple test image for debugging
                    if not success or not result_path:
                        logger.warning(f"Makeover processing failed: {message}")
                        logger.info("Attempting to create test image for debugging...")
                        
                        import uuid
                        test_path = os.path.join(ai_makeover_system.temp_folder, f"test_{uuid.uuid4()}.jpg")
                        if ai_makeover_system.create_test_image(test_path):
                            logger.info("Test image created successfully, using as fallback")
                            success, message, result_path = True, "Test image created for debugging", test_path
                    
                    if success and result_path:
                        try:
                            # Verify file exists and has content
                            if not os.path.exists(result_path):
                                raise FileNotFoundError(f"Result file not found: {result_path}")
                            
                            file_size = os.path.getsize(result_path)
                            if file_size == 0:
                                raise ValueError("Result file is empty")
                            
                            logger.info(f"Sending makeover result: {result_path}, size: {file_size} bytes")
                            
                            # Try multiple methods to send the photo
                            photo_sent = False
                            
                            # Method 1: Direct file path
                            try:
                                await update.message.reply_photo(
                                    photo=open(result_path, 'rb'),
                                    caption="🧪 **EXPERIMENTAL AI RESULT** 🧪\n\n"
                                           "⚠️ This is a prototype hairstyle transfer - results may be imperfect!\n\n"
                                           "🤔 How did our experimental AI do?\n"
                                           "💡 Remember: This is early-stage technology\n\n"
                                           "🔄 Want to try again? Admins can test multiple times!\n"
                                           "📸 Ready for real hair analysis? Send a photo for the competition!"
                                )
                                photo_sent = True
                                logger.info("Photo sent successfully via method 1")
                            except Exception as e1:
                                logger.warning(f"Method 1 failed: {e1}")
                                
                                # Method 2: BytesIO buffer
                                try:
                                    import io
                                    with open(result_path, 'rb') as f:
                                        photo_bytes = io.BytesIO(f.read())
                                        photo_bytes.name = 'makeover_result.jpg'
                                        photo_bytes.seek(0)
                                        
                                    await update.message.reply_photo(
                                        photo=photo_bytes,
                                        caption="🧪 **EXPERIMENTAL AI RESULT** 🧪\n\n"
                                               "⚠️ This is a prototype hairstyle transfer - results may be imperfect!\n\n"
                                               "🤔 How did our experimental AI do?\n"
                                               "💡 Remember: This is early-stage technology\n\n"
                                               "🔄 Want to try again? Admins can test multiple times!\n"
                                               "📸 Ready for real hair analysis? Send a photo for the competition!"
                                    )
                                    photo_sent = True
                                    logger.info("Photo sent successfully via method 2")
                                except Exception as e2:
                                    logger.warning(f"Method 2 failed: {e2}")
                                    raise Exception(f"All photo sending methods failed. Method 1: {e1}, Method 2: {e2}")
                            
                            if not photo_sent:
                                raise Exception("Failed to send photo via any method")
                            
                            logger.info("Makeover result sent successfully")
                            
                        except Exception as send_error:
                            logger.error(f"Error sending makeover result: {send_error}")
                            await update.message.reply_text(
                                f"✅ **MAKEOVER COMPLETED!**\n\n"
                                f"Your virtual makeover was processed successfully, but there was an issue sending the image.\n\n"
                                f"📋 **Technical details for debugging:**\n"
                                f"• Processing: ✅ Complete\n"
                                f"• File creation: ✅ Success\n"
                                f"• File size: {file_size if 'file_size' in locals() else 'Unknown'} bytes\n"
                                f"• Send error: {str(send_error)}\n\n"
                                f"🔄 Please try starting a new makeover session."
                            )
                        
                        # Clean up session and files
                        ai_makeover_system.cleanup_session(user_id)
                        
                    else:
                        await update.message.reply_text(
                            f"❌ **MAKEOVER PROCESSING FAILED**\n\n"
                            f"Sorry, couldn't complete your makeover: {message}\n\n"
                            f"💡 **Tips to try again:**\n"
                            f"• Use clearer, well-lit photos\n"
                            f"• Make sure faces are clearly visible\n"
                            f"• Try different reference hairstyle photos\n\n"
                            f"🔄 Start a new makeover session with /start"
                        )
                        
                        # Clean up failed session
                        ai_makeover_system.cleanup_session(user_id)
                
                else:
                    await update.message.reply_text(
                        "❌ Error saving reference photo. Please try again or start a new makeover session."
                    )
                
                return True
            
            else:
                await update.message.reply_text(
                    f"❌ Session in unexpected state: {current_step}. Please start a new makeover session."
                )
                return True
                
        except Exception as e:
            logger.error(f"Error handling makeover photo: {e}")
            await update.message.reply_text(
                "❌ Error processing makeover photo. Please try again or start a new session."
            )
            return True

# Global bot instance
telegram_bot = TelegramBot()