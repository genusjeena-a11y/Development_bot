"""
Enhanced Bot Learning System for Hairstyles
Allows users to teach the bot new hairstyles through interactive learning
"""
import os
import json
import shutil
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

class HairstyleLearningSystem:
    def __init__(self):
        self.known_hairstyles_file = 'known_hairstyles.json'
        self.learning_dataset_folder = 'hairstyle_learning_dataset'
        self.known_hairstyles = self.load_known_hairstyles()
        
        # Create learning dataset folder if it doesn't exist
        os.makedirs(self.learning_dataset_folder, exist_ok=True)
        
    def load_known_hairstyles(self) -> List[str]:
        """Load the list of known hairstyles from file"""
        try:
            if os.path.exists(self.known_hairstyles_file):
                with open(self.known_hairstyles_file, 'r') as f:
                    data = json.load(f)
                    return data.get('hairstyles', self.get_default_hairstyles())
            else:
                return self.get_default_hairstyles()
        except Exception as e:
            logger.error(f"Error loading known hairstyles: {e}")
            return self.get_default_hairstyles()
    
    def get_default_hairstyles(self) -> List[str]:
        """Get the default list of known hairstyles"""
        return [
            'ponytail', 'braid', 'bun', 'straight', 'curly', 'wavy',
            'bob', 'pixie', 'messy', 'updo', 'loose', 'half-up',
            'fishtail braid', 'french braid', 'dutch braid', 'side braid',
            'top knot', 'low bun', 'high bun', 'twisted bun',
            'beach waves', 'finger waves', 'ringlets', 'afro',
            'lob', 'shag', 'layers', 'bangs', 'side part', 'center part'
        ]
    
    def save_known_hairstyles(self):
        """Save the current list of known hairstyles to file"""
        try:
            data = {'hairstyles': self.known_hairstyles}
            with open(self.known_hairstyles_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving known hairstyles: {e}")
    
    def is_hairstyle_known(self, detected_style: str) -> bool:
        """Check if the detected hairstyle is in the known list"""
        detected_lower = detected_style.lower().strip()
        return any(known.lower() in detected_lower or detected_lower in known.lower() 
                  for known in self.known_hairstyles)
    
    def add_new_hairstyle(self, hairstyle_name: str, photo_path: str, unique_id: str) -> bool:
        """
        Add a new hairstyle to the learning system
        
        Args:
            hairstyle_name: User-provided name for the hairstyle
            photo_path: Path to the original photo
            unique_id: Unique identifier for this submission
            
        Returns:
            bool: True if successfully added, False otherwise
        """
        try:
            # Clean and normalize the hairstyle name
            clean_name = self.clean_hairstyle_name(hairstyle_name)
            
            # Create folder for this hairstyle if it doesn't exist
            style_folder = os.path.join(self.learning_dataset_folder, clean_name)
            os.makedirs(style_folder, exist_ok=True)
            
            # Copy photo to the learning dataset folder
            destination_path = os.path.join(style_folder, f"{unique_id}.jpg")
            shutil.copy2(photo_path, destination_path)
            
            # Add to known hairstyles if not already there
            if not self.is_hairstyle_known(clean_name):
                self.known_hairstyles.append(clean_name)
                self.save_known_hairstyles()
                logger.info(f"Added new hairstyle to learning system: {clean_name}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error adding new hairstyle {hairstyle_name}: {e}")
            return False
    
    def clean_hairstyle_name(self, name: str) -> str:
        """Clean and normalize a hairstyle name"""
        # Remove special characters, convert to lowercase, replace spaces with underscores
        clean = ''.join(c for c in name if c.isalnum() or c in ' -_')
        clean = clean.lower().strip().replace(' ', '_').replace('-', '_')
        # Remove multiple underscores
        while '__' in clean:
            clean = clean.replace('__', '_')
        return clean.strip('_')
    
    def get_learning_prompt(self) -> str:
        """Get the prompt message to ask user about unknown hairstyle"""
        prompts = [
            "Hey Queen 👑, what do you call this gorgeous hairstyle? I want to learn! ✨",
            "Ooh, this style is stunning! 😍 What's the name of this hairstyle, babe?",
            "I'm loving this look! 💕 Help me learn - what do you call this hairstyle?",
            "This hairstyle is fire! 🔥 What should I call this beautiful style?",
            "Gorgeous hair alert! 💫 I haven't seen this style before - what's it called?",
        ]
        import random
        return random.choice(prompts)
    
    def get_learning_confirmation(self, hairstyle_name: str) -> str:
        """Get confirmation message after learning new hairstyle"""
        confirmations = [
            f"YES! I learned '{hairstyle_name}'! 🎉 Next time I see this style, I'll recognize it! ✨",
            f"Amazing! '{hairstyle_name}' is now in my style database! 📚💕 Thanks for teaching me!",
            f"Got it! '{hairstyle_name}' added to my hair knowledge! 🧠💫 You're the best teacher!",
            f"Perfect! I'll remember '{hairstyle_name}' forever! 💝 My style recognition just leveled up!",
            f"Yass! '{hairstyle_name}' is officially part of my vocabulary! 👑✨ Thanks, beauty guru!"
        ]
        import random
        return random.choice(confirmations)
    
    def get_hairstyle_count(self) -> int:
        """Get the total number of known hairstyles"""
        return len(self.known_hairstyles)
    
    def get_learned_styles_this_session(self) -> List[str]:
        """Get styles learned in current session (for stats)"""
        # This could be enhanced to track session-specific learning
        return []

# Global instance
hairstyle_learning = HairstyleLearningSystem()