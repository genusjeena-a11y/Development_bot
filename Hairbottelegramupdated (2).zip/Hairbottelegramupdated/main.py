import os
import asyncio
import threading
import atexit
from routes_nodatabase import app
from bot_nodatabase import telegram_bot
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler

# Global bot application instance
bot_application = None
bot_thread = None

async def run_bot_async():
    """Run the bot asynchronously"""
    global bot_application
    
    bot_application = Application.builder().token(telegram_bot.bot_token).build()
    
    # Add handlers
    bot_application.add_handler(CommandHandler("start", telegram_bot.start))
    bot_application.add_handler(CommandHandler("help", telegram_bot.help_command))
    bot_application.add_handler(CommandHandler("leaderboard", telegram_bot.leaderboard_command))
    bot_application.add_handler(CommandHandler("cleanup", telegram_bot.cleanup_command))
    bot_application.add_handler(CommandHandler("learn", telegram_bot.learn_command))
    bot_application.add_handler(CommandHandler("stats", telegram_bot.stats_command))
    bot_application.add_handler(CommandHandler("reset", telegram_bot.reset_command))
    bot_application.add_handler(CommandHandler("new_category", telegram_bot.new_category_command))
    bot_application.add_handler(CommandHandler("data_clean", telegram_bot.data_clean_command))
    bot_application.add_handler(CommandHandler("makeover", telegram_bot.makeover_command))
    
    # Challenge system commands
    bot_application.add_handler(CommandHandler("challenges", telegram_bot.challenges_command))
    bot_application.add_handler(CommandHandler("mystats", telegram_bot.mystats_command))
    bot_application.add_handler(CommandHandler("trythis", telegram_bot.trythis_command))
    
    # Admin commands
    bot_application.add_handler(CommandHandler("admin", telegram_bot.admin_command))
    bot_application.add_handler(MessageHandler(filters.PHOTO, telegram_bot.handle_photo))
    bot_application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, telegram_bot.handle_text))
    bot_application.add_handler(CallbackQueryHandler(telegram_bot.button_handler))
    
    print("Telegram bot initialized and starting polling...")
    
    # Start polling without signal handlers (for thread compatibility)
    async with bot_application:
        await bot_application.start()
        await bot_application.updater.start_polling(drop_pending_updates=True)
        
        # Keep running
        try:
            while True:
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            print("Bot polling cancelled")
        finally:
            await bot_application.updater.stop()
            await bot_application.stop()

def start_telegram_bot():
    """Initialize and start Telegram bot in background thread"""
    try:
        # Create new event loop for this thread
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        # Run the bot
        loop.run_until_complete(run_bot_async())
        
    except Exception as e:
        print(f"Error starting Telegram bot: {e}")
        import traceback
        traceback.print_exc()

def cleanup_bot():
    """Clean up bot on shutdown"""
    global bot_application
    if bot_application:
        try:
            # Stop the bot gracefully
            asyncio.run(bot_application.stop())
            print("Telegram bot stopped")
        except Exception as e:
            print(f"Error stopping bot: {e}")

# Register cleanup function
atexit.register(cleanup_bot)

# Start bot in background thread when module is imported
def init_bot():
    global bot_thread
    if bot_thread is None:
        bot_thread = threading.Thread(target=start_telegram_bot, daemon=True)
        bot_thread.start()
        print("Telegram bot thread started")

# Initialize bot automatically when gunicorn loads the module
init_bot()

if __name__ == '__main__':
    print("Hair Analysis Bot - No Database Version")
    print("=====================================")
    
    # When run directly, start Flask app (for testing)
    app.run(host='0.0.0.0', port=5000, debug=True)
